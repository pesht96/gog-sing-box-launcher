#!/bin/sh
set -eu
PKG_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
INSTALLER="$PKG_DIR/gog_singbox_launcher_1_13_7.sh"
[ -s "$INSTALLER" ] || {
    echo "installer missing from update package" >&2
    exit 1
}
sh -n "$INSTALLER"
GOG_UPDATE_MODE=1 sh "$INSTALLER"