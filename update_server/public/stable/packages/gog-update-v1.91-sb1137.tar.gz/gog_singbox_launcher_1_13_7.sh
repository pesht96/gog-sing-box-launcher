#!/bin/sh
# GOG Sing-Box Launcher sing-box 1.13.7 baseline for OpenWrt
# Keeps improved UI + safe apply + smart auto_redirect runtime probing

set -eu

LAB_SINGBOX_VERSION="${GOG_LAB_SINGBOX_VERSION:-1.13.7}"
LAB_SINGBOX_RELEASE_BASE="https://github.com/SagerNet/sing-box/releases/download/v$LAB_SINGBOX_VERSION"
GOG_UPDATE_MODE="${GOG_UPDATE_MODE:-0}"
INSTALL_TMP_DIR="/tmp/gog-install.$$"
TMP_DIR="$INSTALL_TMP_DIR"
mkdir -p "$TMP_DIR"
trap 'rm -rf "$INSTALL_TMP_DIR"' EXIT HUP INT TERM

echo "=========================================="
echo "🚀 Установка GOG Sing-Box Launcher 1.13.7 baseline (v1.91-sb1137)"
echo "=========================================="
install_pkg() {
    PKG="$1"
    if command -v apk >/dev/null 2>&1; then
        apk add "$PKG" >/dev/null 2>&1 || return 1
        return 0
    elif command -v opkg >/dev/null 2>&1; then
        opkg install "$PKG" >/dev/null 2>&1 || return 1
        return 0
    fi
    return 1
}

download_lab_core_pkg() {
    url="$1"
    dst="$2"
    if command -v curl >/dev/null 2>&1; then
        curl -fL --retry 3 --connect-timeout 15 -o "$dst" "$url" >/dev/null 2>&1 && return 0
    fi
    if command -v wget >/dev/null 2>&1; then
        wget -q -O "$dst" "$url" && return 0
    fi
    return 1
}

detect_openwrt_pkg_arch() {
    if command -v apk >/dev/null 2>&1; then
        apk --print-arch 2>/dev/null | head -n 1
        return 0
    fi
    if command -v opkg >/dev/null 2>&1; then
        opkg print-architecture 2>/dev/null | awk '$2 != "all" && $2 != "noarch" { arch=$2 } END { if (arch != "") print arch }'
        return 0
    fi
    return 1
}

install_lab_singbox_core() {
    arch=$(detect_openwrt_pkg_arch || true)
    [ -n "$arch" ] || return 1

    pkg_ext="apk"
    pkg_name="sing-box_${LAB_SINGBOX_VERSION}_openwrt_${arch}.apk"
    if command -v opkg >/dev/null 2>&1 && ! command -v apk >/dev/null 2>&1; then
        pkg_ext="ipk"
        pkg_name="sing-box_${LAB_SINGBOX_VERSION}_openwrt_${arch}.ipk"
    fi

    pkg_url="$LAB_SINGBOX_RELEASE_BASE/$pkg_name"
    pkg_path="$TMP_DIR/$pkg_name"
    install_log="$TMP_DIR/sing-box-lab-install.log"

    rm -f "$pkg_path" "$install_log"
    download_lab_core_pkg "$pkg_url" "$pkg_path" || {
        {
            echo "failed to download lab sing-box package"
            echo "version=$LAB_SINGBOX_VERSION"
            echo "arch=$arch"
            echo "url=$pkg_url"
        } > "$install_log"
        return 1
    }

    if [ "$pkg_ext" = "apk" ]; then
        apk add --allow-untrusted "$pkg_path" >"$install_log" 2>&1 || return 1
        return 0
    fi

    opkg install "$pkg_path" >"$install_log" 2>&1 || return 1
    return 0
}

require_cmd() {
    command -v "$1" >/dev/null 2>&1
}

disable_stock_singbox_service() {
    if [ -x /etc/init.d/sing-box ]; then
        /etc/init.d/sing-box stop >/dev/null 2>&1 || true
        /etc/init.d/sing-box disable >/dev/null 2>&1 || true
    fi
}

echo "[1/5] Проверка зависимостей..."
PKG_ERRORS=""
if [ "$GOG_UPDATE_MODE" = "1" ]; then
    echo "    update mode: пропускаю переустановку sing-box core"
else
    for pkg in coreutils-base64 kmod-tun curl ca-bundle wget-ssl nftables usign; do
        install_pkg "$pkg" || PKG_ERRORS="$PKG_ERRORS $pkg"
    done
    install_lab_singbox_core || PKG_ERRORS="$PKG_ERRORS sing-box-lab-$LAB_SINGBOX_VERSION"
fi
disable_stock_singbox_service

MISSING_CMDS=""
for cmd in sing-box ip sed awk grep cut tr md5sum base64 usign tar; do
    require_cmd "$cmd" || MISSING_CMDS="$MISSING_CMDS $cmd"
done

if [ -n "$MISSING_CMDS" ]; then
    echo "❌ Не хватает обязательных команд:$MISSING_CMDS"
    [ -n "$PKG_ERRORS" ] && echo "Не удалось установить пакеты:$PKG_ERRORS"
    exit 1
fi

mkdir -p /www/myproxy /www/cgi-bin /etc/sing-box /tmp/gog-build

echo "[2/5] Подготовка firewall-зоны tun0..."
if ! uci show firewall 2>/dev/null | grep -q "name='singbox'"; then
    uci add firewall zone >/dev/null
    uci set firewall.@zone[-1].name='singbox'
    uci set firewall.@zone[-1].input='ACCEPT'
    uci set firewall.@zone[-1].forward='ACCEPT'
    uci set firewall.@zone[-1].output='ACCEPT'
    uci set firewall.@zone[-1].masq='1'
    uci set firewall.@zone[-1].device='tun0'
    uci add firewall forwarding >/dev/null
    uci set firewall.@forwarding[-1].src='lan'
    uci set firewall.@forwarding[-1].dest='singbox'
    uci commit firewall
fi
/etc/init.d/firewall restart >/dev/null 2>&1 || /etc/init.d/firewall reload >/dev/null 2>&1 || true

echo "[3/5] Установка helper-скриптов..."
cat <<'EOF' > /usr/bin/gog-proxy-stop
#!/bin/sh
killall sing-box >/dev/null 2>&1 || true
i=0
while [ "$i" -lt 3 ]; do
    if ! pidof sing-box >/dev/null 2>&1; then
        break
    fi
    sleep 1
    i=$((i+1))
done
if pidof sing-box >/dev/null 2>&1; then
    killall -9 sing-box >/dev/null 2>&1 || true
    i=0
    while [ "$i" -lt 2 ]; do
        if ! pidof sing-box >/dev/null 2>&1; then
            break
        fi
        sleep 1
        i=$((i+1))
    done
fi
[ -s /tmp/gog_log_filter.pid ] && filter_pid=$(cat /tmp/gog_log_filter.pid 2>/dev/null || true) || filter_pid=""
[ -n "$filter_pid" ] && kill "$filter_pid" >/dev/null 2>&1 || true
[ -n "$filter_pid" ] && kill -9 "$filter_pid" >/dev/null 2>&1 || true
rm -f /tmp/gog_log_filter.pid /tmp/gog_log.pipe
EOF
chmod +x /usr/bin/gog-proxy-stop

cat <<'EOF' > /usr/bin/gog-log-filter
#!/bin/sh
while IFS= read -r line || [ -n "$line" ]; do
    clean=$(printf '%s' "$line" | tr -d '\033' | sed 's/\[[0-9;]*m//g')
    case "$clean" in
        *"FATAL["*|*"PANIC["*|*"WARN["*|*"outbound/urltest[AUTO-BALANCE]"*|*"outbound/vless[srv-"*|*"outbound/trojan[srv-"*|*"outbound/hysteria2[srv-"*)
            printf '%s\n' "$clean"
            ;;
        *"ERROR["*)
            case "$clean" in
                *"outbound/urltest[AUTO-BALANCE]"*|*"outbound/vless["*|*"outbound/trojan["*|*"outbound/hysteria2["*|*"tun["*|*"dns-out"*|*"reality"*|*"config.json"*|*"sing-box"*)
                    printf '%s\n' "$clean"
                    ;;
            esac
            ;;
    esac
done
EOF
chmod +x /usr/bin/gog-log-filter

cat <<'EOF' > /usr/bin/gog-proxy-start
#!/bin/sh
CFG="$1"
LOG_LIMIT=262144
START_WAIT_SECONDS=15
REFILTER_DOMAINS_FILE="/etc/sing-box/refilter_domains.srs"
REFILTER_IPSUM_FILE="/etc/sing-box/refilter_ipsum.srs"
REFILTER_BOOTSTRAP_DIR="/etc/gog/refilter-cache"
REFILTER_DOMAINS_CACHE_FILE="$REFILTER_BOOTSTRAP_DIR/refilter_domains.srs"
REFILTER_IPSUM_CACHE_FILE="$REFILTER_BOOTSTRAP_DIR/refilter_ipsum.srs"
snapshot_tail() {
    src="$1"
    dst="$2"
    limit="$3"
    [ -s "$src" ] || { rm -f "$dst"; return 0; }
    tail -c "$limit" "$src" > "$dst" 2>/dev/null || cp "$src" "$dst" >/dev/null 2>&1 || true
}
restore_refilter_asset() {
    active_file="$1"
    cache_file="$2"
    [ -s "$active_file" ] && return 0
    [ -s "$cache_file" ] || return 1
    mkdir -p "$(dirname "$active_file")" >/dev/null 2>&1 || true
    cp "$cache_file" "$active_file" >/dev/null 2>&1 || cat "$cache_file" > "$active_file" 2>/dev/null || return 1
    [ -s "$active_file" ]
}
ensure_refilter_assets() {
    [ -s "$CFG" ] || return 1
    if grep -F "$REFILTER_DOMAINS_FILE" "$CFG" >/dev/null 2>&1 || grep -F "$REFILTER_IPSUM_FILE" "$CFG" >/dev/null 2>&1; then
        restore_refilter_asset "$REFILTER_DOMAINS_FILE" "$REFILTER_DOMAINS_CACHE_FILE" || return 1
        restore_refilter_asset "$REFILTER_IPSUM_FILE" "$REFILTER_IPSUM_CACHE_FILE" || return 1
    fi
}
[ -n "$CFG" ] || CFG="/etc/sing-box/config.json"
[ -s "$CFG" ] || exit 1
ensure_refilter_assets || exit 1
/usr/bin/gog-proxy-stop >/dev/null 2>&1 || true
[ -s /tmp/gog.log ] && snapshot_tail /tmp/gog.log /tmp/gog.log.1 "$LOG_LIMIT" || true
rm -f /tmp/gog.log /tmp/gog_active_server_observation.txt /tmp/gog_log.pipe /tmp/gog_log_filter.pid
mkfifo /tmp/gog_log.pipe || exit 1
/usr/bin/gog-log-filter < /tmp/gog_log.pipe >> /tmp/gog.log &
FILTER_PID=$!
printf '%s' "$FILTER_PID" > /tmp/gog_log_filter.pid
ulimit -n 8192 >/dev/null 2>&1 || true
/usr/bin/sing-box run -c "$CFG" </dev/null >/tmp/gog_log.pipe 2>&1 &
i=0
while [ "$i" -lt "$START_WAIT_SECONDS" ]; do
    sleep 1
    if ! pidof sing-box >/dev/null 2>&1; then
        kill "$FILTER_PID" >/dev/null 2>&1 || true
        kill -9 "$FILTER_PID" >/dev/null 2>&1 || true
        rm -f /tmp/gog_log_filter.pid /tmp/gog_log.pipe
        exit 1
    fi
    if pidof sing-box >/dev/null 2>&1 && ip link show tun0 >/dev/null 2>&1; then
        exit 0
    fi
    i=$((i+1))
done
exit 1
EOF
chmod +x /usr/bin/gog-proxy-start

cat <<'EOF' > /usr/bin/gog-self-update
#!/bin/sh
CMD="${1:-status}"
case "$CMD" in
    status)
        QUERY_STRING='action=update_status' REQUEST_METHOD='GET' /www/cgi-bin/myproxy_api
        ;;
    check)
        QUERY_STRING='action=update_check' REQUEST_METHOD='GET' /www/cgi-bin/myproxy_api
        ;;
    download)
        QUERY_STRING='action=update_download' REQUEST_METHOD='POST' /www/cgi-bin/myproxy_api
        ;;
    install)
        QUERY_STRING='action=update_install' REQUEST_METHOD='POST' /www/cgi-bin/myproxy_api
        ;;
    rollback)
        QUERY_STRING='action=update_rollback' REQUEST_METHOD='POST' /www/cgi-bin/myproxy_api
        ;;
    weekly)
        status_json=$(QUERY_STRING='action=update_status' REQUEST_METHOD='GET' /www/cgi-bin/myproxy_api 2>/dev/null || true)
        printf '%s' "$status_json" | grep -q '"auto_check_enabled":[[:space:]]*false' && exit 0
        seed=$(date +%s 2>/dev/null || echo 0)
        case "$seed" in ''|*[!0-9]*) seed=0 ;; esac
        delay=$((seed % 21600))
        sleep "$delay"
        QUERY_STRING='action=update_check' REQUEST_METHOD='GET' /www/cgi-bin/myproxy_api >/dev/null 2>&1 || true
        ;;
    *)
        echo "Usage: gog-self-update {status|check|download|install|rollback|weekly}" >&2
        exit 2
        ;;
esac
EOF
chmod +x /usr/bin/gog-self-update
echo "[4/5] Установка веб-интерфейса..."
cat <<'EOF' > /www/myproxy/index.html
<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta http-equiv="Cache-Control" content="no-store, no-cache, must-revalidate, max-age=0">
<meta http-equiv="Pragma" content="no-cache">
<meta http-equiv="Expires" content="0">
<title>GOG Sing-Box Launcher</title>
<link rel="icon" type="image/svg+xml" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 64 64'%3E%3Ccircle cx='32' cy='32' r='30' fill='%23f28c28'/%3E%3Ctext x='32' y='39' text-anchor='middle' font-family='Arial,sans-serif' font-size='20' font-weight='700' fill='%23000000'%3EGOG%3C/text%3E%3C/svg%3E">
<style>
  :root{
    --bg:#eef1f6; --card:#f8fafc; --text:#1f2937; --muted:#5f6b7a; --line:#d9e0ea;
    --blue:#4774ca; --blue-hover:#3e66b5; --green:#56ad79; --green-hover:#4b9c6b; --red:#c65252; --red-hover:#b54747;
    --danger-soft:#fff1f2; --danger-soft-text:#991b1b; --surface:#ffffff; --surface-soft:#f3f6fb; --shadow:0 6px 18px rgba(20,33,61,.06);
    --radius:18px;
  }
  *{box-sizing:border-box}
  body{
    margin:0;
    padding:22px;
    min-height:100vh;
    background:linear-gradient(160deg,#f4f6fb 0%,#eaedf4 100%);
    font-family:"Manrope","Segoe UI","Trebuchet MS",sans-serif;
    color:var(--text);
    position:relative;
    overflow-x:hidden;
    text-rendering:optimizeLegibility;
    -webkit-font-smoothing:antialiased
  }
  button,input,select,textarea{font:inherit}
  .bg-orb{
    position:fixed; z-index:0; border-radius:999px; filter:blur(42px); opacity:.34; pointer-events:none
  }
  .orb-a{width:320px;height:320px;background:#9ab8ff;top:-120px;left:-90px}
  .orb-b{width:280px;height:280px;background:#a3e7c2;top:170px;right:-90px}
  .wrap{position:relative;z-index:1;width:min(1240px,94vw);margin:0 auto;display:flex;flex-direction:column;gap:14px}
  .card{
    background:rgba(248,250,252,.9);
    border:1px solid var(--line);
    border-radius:var(--radius);
    padding:18px;
    box-shadow:var(--shadow)
  }
  .header-card{
    display:flex;
    justify-content:space-between;
    align-items:flex-start;
    gap:18px;
    padding:20px
  }
  .header-main{min-width:240px}
  h1{margin:4px 0 0;font-size:42px;line-height:1}
  h2{margin:0 0 12px;font-size:28px;line-height:1.08}
  .dashboard-grid{
    display:grid;
    grid-template-columns:1.45fr .95fr;
    gap:12px;
    align-items:start
  }
  .col{display:flex;flex-direction:column;gap:12px;min-width:0}
  .status-stack{display:flex;flex-direction:column;gap:8px;align-items:flex-end;min-width:0}
  .status-strip{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}
  .status-meta{text-align:right;max-width:620px}
  .pill,.badge{
    display:inline-flex; align-items:center; gap:8px; padding:8px 12px; border-radius:999px;
    min-height:34px; font-size:13px; font-weight:800; border:1px solid var(--line); background:var(--surface); color:#7f1d1d; white-space:nowrap
  }
  .pill.ok,.badge.ok{background:#e8f8ef;border-color:#b9e5c9;color:#166534;box-shadow:0 4px 12px rgba(34,197,94,.08)}
  .pill.subtle,.badge.subtle{background:#ffffff;border-color:#d7dfeb;color:#334155;font-weight:700}
  .mode{margin:0;font-size:12px;color:#4b5563}
  .statusline{margin:6px 0 0;font-size:13px;color:var(--muted);min-height:18px;white-space:pre-wrap}
  .hint{display:block;color:var(--muted);font-size:12px;line-height:1.5}
  .row{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:start}
  .grow{min-width:0}
  input[type="text"],textarea.text-input{
    width:100%;
    border:1px solid #cfd8e4;
    border-radius:12px;
    padding:12px 14px;
    font-size:15px;
    color:#1e293b;
    background:#fff;
    outline:none
  }
  input[type="text"]:focus,textarea.text-input:focus{border-color:#8fb1ff;box-shadow:0 0 0 4px rgba(71,116,202,.15)}
  textarea.text-input{min-height:88px;line-height:1.45;resize:vertical}
  button{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    width:auto;
    border:0;
    border-radius:12px;
    padding:12px 14px;
    font-size:15px;
    font-weight:800;
    cursor:pointer;
    line-height:1.2;
    transition:background-color .15s ease,filter .15s ease,transform .15s ease;
    -webkit-appearance:none;
    appearance:none
  }
  button:hover{filter:brightness(.98)}
  button:disabled{cursor:not-allowed;opacity:.7;filter:none}
  #clearBtn,#loadBtn,#prepareRefilterBtn,.actions button{width:100%}
  .btn-blue{background:var(--blue);color:#fff}
  .btn-blue:hover{background:var(--blue-hover)}
  .btn-green{background:var(--green);color:#fff}
  .btn-green:hover{background:var(--green-hover)}
  .btn-red{background:var(--red);color:#fff}
  .btn-red:hover{background:var(--red-hover)}
  .btn-gray,.btn-ghost{background:#eef2f7;color:#17202d}
  .btn-danger-soft{background:var(--danger-soft);color:var(--danger-soft-text)}
  .btn-ghost.small,.btn-gray.small{padding:10px 12px;font-size:13px}
  .section-card{padding:18px}
  .card-title-row{display:flex;justify-content:space-between;align-items:center;gap:12px}
  .tag{
    display:inline-flex;align-items:center;justify-content:center;min-height:32px;padding:6px 12px;border-radius:999px;
    background:#eef2f7;color:#334155;font-size:12px;font-weight:700;border:1px solid #d9e0ea
  }
  .tag.soft{background:#f6f8fb;color:#516070}
  .route-grid{display:grid;gap:10px}
  .route-tile{
    display:grid;
    grid-template-columns:auto 1fr auto;
    gap:12px;
    align-items:flex-start;
    padding:14px;
    border:1px solid #d6deea;
    border-radius:14px;
    background:#ffffff;
    text-align:left
  }
  .route-tile.active{background:#eef8f2;border-color:#b9e5c9}
  .route-icon{
    width:42px;height:42px;border-radius:12px;background:#edf2ff;color:#274690;
    display:inline-flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;flex:0 0 auto
  }
  .route-body{display:flex;flex-direction:column;gap:4px;min-width:0}
  .route-body strong{font-size:15px}
  .route-state{font-size:12px;color:#5f6b7a;font-weight:700;white-space:nowrap}
  .hidden-rule{display:none}
  .refilter-tools{margin-top:12px;display:flex;flex-direction:column;gap:8px}
  .checks.compact label{
    display:flex;align-items:flex-start;gap:10px;font-weight:500;margin:0 0 12px
  }
  .checks.compact label:last-child{margin-bottom:0}
  .checks.compact input{margin-top:2px;flex:0 0 auto}
  .server-toolbar{display:flex;flex-wrap:wrap;gap:8px;align-items:center;justify-content:flex-start;margin-bottom:10px}
  .server-toolbar .tag{margin-left:auto}
  #serverList{
    padding:12px;
    background:rgba(243,246,251,.9);
    border:1px dashed #cdd8e7;
    border-radius:14px;
    min-height:88px;
    max-height:360px;
    overflow:auto
  }
  .server-empty{color:#6b7280;font-size:14px}
  .server-item{
    display:flex;align-items:flex-start;gap:10px;margin:0 0 10px;padding:10px 12px;border-radius:12px;
    border:1px solid transparent;background:#fff;transition:.15s ease
  }
  .server-item:last-child{margin-bottom:0}
  .server-item.active{background:#ecfdf5;border-color:#bbf7d0}
  .server-item input{margin-top:3px;flex:0 0 auto}
  .server-meta{display:flex;align-items:flex-start;gap:10px;min-width:0}
  .server-dot{
    width:10px;height:10px;border-radius:999px;background:#cbd5e1;box-shadow:0 0 0 2px rgba(203,213,225,.35);
    flex:0 0 auto;margin-top:4px
  }
  .server-dot.active{background:#16a34a;box-shadow:0 0 0 4px rgba(22,163,74,.14)}
  .server-title-line{display:flex;align-items:center;gap:6px;flex-wrap:wrap;min-width:0}
  .server-name{word-break:break-word;font-size:14px;color:#1f2937}
  .server-protocol{
    display:inline-flex;align-items:center;justify-content:center;
    padding:2px 7px;border-radius:999px;border:1px solid #cfd9e8;
    background:#f4f7fb;color:#45556d;font-size:11px;font-weight:800;
    line-height:1.2;white-space:nowrap;letter-spacing:.01em
  }
  .actions{display:grid;grid-template-columns:1fr;gap:10px}
  .actions.single{grid-template-columns:1fr}
  .log-card{padding:18px}
  .log-card.main-log-card{min-height:430px}
  .log-actions{display:flex;align-items:center;justify-content:space-between;gap:12px}
  .log-tools{display:flex;gap:8px;align-items:center}
  .logbox{
    margin-top:12px;padding:12px;border:1px solid var(--line);border-radius:12px;background:#0b1220;color:#dbeafe;
    font-family:ui-monospace,SFMono-Regular,Menlo,Monaco,Consolas,"Liberation Mono","Courier New",monospace;
    font-size:12px;line-height:1.48;max-height:260px;overflow:auto;white-space:pre-wrap
  }
  .main-log-card .logbox{min-height:330px;max-height:520px}
  .log-card.collapsed .logbox{display:none}
  .mini{font-size:12px;color:var(--muted);margin-top:10px}
  #applyBtn.btn.primary{
    background:var(--blue);
    border:1px solid #3f69b8;
    color:#fff;
  }
  #applyBtn.btn.primary:hover{background:var(--blue-hover)}
  #powerBtn.btn.success{
    background:var(--green);
    border:1px solid #489a69;
    color:#fff;
  }
  #powerBtn.btn.success:hover{background:var(--green-hover)}
  #powerBtn.btn.danger{
    background:var(--red);
    border:1px solid #a84545;
    color:#fff;
  }
  #powerBtn.btn.danger:hover{background:var(--red-hover)}
  body[data-ui-mode="dark"]{
    --line:#2e3b4c;
    --text:#ecf2f8;
    --muted:#a6b3c4;
    --blue:#3f7488;
    --blue-hover:#376679;
    --green:#3f8d6b;
    --green-hover:#36785c;
    --red:#b75d58;
    --red-hover:#a85651;
    --danger-soft:#2a2325;
    --danger-soft-text:#f2c8c8;
    --surface:#172130;
    --surface-soft:#141f2c;
    --shadow:0 8px 22px rgba(0,0,0,.35);
    background:linear-gradient(160deg,#0f141b 0%,#111922 100%);
  }
  body[data-ui-mode="dark"] .orb-a{background:#46607a;opacity:.26}
  body[data-ui-mode="dark"] .orb-b{background:#3f6b58;opacity:.24}
  body[data-ui-mode="dark"] .card{background:rgba(21,29,39,.94);border-color:#2c3a4c}
  body[data-ui-mode="dark"] h1,
  body[data-ui-mode="dark"] h2,
  body[data-ui-mode="dark"] .server-name,
  body[data-ui-mode="dark"] .route-body strong,
  body[data-ui-mode="dark"] .theme-label,
  body[data-ui-mode="dark"] .statusline,
  body[data-ui-mode="dark"] .mode,
  body[data-ui-mode="dark"] .hint,
  body[data-ui-mode="dark"] .mini,
  body[data-ui-mode="dark"] .k,
  body[data-ui-mode="dark"] .v{color:#edf4ff}
  body[data-ui-mode="dark"] input[type="text"],body[data-ui-mode="dark"] textarea.text-input{background:#131d2a;border-color:#314458;color:#eaf2ff}
  body[data-ui-mode="dark"] input[type="text"]::placeholder,body[data-ui-mode="dark"] textarea.text-input::placeholder{color:#8ea2bc}
  body[data-ui-mode="dark"] input[type="text"]:focus,body[data-ui-mode="dark"] textarea.text-input:focus{outline:2px solid #2f7269;border-color:#4e9b90;box-shadow:none}
  .theme-picker{margin-top:8px;display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap}
  .theme-label{font-size:12px;color:#5f6b7a;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
  .theme-toggle{display:inline-flex;align-items:center;gap:4px;background:#eef2f8;border:1px solid #d7dfec;border-radius:10px;padding:3px}
  body[data-ui-mode="dark"] .theme-toggle{background:#16212f;border-color:#33465c}
  .theme-btn{border:1px solid transparent;background:transparent;color:#3b4a62;border-radius:8px;padding:6px 10px;font-size:12px;font-weight:800;cursor:pointer}
  body[data-ui-mode="dark"] .theme-btn{color:#c4d2e3}
  .theme-btn.active{background:#fff;border-color:#c9d4e8;color:#22324d;box-shadow:0 1px 2px rgba(25,35,57,.08)}
  body[data-ui-mode="dark"] .theme-btn.active{background:#2a394b;border-color:#4f6d86;color:#eef5ff;box-shadow:none}
  .mini-stats{margin-top:8px;display:grid;grid-template-columns:repeat(3,1fr);gap:8px}
  .stat-chip{border:1px solid #d6dfec;border-radius:12px;background:#fff;padding:8px;text-align:center}
  body[data-ui-mode="dark"] .stat-chip{background:#172130;border-color:#33465d}
  .dependency-actions{margin-top:12px;display:grid;grid-template-columns:1fr 1fr;gap:10px}
  .dependency-export-box{
    margin-top:10px;padding:10px 12px;border:1px dashed #c7d5e8;border-radius:14px;background:#f7fafd;
    display:none;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap
  }
  body[data-ui-mode="dark"] .dependency-export-box{background:#182331;border-color:#3b4f66}
  .dependency-export-box.visible{display:flex}
  .dependency-export-summary{font-size:12px;color:#516070;line-height:1.5;flex:1 1 260px}
  body[data-ui-mode="dark"] .dependency-export-summary{color:#d7e5f6}
  .dependency-list{display:grid;gap:10px;margin-top:12px}
  .dependency-card{
    border:1px solid #d6dfec;
    border-radius:14px;
    background:#fff;
    padding:12px
  }
  body[data-ui-mode="dark"] .dependency-card{background:#15212e;border-color:#314357}
  .dependency-head{display:flex;justify-content:space-between;align-items:flex-start;gap:10px}
  .dependency-title{font-size:15px;font-weight:800;color:#1f2937}
  body[data-ui-mode="dark"] .dependency-title{color:#edf4ff}
  .dependency-subtitle{font-size:12px;color:#6b7280;margin-top:3px}
  body[data-ui-mode="dark"] .dependency-subtitle{color:#9fb0c4}
  .dependency-summary{display:flex;flex-wrap:wrap;gap:6px;justify-content:flex-end}
  .dependency-chip{
    display:inline-flex;align-items:center;gap:6px;padding:5px 8px;border-radius:999px;
    border:1px solid #d8e0eb;background:#f5f7fb;color:#334155;font-size:12px;font-weight:700
  }
  body[data-ui-mode="dark"] .dependency-chip{background:#1d2a3a;border-color:#3b516a;color:#e6eef8}
  .dependency-chip.probation{background:#fff7e6;border-color:#efcc72;color:#8a6116}
  .dependency-chip.suggested{background:#ecfdf5;border-color:#9adeba;color:#166534}
  .dependency-chip.accepted{background:#ecfdf5;border-color:#8bd0a8;color:#166534}
  .dependency-chip.rejected{background:#fff1f2;border-color:#f0a7ae;color:#991b1b}
  body[data-ui-mode="dark"] .dependency-chip.probation{background:#3a3018;border-color:#a88a49;color:#f0d287}
  body[data-ui-mode="dark"] .dependency-chip.suggested{background:#163226;border-color:#4f8f70;color:#b9ebcf}
  body[data-ui-mode="dark"] .dependency-chip.accepted{background:#163226;border-color:#4f8f70;color:#b9ebcf}
  body[data-ui-mode="dark"] .dependency-chip.rejected{background:#3a2024;border-color:#9e5f66;color:#f1b8bf}
  .dependency-section{margin-top:12px}
  .dependency-section-title{font-size:12px;font-weight:800;letter-spacing:.04em;text-transform:uppercase;color:#607086;margin-bottom:8px}
  body[data-ui-mode="dark"] .dependency-section-title{color:#9fb0c4}
  .dependency-candidates{display:grid;gap:8px;margin-top:10px}
  .dependency-domain{
    display:flex;align-items:center;justify-content:space-between;gap:10px;flex-wrap:wrap;padding:9px 10px;border-radius:12px;
    background:#eef3f9;border:1px solid #d7e0eb;color:#223046;font-size:12px;font-weight:700
  }
  body[data-ui-mode="dark"] .dependency-domain{background:#1b2838;border-color:#3a516a;color:#edf4ff}
  .dependency-domain-main{display:flex;align-items:center;gap:8px;flex-wrap:wrap;min-width:0}
  .dependency-domain-state{
    display:inline-flex;align-items:center;justify-content:center;padding:2px 6px;border-radius:999px;
    background:#fff;border:1px solid #d7deea;color:#41536b;font-size:11px;font-weight:800
  }
  body[data-ui-mode="dark"] .dependency-domain-state{background:#263445;border-color:#48627c;color:#edf5ff}
  .dependency-domain-state.probation{background:#fff7e6;border-color:#efcc72;color:#8a6116}
  .dependency-domain-state.suggested{background:#ecfdf5;border-color:#9adeba;color:#166534}
  .dependency-domain-state.accepted{background:#ecfdf5;border-color:#8bd0a8;color:#166534}
  .dependency-domain-state.rejected{background:#fff1f2;border-color:#f0a7ae;color:#991b1b}
  body[data-ui-mode="dark"] .dependency-domain-state.probation{background:#3a3018;border-color:#a88a49;color:#f0d287}
  body[data-ui-mode="dark"] .dependency-domain-state.suggested{background:#163226;border-color:#4f8f70;color:#b9ebcf}
  body[data-ui-mode="dark"] .dependency-domain-state.accepted{background:#163226;border-color:#4f8f70;color:#b9ebcf}
  body[data-ui-mode="dark"] .dependency-domain-state.rejected{background:#3a2024;border-color:#9e5f66;color:#f1b8bf}
  .dependency-meta{font-size:11px;color:#6b7280}
  body[data-ui-mode="dark"] .dependency-meta{color:#a7b6c8}
  .dependency-domain-actions{display:flex;align-items:center;gap:6px;margin-left:auto}
  .dependency-action-btn{
    display:inline-flex;align-items:center;justify-content:center;padding:5px 8px;border-radius:999px;
    border:1px solid #d7deea;background:#fff;color:#334155;font-size:11px;font-weight:800;cursor:pointer
  }
  .dependency-action-btn:hover{filter:brightness(.98)}
  .dependency-action-btn:disabled{opacity:.55;cursor:default}
  .dependency-action-btn.accept{background:#ecfdf5;border-color:#8bd0a8;color:#166534}
  .dependency-action-btn.reject{background:#fff1f2;border-color:#f0a7ae;color:#991b1b}
  .dependency-action-btn.clear{background:#f8fafc;border-color:#d7deea;color:#475569}
  body[data-ui-mode="dark"] .dependency-action-btn{background:#233244;border-color:#48627c;color:#edf5ff}
  body[data-ui-mode="dark"] .dependency-action-btn.accept{background:#163226;border-color:#4f8f70;color:#b9ebcf}
  body[data-ui-mode="dark"] .dependency-action-btn.reject{background:#3a2024;border-color:#9e5f66;color:#f1b8bf}
  body[data-ui-mode="dark"] .dependency-action-btn.clear{background:#253447;border-color:#48627c;color:#dce8f6}
  .dependency-empty{font-size:13px;color:#6b7280}
  body[data-ui-mode="dark"] .dependency-empty{color:#a7b6c8}
  .update-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px}
  .update-field{background:#f8fafc;border:1px solid #d9e1ec;border-radius:12px;padding:10px}
  body[data-ui-mode="dark"] .update-field{background:#162231;border-color:#30445a}
  .update-field .k{display:block;font-size:11px;text-transform:uppercase;letter-spacing:.04em;color:#64748b;font-weight:800}
  body[data-ui-mode="dark"] .update-field .k{color:#9fb0c4}
  .update-field .v{display:block;margin-top:4px;font-size:13px;color:#1f2937;font-weight:800;word-break:break-word}
  body[data-ui-mode="dark"] .update-field .v{color:#edf4ff}
  .update-actions{margin-top:12px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px}
  .update-message{margin-top:10px;font-size:12px;color:#607086;line-height:1.45}
  .update-message.error{color:#b42318}
  .operator-hidden{display:none!important}
  body[data-ui-mode="dark"] .update-message{color:#a7b6c8}
  body[data-ui-mode="dark"] .update-message.error{color:#fca5a5}
  .k{display:block;font-size:12px;color:var(--muted)}
  .v{font-size:13px;font-weight:800}
  .actions{grid-template-columns:1fr;gap:10px}
  .actions .btn-blue,.actions .btn-red,.actions .btn-green{width:100%}
  .server-toolbar{margin-bottom:12px}
  #serverList{display:grid;gap:10px}
  .server-item{margin:0;padding:10px 12px;min-height:46px;line-height:1.25;border:1px solid #d6dfec;background:#fff;border-radius:12px;display:grid;grid-template-columns:1fr auto;align-items:center;gap:8px;transition:border-color .15s ease,box-shadow .15s ease,transform .12s ease}
  .server-item:hover{border-color:#c6d4e8;transform:translateY(-1px)}
  body[data-ui-mode="dark"] .server-item{background:#141f2c;border-color:#314357}
  body[data-ui-mode="dark"] .server-item:hover{border-color:#3d5570}
  .server-item input{order:2;margin:0;accent-color:#3f69b8}
  body[data-ui-mode="dark"] .server-item input{accent-color:#4f9d88}
  body[data-ui-mode="dark"] #serverList{
    background:#1a2431;
    border-color:#34485f;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.02)
  }
  .server-item.active{background:#edf8ef;border-color:#b8e1c5;box-shadow:0 0 0 2px rgba(47,173,99,.12)}
  body[data-ui-mode="dark"] .server-item.active{background:#153127;border-color:#3a7156;box-shadow:0 0 0 2px rgba(79,157,136,.22)}
  .server-meta{align-items:center}
  .server-dot{background:#3c82f6;box-shadow:none;margin-top:0}
  body[data-ui-mode="dark"] .server-dot{background:#7489a1}
  .server-dot.active,.server-item.active .server-dot{background:#2fad63;box-shadow:0 0 0 4px rgba(22,163,74,.14)}
  .route-grid{grid-template-columns:repeat(2,minmax(0,1fr))}
  .route-tile{border:1px solid #d5ddec;background:#fff;min-height:132px;align-content:start;transition:border-color .15s ease,box-shadow .15s ease,transform .12s ease}
  .route-tile:hover{transform:translateY(-1px)}
  body[data-ui-mode="dark"] .route-tile{background:#15212e;border-color:#304458}
  .route-tile.active{border-color:#8aa9e8;box-shadow:0 0 0 2px rgba(61,113,206,.09);background:#f5f9ff}
  body[data-ui-mode="dark"] .route-tile.active{border-color:#4f9d88;box-shadow:0 0 0 2px rgba(79,157,136,.22);background:#17332e}
  .route-tile.featured.active{border-color:#edcb57;background:#fffcf0;box-shadow:0 0 0 2px rgba(225,191,77,.16)}
  body[data-ui-mode="dark"] .route-tile.featured.active{border-color:#b49650;background:#312915;box-shadow:0 0 0 2px rgba(180,150,80,.2)}
  .route-icon{border-radius:999px;background:linear-gradient(180deg,#7eb4ff 0%,#5f96ee 100%);color:#fff}
  body[data-ui-mode="dark"] .route-icon{background:linear-gradient(180deg,#5f7a93 0%,#46607a 100%)}
  .route-body strong{display:block;font-size:17px;line-height:1.12;margin-bottom:2px}
  .route-body>span{display:block;font-size:14px;color:#2f3a4e;line-height:1.35}
  body[data-ui-mode="dark"] .route-body>span{color:#d4ddea}
  .route-state{align-self:end;font-size:12px;font-weight:800;color:#2f6ed5}
  body[data-ui-mode="dark"] .route-state{color:#74c9ae}
  .route-tile:not(.active) .route-state{color:#8190a8}
  body[data-ui-mode="dark"] .route-tile:not(.active) .route-state{color:#9aaabd}
  .manual-domains{margin-top:12px;border-top:1px solid #d6dfec;padding-top:10px}
  body[data-ui-mode="dark"] .manual-domains{border-top-color:#33475e}
  .manual-domains.is-disabled{opacity:.9}
  .manual-domains-list{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px;min-height:20px}
  .manual-domain-empty{font-size:12px;color:#6b7280}
  .manual-domain-chip{
    display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;
    background:#eef2f7;border:1px solid #d9e0ea;color:#334155;font-size:12px;font-weight:700
  }
  .manual-domain-remove{
    width:20px;height:20px;padding:0;border-radius:999px;background:#dde6f4;color:#5b6473;
    font-size:14px;font-weight:800;line-height:1;flex:0 0 auto
  }
  .manual-domain-remove:hover{background:#d0d9e6;filter:none}
  .server-name{display:block;line-height:1.25}
  .server-protocol{background:#eef5fb;border-color:#cfe0f0;color:#40546d}
  body[data-ui-mode="dark"] .server-protocol{background:#1f3043;border-color:#405a73;color:#dcecff}
  .log-actions{display:inline-flex;align-items:center;justify-content:flex-end;gap:8px;flex-wrap:wrap}
  .log-toggle-btn{display:inline-flex;align-items:center;gap:6px}
  .log-toggle-arrow{display:inline-block;width:10px;text-align:center;font-weight:800}
  .tag.soft{background:#f1f4fa;color:#5a6680;border-color:#dde4f0}
  body[data-ui-mode="dark"] .tag{background:#202c3d;color:#d9e6f6;border-color:#3a516b}
  body[data-ui-mode="dark"] .tag.soft{background:#1a2737;color:#bdc9d8;border-color:#334a62}
  body[data-ui-mode="dark"] .btn-ghost,
  body[data-ui-mode="dark"] .btn-gray{
    background:#1f2b3b;
    color:#e7f0fb;
    border:1px solid #3a516a
  }
  body[data-ui-mode="dark"] .btn-ghost:hover,
  body[data-ui-mode="dark"] .btn-gray:hover{background:#243245}
  body[data-ui-mode="dark"] .manual-domain-chip{background:#1b2838;border-color:#34506a;color:#e7f1fb}
  body[data-ui-mode="dark"] .manual-domain-remove{background:#243346;color:#f0b6b6}
  body[data-ui-mode="dark"] .manual-domain-remove:hover{background:#2b3d54}
  body[data-ui-mode="dark"] .logbox{background:#0f1721;border-color:#30445b;color:#d6e3f5}
  body[data-ui-mode="dark"] .pill.subtle,body[data-ui-mode="dark"] .badge.subtle{background:#1d2938;border-color:#41576f;color:#eef6ff}
  body[data-ui-mode="dark"] #applyBtn.btn.primary{background:#3f7488;border-color:#4e8aa0}
  body[data-ui-mode="dark"] #powerBtn.btn.success{background:#3f8d6b;border-color:#458f6f}
  body[data-ui-mode="dark"] #powerBtn.btn.danger{background:#b75d58;border-color:#974e49}
  @media (max-width:980px){
    .dashboard-grid{grid-template-columns:1fr}
    .status-stack,.status-meta{text-align:left;align-items:flex-start}
    .status-strip{justify-content:flex-start}
  }
  @media (max-width:760px){
    body{padding:14px}
    .wrap{width:min(100%,96vw)}
    .header-card{padding:16px;flex-direction:column}
    h1{font-size:34px}
    h2{font-size:24px}
    .row{grid-template-columns:1fr}
    .theme-picker{flex-direction:column;align-items:flex-start}
    .theme-toggle{width:100%}
    .theme-btn{flex:1 1 auto;text-align:center}
    .log-actions{justify-content:flex-start}
  }
  @media (max-width:520px){
    .mini-stats{grid-template-columns:1fr;gap:6px}
    .stat-chip{text-align:left;display:flex;justify-content:space-between;align-items:center;padding:9px 10px}
    .dependency-actions{grid-template-columns:1fr}
    .update-grid{grid-template-columns:1fr}
    .update-actions{grid-template-columns:1fr}
    .dependency-head{flex-direction:column}
    .dependency-summary{justify-content:flex-start}
    .dependency-domain-actions{margin-left:0;width:100%;justify-content:flex-start}
  }
</style>
</head>
<body data-ui-mode="white">
<div class="bg-orb orb-a"></div>
<div class="bg-orb orb-b"></div>
<div class="wrap">
  <header class="card header-card">
    <div class="header-main">
      <h1>GOG Sing-Box Launcher</h1>
    </div>
    <div class="status-stack">
      <div class="status-strip">
        <span id="topStatus" class="pill">● Остановлен</span>
        <span id="activeNodeBadge" class="pill subtle">Активный узел: -</span>
      </div>
      <div class="status-meta">
        <div id="modeLine" class="mode"></div>
        <div id="statusLine" class="statusline"></div>
      </div>
    </div>
  </header>

  <div class="dashboard-grid">
    <div class="col">
      <section class="card section-card">
        <h2 data-i18n="subscription.title">Источник серверов (URL или Share Links)</h2>
        <span class="hint" data-i18n="subscription.hint">Вставьте HTTP/HTTPS-подписку или одну/несколько строк vless://, trojan://, hy2:// или hysteria2://, затем загрузите сервера, выберите узлы и запустите сервис.</span>
        <div class="row" style="margin-top:10px">
          <div class="grow"><textarea id="subUrl" class="text-input" placeholder="https://... или vless:// / trojan:// / hy2:// ..." data-i18n-placeholder="subscription.placeholder" spellcheck="false"></textarea></div>
          <div style="width:180px"><button class="btn-red" id="clearBtn" onclick="clearConfig()" data-i18n="buttons.full_reset">Полный сброс</button></div>
        </div>
        <div style="margin-top:12px"><button id="loadBtn" class="btn-blue" onclick="loadServers()" data-i18n="buttons.load_servers">Загрузить и проверить сервера</button></div>
      </section>

      <section class="card section-card">
        <h2 data-i18n="routing.title">Правила маршрутизации</h2>
        <div class="route-grid">
          <button type="button" class="route-tile active featured" data-rule="rule_refilter" aria-pressed="true" onclick="toggleRuleTile('rule_refilter')">
            <span class="route-icon">.srs</span>
            <span class="route-body">
              <strong data-i18n="routing.refilter.title">Re:filter</strong>
              <span data-i18n="routing.refilter.desc">Проксировать домены из полной базы `.srs`.</span>
            </span>
            <span class="route-state">Активно</span>
          </button>
          <button type="button" class="route-tile active" data-rule="rule_proxy_ai" aria-pressed="true" onclick="toggleRuleTile('rule_proxy_ai')">
            <span class="route-icon">🌐</span>
            <span class="route-body">
              <strong data-i18n="routing.foreign.title">Иностранные сервисы</strong>
              <span data-i18n="routing.foreign.desc">Проксировать AI и зарубежные сервисы: ChatGPT, Gemini, Claude, Canva, Netflix.</span>
            </span>
            <span class="route-state">Активно</span>
          </button>
          <button type="button" class="route-tile active" data-rule="rule_direct_ru" aria-pressed="true" onclick="toggleRuleTile('rule_direct_ru')">
            <span class="route-icon">🇷🇺</span>
            <span class="route-body">
              <strong data-i18n="routing.ru_services.title">Российские сервисы</strong>
              <span data-i18n="routing.ru_services.desc">Пускать напрямую важные российские сервисы: банки, маркетплейсы, госуслуги, VK, Apple.</span>
            </span>
            <span class="route-state">Активно</span>
          </button>
          <button type="button" class="route-tile active" data-rule="rule_force_ru_suffix" aria-pressed="true" onclick="toggleRuleTile('rule_force_ru_suffix')">
            <span class="route-icon">🚩</span>
            <span class="route-body">
              <strong data-i18n="routing.ru_suffix.title">Всё RU — напрямую</strong>
              <span data-i18n="routing.ru_suffix.desc">.ru / .рф / .su</span>
            </span>
            <span class="route-state">Активно</span>
          </button>
        </div>
        <input class="hidden-rule" type="checkbox" id="rule_refilter" checked>
        <input class="hidden-rule" type="checkbox" id="rule_proxy_ai" checked>
        <input class="hidden-rule" type="checkbox" id="rule_direct_ru" checked>
        <input class="hidden-rule" type="checkbox" id="rule_force_ru_suffix" checked>
        <div class="refilter-tools">
          <button type="button" class="btn-ghost" id="prepareRefilterBtn" onclick="prepareRefilter()">Подготовить базы Re:filter</button>
          <span class="hint" id="prepareRefilterHint">Нужно только для первого запуска или если базы ещё не были скачаны на этот роутер.</span>
          <span class="hint" data-i18n="routing.full_vpn_hint">Если снять все 4 опции, включится полный VPN: весь внешний трафик через AUTO-BALANCE.</span>
        </div>
      </section>

      <section class="card section-card">
        <h2 data-i18n="cloud.title">Свой облачный список доменов</h2>
        <span class="hint" data-i18n="cloud.hint">Необязательно. TXT, по одному домену в строке. Эти домены будут идти через прокси.</span>
        <div style="margin-top:10px"><input id="customUrl" type="text" placeholder="https://raw.githubusercontent.com/.../list.txt"></div>
        <div class="manual-domains">
          <span class="hint" data-i18n="cloud.manual_hint">Дополнительно к TXT URL. Эти домены начнут идти через прокси после «Применить изменения».</span>
          <div class="row compact" style="margin-top:8px">
            <div class="grow"><input id="manualDomainInput" type="text" placeholder="например: 2ip.ru" data-i18n-placeholder="cloud.manual_placeholder"></div>
            <div style="width:140px"><button type="button" class="btn-gray" id="addManualDomainBtn" onclick="addManualDomain()" data-i18n="buttons.add_domain">Добавить</button></div>
          </div>
          <div id="manualDomainsList" class="manual-domains-list"></div>
        </div>
      </section>

      <section class="card log-card main-log-card" id="logCard">
        <div class="card-title-row">
          <h2 data-i18n="log.title">Журнал событий</h2>
          <div class="log-actions">
            <span class="tag soft" id="autoRefreshBadge" data-i18n="log.autorefresh">автообновление</span>
            <button id="logToggleBtn" class="btn-ghost small log-toggle-btn" type="button" onclick="toggleLogCollapse()" aria-expanded="true">
              <span id="logToggleArrow" class="log-toggle-arrow" aria-hidden="true">▾</span>
              <span id="logToggleLabel">Свернуть</span>
            </button>
          </div>
        </div>
        <pre id="logBox" class="logbox">Журнал пока пуст.</pre>
        <div class="mini">v1.91-sb1137</div>
      </section>
    </div>

    <div class="col">
      <aside class="card section-card">
        <div class="card-title-row">
          <h2 data-i18n="servers.title">Выбор сервера</h2>
          <span id="serversCountTag" class="tag">0 узлов</span>
        </div>
        <div class="server-toolbar">
          <button type="button" class="btn-ghost small" id="selectAllBtn" onclick="selectAllServers()" data-i18n="buttons.select_all">Выбрать все</button>
          <button type="button" class="btn-ghost small" id="clearAllBtn" onclick="clearServerSelection()" data-i18n="buttons.clear_all">Снять все</button>
          <span id="selectedCountTag" class="tag soft">Выбрано: 0</span>
        </div>
        <div id="serverList"><div class="server-empty" data-i18n="servers.empty_initial">Список серверов пока не загружен.</div></div>
      </aside>

      <section class="card section-card action-card">
        <div class="actions" id="actionsBox">
          <button id="applyBtn" class="btn primary" style="display:none" onclick="applyChanges()" data-i18n="buttons.apply">Применить изменения</button>
          <button id="powerBtn" class="btn success" onclick="powerAction()">Включить</button>
        </div>
      </section>

      <aside class="card section-card">
        <h2 data-i18n="settings.title">Настройки</h2>
        <div class="checks compact">
          <label><input type="checkbox" id="auto_update" checked> <span data-i18n="settings.auto_update">Автообновление подписки и списков каждые 10 часов.</span></label>
          <label><input type="checkbox" id="use_auto_redirect" checked> <span data-i18n="settings.auto_redirect">⚡ Ускоренный режим <b>auto_redirect</b>: если он не заведётся, скрипт сам откатится на совместимый; перебалансировка узлов идёт каждые 3 минуты.</span></label>
        </div>
        <div class="theme-picker">
          <span class="theme-label" data-i18n="settings.language_label">Язык интерфейса</span>
          <div class="theme-toggle" role="group" aria-label="Language switcher">
            <button id="langRuBtn" type="button" class="theme-btn active" onclick="setLanguage('ru', true)" data-i18n="buttons.lang_ru">Русский</button>
            <button id="langEnBtn" type="button" class="theme-btn" onclick="setLanguage('en', true)" data-i18n="buttons.lang_en">English</button>
          </div>
        </div>
        <div class="theme-picker">
          <span class="theme-label" data-i18n="settings.ui_mode_label">Режим интерфейса</span>
          <div class="theme-toggle" role="group" aria-label="UI mode switcher">
            <button id="modeWhiteBtn" type="button" class="theme-btn active" onclick="setUiMode('white', true)" data-i18n="buttons.mode_white">White mode</button>
            <button id="modeDarkBtn" type="button" class="theme-btn" onclick="setUiMode('dark', true)" data-i18n="buttons.mode_dark">Dark mode</button>
          </div>
        </div>
        <div class="mini-stats">
          <div class="stat-chip">
            <span class="k" data-i18n="stats.profile">Профиль</span>
            <span id="profileValue" class="v">split</span>
          </div>
          <div class="stat-chip">
            <span class="k" data-i18n="stats.route">Route</span>
            <span id="routeValue" class="v">direct</span>
          </div>
          <div class="stat-chip">
            <span class="k" data-i18n="stats.dns">DNS</span>
            <span id="dnsValue" class="v">local-dns</span>
          </div>
        </div>
      </aside>

      <aside class="card section-card">
        <div class="card-title-row">
          <h2 data-i18n="updates.title">Обновления приложения</h2>
          <span id="updateStateTag" class="tag soft">не проверялось</span>
        </div>
        <span class="hint operator-hidden" data-i18n="updates.hint">Проверка идёт через Cloudflare Pages manifest. Недоступный сервер обновлений не влияет на работу GOG.</span>
        <div class="checks compact">
          <label><input type="checkbox" id="app_auto_update_check" checked onchange="saveUpdateSettings()"> <span data-i18n="updates.auto_check">Проверять обновления автоматически раз в 7 дней.</span></label>
          <label><input type="checkbox" id="app_auto_update_install" onchange="saveUpdateSettings()"> <span data-i18n="updates.auto_install">Устанавливать проверенные обновления автоматически.</span></label>
        </div>
        <div class="operator-hidden" style="margin-top:10px"><input id="updateManifestUrl" type="text" placeholder="https://.../stable/update.json" onchange="saveUpdateSettings()"></div>
        <div class="update-grid">
          <div class="update-field"><span class="k" data-i18n="updates.current">Текущая версия</span><span id="updateCurrentVersion" class="v">v1.91-sb1137</span></div>
          <div class="update-field"><span class="k" data-i18n="updates.available">Доступная версия</span><span id="updateAvailableVersion" class="v">-</span></div>
          <div class="update-field"><span class="k" data-i18n="updates.last_check">Последняя проверка</span><span id="updateLastCheck" class="v">-</span></div>
          <div class="update-field"><span class="k" data-i18n="updates.signature">Подпись</span><span id="updateSignatureState" class="v">-</span></div>
        </div>
        <div class="update-actions">
          <button type="button" class="btn-blue" id="updateCheckBtn" onclick="checkApplicationUpdate()" data-i18n="updates.check_now">Проверить сейчас</button>
          <button type="button" class="btn-gray" id="updateInstallBtn" onclick="installApplicationUpdate()" data-i18n="updates.install">Установить</button>
          <button type="button" class="btn-gray" id="updateRollbackBtn" onclick="rollbackApplicationUpdate()" data-i18n="updates.rollback">Откатить</button>
        </div>
        <div id="updateMessage" class="update-message"></div>
      </aside>

      <aside class="card section-card">
        <div class="card-title-row">
          <h2 data-i18n="deps.title">Зависимости сервисов</h2>
          <span id="depsLastScanTag" class="tag soft" data-i18n="deps.last_scan_never">Скан ещё не запускался</span>
        </div>
          <span class="hint" data-i18n="deps.hint">Review-only: здесь видны найденные зависимости и ручные review-решения, но routing всё ещё не меняется автоматически.</span>
        <div class="dependency-actions">
          <button type="button" class="btn-blue" id="dependencyScanBtn" onclick="scanDependencies()" data-i18n="deps.scan">Сканировать зависимости</button>
          <button type="button" class="btn-gray" id="dependencyResetBtn" onclick="resetDependencies()" data-i18n="deps.reset">Сбросить review</button>
        </div>
        <div id="dependencyExportBox" class="dependency-export-box">
          <div id="dependencyExportSummary" class="dependency-export-summary"></div>
          <button type="button" class="btn-ghost small" id="dependencyExportAcceptedBtn" onclick="exportAcceptedDependencies()" data-i18n="deps.export_all">Экспортировать принятые</button>
        </div>
        <div id="dependencyList" class="dependency-list">
          <div class="dependency-empty" data-i18n="deps.empty">Кандидатов пока нет.</div>
        </div>
      </aside>
    </div>
  </div>
</div>

<script>
const state = {
  running: false,
  selected: new Set(),
  loadedServers: [],
  manualDomains: [],
  activeServerId: '',
  effectiveMode: '',
  routingProfile: 'split',
  routeFinal: 'direct',
  dnsFinal: 'local-dns',
  uiMode: 'white',
  lang: 'ru',
  effectiveAutoRedirect: null,
  refilterBootstrapReady: false,
  refilterActiveReady: false,
  manualStop: false,
  logCollapsed: false,
  stoppedStreak: 0,
  logRequestSeq: 0,
  lastLogText: '',
  dependencyData: { last_scan_epoch: 0, profiles: [] },
  updateData: null,
  draftTouched: {}
};

const I18N = {
  ru: {
    'subscription.title': 'Источник серверов (URL или Share Links)',
    'subscription.hint': 'Вставьте HTTP/HTTPS-подписку или одну/несколько строк vless://, trojan://, hy2:// или hysteria2://, затем загрузите сервера, выберите узлы и запустите сервис.',
    'subscription.placeholder': 'https://... или vless:// / trojan:// / hy2:// ...',
    'routing.title': 'Правила маршрутизации',
    'routing.refilter.title': 'Re:filter',
    'routing.refilter.desc': 'Проксировать домены из полной базы `.srs`.',
    'routing.foreign.title': 'Иностранные сервисы',
    'routing.foreign.desc': 'Проксировать AI и зарубежные сервисы: ChatGPT, Gemini, Claude, Canva, Netflix.',
    'routing.ru_services.title': 'Российские сервисы',
    'routing.ru_services.desc': 'Пускать напрямую важные российские сервисы: банки, маркетплейсы, госуслуги, VK, Apple.',
    'routing.ru_suffix.title': 'Всё RU — напрямую',
    'routing.ru_suffix.desc': '.ru / .рф / .su',
    'routing.full_vpn_hint': 'Если снять все 4 опции, включится полный VPN: весь внешний трафик через AUTO-BALANCE.',
    'cloud.title': 'Свой облачный список доменов',
    'cloud.hint': 'Необязательно. TXT, по одному домену в строке. Эти домены будут идти через прокси.',
    'cloud.manual_hint': 'Дополнительно к TXT URL. Эти домены начнут идти через прокси после «Применить изменения».',
    'cloud.manual_placeholder': 'например: 2ip.ru',
    'cloud.manual_empty': 'Список пока пуст.',
    'servers.title': 'Выбор сервера',
    'servers.empty_initial': 'Список серверов пока не загружен.',
    'servers.empty_none': 'Сервера не найдены.',
    'settings.title': 'Настройки',
    'settings.auto_update': 'Автообновление подписки и списков каждые 10 часов.',
    'settings.auto_redirect': '⚡ Ускоренный режим auto_redirect: если он не заведётся, скрипт сам откатится на совместимый; перебалансировка узлов идёт каждые 3 минуты.',
    'settings.language_label': 'Язык интерфейса',
    'settings.ui_mode_label': 'Режим интерфейса',
    'deps.title': 'Зависимости сервисов',
    'deps.hint': 'Review-only: здесь видны найденные зависимости и ручные review-решения. Routing меняется только если Вы явно экспортируете принятые домены в локальный список и затем нажмёте «Применить изменения».',
    'deps.scan': 'Сканировать зависимости',
    'deps.reset': 'Сбросить review',
    'deps.export_all': 'Экспортировать принятые',
    'deps.empty': 'Кандидатов пока нет.',
    'deps.last_scan_never': 'Скан ещё не запускался',
    'deps.last_scan_at': 'Последний скан: {time}',
    'deps.state.candidate': 'candidate',
    'deps.state.probation': 'probation',
    'deps.state.suggested': 'suggested',
    'deps.state.accepted': 'accepted',
    'deps.state.rejected': 'rejected',
    'deps.count.candidate': 'candidate: {count}',
    'deps.count.probation': 'probation: {count}',
    'deps.count.suggested': 'suggested: {count}',
    'deps.count.accepted': 'accepted: {count}',
    'deps.count.rejected': 'rejected: {count}',
    'deps.section.pending': 'Ожидают review',
    'deps.section.accepted': 'Приняты',
    'deps.section.rejected': 'Отклонены',
    'deps.action.accept': 'Принять',
    'deps.action.reject': 'Отклонить',
    'deps.action.clear': 'Снять решение',
    'deps.export_summary_ready': 'Принятых доменов: {accepted}. Уже в локальном списке: {present}. Готово к экспорту: {exportable}.',
    'deps.export_summary_done': 'Все принятые домены уже находятся в локальном списке. Если нужно применить их к routing, нажмите «Применить изменения».',
    'updates.title': 'Обновления приложения',
    'updates.hint': 'Проверка идёт через Cloudflare Pages manifest. Недоступный сервер обновлений не влияет на работу GOG.',
    'updates.auto_check': 'Проверять обновления автоматически раз в 7 дней.',
    'updates.auto_install': 'Устанавливать проверенные обновления автоматически.',
    'updates.current': 'Текущая версия',
    'updates.available': 'Доступная версия',
    'updates.last_check': 'Последняя проверка',
    'updates.signature': 'Подпись',
    'updates.check_now': 'Проверить сейчас',
    'updates.install': 'Установить',
    'updates.rollback': 'Откатить',
    'updates.state.idle': 'не проверялось',
    'updates.state.no_update': 'обновлений нет',
    'updates.state.update_available': 'найдено',
    'updates.state.update_unavailable': 'сервер недоступен',
    'updates.state.invalid_manifest': 'ошибка manifest',
    'updates.state.incompatible': 'несовместимо',
    'updates.state.rollback_done': 'откат выполнен',
    'updates.state.package_downloaded': 'пакет скачан',
    'stats.profile': 'Профиль',
    'stats.route': 'Route',
    'stats.dns': 'DNS',
    'buttons.full_reset': 'Полный сброс',
    'buttons.load_servers': 'Загрузить и проверить сервера',
    'buttons.add_domain': 'Добавить',
    'buttons.remove_domain': 'Удалить домен',
    'buttons.select_all': 'Выбрать все',
    'buttons.clear_all': 'Снять все',
    'buttons.lang_ru': 'Русский',
    'buttons.lang_en': 'English',
    'buttons.mode_white': 'White mode',
    'buttons.mode_dark': 'Dark mode',
    'buttons.apply': 'Применить изменения',
    'buttons.loading_servers': 'Проверяю источник...',
    'buttons.applying': 'Применяю...',
    'buttons.preparing_refilter': 'Готовлю базы...',
    'buttons.power_turning_on': 'Включаю...',
    'actions.power_on': 'Включить',
    'actions.power_off': 'Выключить',
    'counts.nodes': '{count} узлов',
    'counts.selected': 'Выбрано: {count}',
    'route.state.active': 'Активно',
    'route.state.inactive': 'Отключено',
    'log.title': 'Журнал событий',
    'log.autorefresh': 'автообновление',
    'log.hide': 'Свернуть',
    'log.expand': 'Развернуть',
    'log.empty': 'Журнал пока пуст.',
    'status.running_dot': '● Работает',
    'status.stopped_dot': '● Остановлен',
    'status.active_node': 'Активный узел: {node}',
    'status.mode_prefix': 'Режим: {mode}',
    'status.running_line': 'GOG Sing-Box Launcher работает · {mode} · профиль: {profile} · route={route}, dns={dns}',
    'status.active_segment': 'активная нода: {node}',
    'status.manual_stop': 'GOG Sing-Box Launcher остановлен вручную. Автозапуск и cron отключены.',
    'status.stopped': 'GOG Sing-Box Launcher остановлен.',
    'messages.enter_subscription': 'Сначала вставьте URL подписки или одну/несколько строк vless://, trojan://, hy2:// или hysteria2://.',
    'messages.load_servers_loading': 'Загружаю список серверов...',
    'messages.load_servers_none': 'Сервера не найдены.',
    'messages.load_servers_found_selected': 'Найдено серверов: {total}. Сохранено выбранных узлов: {selected}.',
    'messages.load_servers_found_pick': 'Найдено серверов: {total}. Выберите нужные узлы галочками.',
    'messages.load_servers_error': 'Не удалось загрузить источник серверов: {error}',
    'messages.subscription_empty': 'Источник серверов пуст. Вставьте URL подписки или share-link строки и загрузите сервера.',
    'messages.need_server': 'Нужно выбрать хотя бы один сервер.',
    'messages.full_vpn_confirm': 'Сняты все правила маршрутизации. Будет включён полный VPN: почти весь внешний трафик пойдёт через прокси. Продолжить?',
    'messages.start_cancelled': 'Запуск отменён.',
    'messages.building_config': 'Собираю и проверяю конфиг...',
    'messages.config_applied': 'Конфиг применён.',
    'messages.full_vpn_enabled': 'Активен режим полного VPN.',
    'messages.apply_error': 'Ошибка применения: {error}',
    'messages.stop_progress': 'Останавливаю сервис...',
    'messages.stop_pending': 'Команда stop отправлена, но сервис ещё не подтвердил остановку.',
    'messages.stop_sent': 'Команда остановки отправлена.',
    'messages.refilter_preparing': 'Подготавливаю локальные базы Re:filter...',
    'messages.refilter_ready': 'Базы Re:filter подготовлены.',
    'messages.refilter_prepare_error': 'Не удалось подготовить базы Re:filter: {error}',
    'messages.power_wait_running': 'Конфиг применён, но UI не увидел running. Проверьте статус через 2–3 секунды.',
    'messages.generic_error': 'Ошибка: {error}',
    'messages.clear_confirm': 'Полностью удалить настройки, кеш списков и остановить сервис?',
    'messages.clear_progress': 'Удаляю конфигурацию...',
    'messages.clear_deleted': 'Конфигурация удалена.',
    'messages.clear_error': 'Ошибка удаления: {error}',
    'messages.manual_domain_invalid': 'Введите корректный домен, например 2ip.ru.',
    'messages.manual_domain_duplicate': 'Домен {domain} уже добавлен.',
    'messages.manual_domain_added': 'Домен {domain} добавлен в локальный список. Нажмите «Применить изменения».',
    'messages.manual_domain_removed': 'Домен {domain} удалён из локального списка.',
    'messages.logs_error': 'Не удалось загрузить журнал: {error}',
    'messages.init_error': 'Ошибка инициализации UI: {error}',
    'messages.deps_scanning': 'Сканирую зависимые домены...',
    'messages.deps_scan_done': 'Скан зависимостей завершён.',
    'messages.deps_scan_error': 'Не удалось выполнить скан зависимостей: {error}',
    'messages.deps_reset_confirm': 'Сбросить все накопленные кандидаты и ручные review-решения зависимостей?',
    'messages.deps_reset_done': 'Состояние review зависимостей очищено.',
    'messages.deps_reset_error': 'Не удалось сбросить состояние review зависимостей: {error}',
    'messages.deps_accept_done': 'Домен {domain} принят в review-память сервиса {service}.',
    'messages.deps_reject_done': 'Домен {domain} отклонён в review-памяти сервиса {service}.',
    'messages.deps_clear_done': 'Решение review для домена {domain} очищено.',
    'messages.deps_review_error': 'Не удалось обновить review-решение для домена {domain}: {error}',
    'messages.deps_export_done': 'Экспортировано доменов: {count}. Они добавлены в локальный список доменов. Теперь нажмите «Применить изменения».',
    'messages.deps_export_none': 'Новых принятых доменов для экспорта сейчас нет.',
    'messages.update_checking': 'Проверяю manifest обновлений...',
    'messages.update_settings_saved': 'Настройки обновлений сохранены.',
    'messages.update_settings_error': 'Не удалось сохранить настройки обновлений: {error}',
    'messages.update_check_done': 'Проверка обновлений завершена.',
    'messages.update_check_error': 'Не удалось проверить обновления: {error}',
    'messages.update_install_confirm': 'Установить найденное обновление? Перед установкой будет нужен backup/verify path.',
    'messages.update_install_error': 'Установка обновления недоступна или завершилась ошибкой: {error}',
    'messages.update_rollback_confirm': 'Откатить последнее обновление из backup-а?',
    'messages.update_rollback_error': 'Откат недоступен или завершился ошибкой: {error}',
    'refilter.button.ready': '✓ Базы Re:filter готовы',
    'refilter.hint.ready': 'Локальные active и bootstrap базы уже готовы. Дополнительная подготовка не нужна.',
    'refilter.button.prepare': 'Подготовить базы Re:filter',
    'refilter.hint.running': 'Если GitHub напрямую недоступен, кнопка попробует подтянуть базы сейчас; при живом tun0 это может пройти через текущий прокси-путь.',
    'refilter.hint.stopped': 'Нужно только для первого запуска или если базы ещё не были скачаны на этот роутер.'
  },
  en: {
    'subscription.title': 'Server Source (URL or Share Links)',
    'subscription.hint': 'Paste an HTTP/HTTPS subscription or one or more vless://, trojan://, hy2://, or hysteria2:// lines, then load the servers, choose the nodes, and start the service.',
    'subscription.placeholder': 'https://... or vless:// / trojan:// / hy2:// ...',
    'routing.title': 'Routing Rules',
    'routing.refilter.title': 'Re:filter',
    'routing.refilter.desc': 'Proxy domains from the full `.srs` base.',
    'routing.foreign.title': 'Foreign services',
    'routing.foreign.desc': 'Proxy AI and foreign services: ChatGPT, Gemini, Claude, Canva, Netflix.',
    'routing.ru_services.title': 'Russian services',
    'routing.ru_services.desc': 'Route key Russian services directly: banks, marketplaces, gosuslugi, VK, Apple.',
    'routing.ru_suffix.title': 'All RU — direct',
    'routing.ru_suffix.desc': '.ru / .рф / .su',
    'routing.full_vpn_hint': 'If you disable all 4 options, full VPN will be enabled: all external traffic goes through AUTO-BALANCE.',
    'cloud.title': 'Cloud Domain List',
    'cloud.hint': 'Optional. TXT, one domain per line. These domains will be proxied.',
    'cloud.manual_hint': 'Optional. These domains are added on top of the TXT URL and start using the proxy after `Apply changes`.',
    'cloud.manual_placeholder': 'example: 2ip.ru',
    'cloud.manual_empty': 'List is empty.',
    'servers.title': 'Server Overview',
    'servers.empty_initial': 'Server list is not loaded yet.',
    'servers.empty_none': 'No servers found.',
    'settings.title': 'Auto Settings',
    'settings.auto_update': 'Auto-update subscription and lists every 10 hours.',
    'settings.auto_redirect': '⚡ Fast auto_redirect mode: if it fails to start, the script falls back to compatibility mode; node rebalance runs every 3 minutes.',
    'settings.language_label': 'Interface language',
    'settings.ui_mode_label': 'Interface mode',
    'deps.title': 'Service Dependencies',
    'deps.hint': 'Review-only: learned dependencies and manual review decisions are shown here. Routing changes only if You explicitly export accepted domains into the local domain list and then click `Apply changes`.',
    'deps.scan': 'Scan dependencies',
    'deps.reset': 'Reset review',
    'deps.export_all': 'Export accepted',
    'deps.empty': 'No candidates yet.',
    'deps.last_scan_never': 'Scan has not run yet',
    'deps.last_scan_at': 'Last scan: {time}',
    'deps.state.candidate': 'candidate',
    'deps.state.probation': 'probation',
    'deps.state.suggested': 'suggested',
    'deps.state.accepted': 'accepted',
    'deps.state.rejected': 'rejected',
    'deps.count.candidate': 'candidate: {count}',
    'deps.count.probation': 'probation: {count}',
    'deps.count.suggested': 'suggested: {count}',
    'deps.count.accepted': 'accepted: {count}',
    'deps.count.rejected': 'rejected: {count}',
    'deps.section.pending': 'Pending review',
    'deps.section.accepted': 'Accepted',
    'deps.section.rejected': 'Rejected',
    'deps.action.accept': 'Accept',
    'deps.action.reject': 'Reject',
    'deps.action.clear': 'Clear',
    'deps.export_summary_ready': 'Accepted domains: {accepted}. Already in the local list: {present}. Ready to export: {exportable}.',
    'deps.export_summary_done': 'All accepted domains are already in the local domain list. Click `Apply changes` if You want them to affect routing.',
    'updates.title': 'Application Updates',
    'updates.hint': 'Checks use the Cloudflare Pages manifest. If the update server is unavailable, GOG runtime is not affected.',
    'updates.auto_check': 'Check for updates automatically every 7 days.',
    'updates.auto_install': 'Install verified updates automatically.',
    'updates.current': 'Current version',
    'updates.available': 'Available version',
    'updates.last_check': 'Last check',
    'updates.signature': 'Signature',
    'updates.check_now': 'Check now',
    'updates.install': 'Install',
    'updates.rollback': 'Rollback',
    'updates.state.idle': 'not checked',
    'updates.state.no_update': 'no update',
    'updates.state.update_available': 'available',
    'updates.state.update_unavailable': 'server unavailable',
    'updates.state.invalid_manifest': 'manifest error',
    'updates.state.incompatible': 'incompatible',
    'updates.state.rollback_done': 'rollback done',
    'updates.state.package_downloaded': 'package downloaded',
    'stats.profile': 'Profile',
    'stats.route': 'Route',
    'stats.dns': 'DNS',
    'buttons.full_reset': 'Full reset',
    'buttons.load_servers': 'Load and verify servers',
    'buttons.add_domain': 'Add',
    'buttons.remove_domain': 'Remove domain',
    'buttons.select_all': 'Select all',
    'buttons.clear_all': 'Clear all',
    'buttons.lang_ru': 'Russian',
    'buttons.lang_en': 'English',
    'buttons.mode_white': 'White mode',
    'buttons.mode_dark': 'Dark mode',
    'buttons.apply': 'Apply changes',
    'buttons.loading_servers': 'Checking source...',
    'buttons.applying': 'Applying...',
    'buttons.preparing_refilter': 'Preparing bases...',
    'buttons.power_turning_on': 'Starting...',
    'actions.power_on': 'Enable',
    'actions.power_off': 'Disable',
    'counts.nodes': '{count} nodes',
    'counts.selected': 'Selected: {count}',
    'route.state.active': 'Enabled',
    'route.state.inactive': 'Disabled',
    'log.title': 'Event Log',
    'log.autorefresh': 'auto refresh',
    'log.hide': 'Collapse',
    'log.expand': 'Expand',
    'log.empty': 'Log is empty.',
    'status.running_dot': '● Running',
    'status.stopped_dot': '● Stopped',
    'status.active_node': 'Active node: {node}',
    'status.mode_prefix': 'Mode: {mode}',
    'status.running_line': 'GOG Sing-Box Launcher running · {mode} · profile: {profile} · route={route}, dns={dns}',
    'status.active_segment': 'active node: {node}',
    'status.manual_stop': 'GOG Sing-Box Launcher was stopped manually. Autostart and cron are disabled.',
    'status.stopped': 'GOG Sing-Box Launcher is stopped.',
    'messages.enter_subscription': 'Please paste a subscription URL or one or more vless://, trojan://, hy2://, or hysteria2:// lines first.',
    'messages.load_servers_loading': 'Loading server list...',
    'messages.load_servers_none': 'No servers found.',
    'messages.load_servers_found_selected': 'Servers found: {total}. Preserved selected nodes: {selected}.',
    'messages.load_servers_found_pick': 'Servers found: {total}. Select the required nodes.',
    'messages.load_servers_error': 'Failed to load the server source: {error}',
    'messages.subscription_empty': 'The server source is empty. Paste a URL or supported share-link lines and load the servers.',
    'messages.need_server': 'Please select at least one server.',
    'messages.full_vpn_confirm': 'All routing rules are disabled. Full VPN will be enabled and most external traffic will go through the proxy. Continue?',
    'messages.start_cancelled': 'Start cancelled.',
    'messages.building_config': 'Building and checking config...',
    'messages.config_applied': 'Config applied.',
    'messages.full_vpn_enabled': 'Full VPN mode is active.',
    'messages.apply_error': 'Apply failed: {error}',
    'messages.stop_progress': 'Stopping service...',
    'messages.stop_pending': 'Stop command was sent, but the service has not confirmed the stop yet.',
    'messages.stop_sent': 'Stop command sent.',
    'messages.refilter_preparing': 'Preparing local Re:filter bases...',
    'messages.refilter_ready': 'Re:filter bases are ready.',
    'messages.refilter_prepare_error': 'Failed to prepare Re:filter bases: {error}',
    'messages.power_wait_running': 'The config was applied, but the UI did not observe running yet. Check the status again in 2–3 seconds.',
    'messages.generic_error': 'Error: {error}',
    'messages.clear_confirm': 'Remove all settings, clear caches, and stop the service?',
    'messages.clear_progress': 'Removing configuration...',
    'messages.clear_deleted': 'Configuration removed.',
    'messages.clear_error': 'Delete failed: {error}',
    'messages.manual_domain_invalid': 'Enter a valid domain, for example 2ip.ru.',
    'messages.manual_domain_duplicate': 'Domain {domain} is already added.',
    'messages.manual_domain_added': 'Domain {domain} was added to the local list. Click `Apply changes`.',
    'messages.manual_domain_removed': 'Domain {domain} was removed from the local list.',
    'messages.logs_error': 'Failed to load log: {error}',
    'messages.init_error': 'UI initialization error: {error}',
    'messages.deps_scanning': 'Scanning dependent domains...',
    'messages.deps_scan_done': 'Dependency scan completed.',
    'messages.deps_scan_error': 'Dependency scan failed: {error}',
    'messages.deps_reset_confirm': 'Reset all learned dependency candidates and manual review decisions?',
    'messages.deps_reset_done': 'Dependency review state cleared.',
    'messages.deps_reset_error': 'Failed to reset dependency review state: {error}',
    'messages.deps_accept_done': 'Domain {domain} accepted in review memory for {service}.',
    'messages.deps_reject_done': 'Domain {domain} rejected in review memory for {service}.',
    'messages.deps_clear_done': 'Review decision cleared for domain {domain}.',
    'messages.deps_review_error': 'Failed to update dependency review for {domain}: {error}',
    'messages.deps_export_done': 'Exported domains: {count}. They were added to the local domain list. Now click `Apply changes`.',
    'messages.deps_export_none': 'There are no new accepted domains to export right now.',
    'messages.update_checking': 'Checking update manifest...',
    'messages.update_settings_saved': 'Update settings saved.',
    'messages.update_settings_error': 'Failed to save update settings: {error}',
    'messages.update_check_done': 'Update check completed.',
    'messages.update_check_error': 'Failed to check updates: {error}',
    'messages.update_install_confirm': 'Install the available update? Backup/verify path must be ready first.',
    'messages.update_install_error': 'Update install is unavailable or failed: {error}',
    'messages.update_rollback_confirm': 'Rollback the last update from backup?',
    'messages.update_rollback_error': 'Rollback is unavailable or failed: {error}',
    'refilter.button.ready': '✓ Re:filter bases are ready',
    'refilter.hint.ready': 'Local active and bootstrap bases are already prepared. No extra preparation is needed.',
    'refilter.button.prepare': 'Prepare Re:filter bases',
    'refilter.hint.running': 'If GitHub is unreachable directly, the button will try to pull the bases now; with a live tun0 this may still work over the current proxy path.',
    'refilter.hint.stopped': 'Use this only for the first start or if the bases have not yet been downloaded to this router.'
  }
};

const DRAFT_FIELD_IDS = ['subUrl','customUrl','auto_update','use_auto_redirect','rule_refilter','rule_proxy_ai','rule_direct_ru','rule_force_ru_suffix'];
let draftBindingsDone = false;
let uiPollersStarted = false;
let uiBootstrapPromise = null;

function escText(s) {
  return String(s ?? "");
}

function t(key, vars = {}) {
  const pack = I18N[state.lang] || I18N.ru;
  let text = pack[key] || I18N.ru[key] || key;
  for (const [name, value] of Object.entries(vars)) {
    text = text.split('{' + name + '}').join(String(value));
  }
  return text;
}

function fallbackErrorText() {
  return state.lang === 'en' ? 'unknown error' : 'неизвестная ошибка';
}

function applyTranslations() {
  for (const node of document.querySelectorAll('[data-i18n]')) {
    const key = node.getAttribute('data-i18n');
    if (!key) continue;
    node.textContent = t(key);
  }
  for (const node of document.querySelectorAll('[data-i18n-placeholder]')) {
    const key = node.getAttribute('data-i18n-placeholder');
    if (!key) continue;
    node.setAttribute('placeholder', t(key));
  }
  document.documentElement.lang = state.lang;
  updateLogToggleUI();
  renderManualDomains();
  renderDependencyProfiles();
  renderUpdatePanel();
}

function syncLanguageButtons() {
  const ruBtn = document.getElementById('langRuBtn');
  const enBtn = document.getElementById('langEnBtn');
  if (ruBtn) ruBtn.classList.toggle('active', state.lang === 'ru');
  if (enBtn) enBtn.classList.toggle('active', state.lang === 'en');
}

function setLanguage(lang, save = true) {
  state.lang = lang === 'en' ? 'en' : 'ru';
  applyTranslations();
  syncLanguageButtons();
  updateRouteTilesFromInputs();
  updateServerCounters();
  updateActiveNodeBadge();
  updateRefilterButton();
  updateButtons();
  if (!state.loadedServers.length) {
    const emptyNode = document.querySelector('#serverList .server-empty');
    if (emptyNode) {
      const current = (emptyNode.textContent || '').trim();
      const isNotFound = current === I18N.ru['servers.empty_none'] || current === I18N.en['servers.empty_none'];
      emptyNode.textContent = isNotFound ? t('servers.empty_none') : t('servers.empty_initial');
    }
  }
  if (save) {
    try {
      localStorage.setItem('gog_ui_lang_v1', state.lang);
    } catch (_) {}
  }
  setTimeout(() => {
    refreshStatus();
    loadLogs();
  }, 0);
}

function initLanguage() {
  let lang = 'ru';
  try {
    lang = localStorage.getItem('gog_ui_lang_v1') || 'ru';
  } catch (_) {
    lang = 'ru';
  }
  setLanguage(lang, false);
}

function getLoadedServerName(serverId) {
  if (!serverId) return '';
  const item = state.loadedServers.find((entry) => entry.id === serverId);
  return item ? escText(item.name || item.id) : '';
}

function updateActiveNodeBadge() {
  const badge = document.getElementById('activeNodeBadge');
  if (!badge) return;
  const activeName = getLoadedServerName(state.activeServerId);
  badge.textContent = t('status.active_node', {node: activeName || '-'});
}

function updateServerCounters() {
  const serversCountTag = document.getElementById('serversCountTag');
  const selectedCountTag = document.getElementById('selectedCountTag');
  let renderedSelected = 0;
  if (state.loadedServers.length) {
    const loadedIds = new Set(state.loadedServers.map((item) => item.id));
    for (const id of state.selected) {
      if (loadedIds.has(id)) renderedSelected += 1;
    }
  }
  if (serversCountTag) {
    serversCountTag.textContent = t('counts.nodes', {count: state.loadedServers.length});
  }
  if (selectedCountTag) {
    selectedCountTag.textContent = t('counts.selected', {count: renderedSelected});
  }
}

function setRouteTileState(tile, checked) {
  if (!tile) return;
  tile.classList.toggle('active', !!checked);
  tile.setAttribute('aria-pressed', checked ? 'true' : 'false');
  const stateNode = tile.querySelector('.route-state');
  if (stateNode) {
    stateNode.textContent = checked ? t('route.state.active') : t('route.state.inactive');
  }
}

function updateRouteTilesFromInputs() {
  for (const tile of document.querySelectorAll('.route-tile')) {
    const ruleId = tile.dataset.rule;
    const input = document.getElementById(ruleId);
    setRouteTileState(tile, !!(input && input.checked));
  }
}

function toggleRuleTile(ruleId) {
  const input = document.getElementById(ruleId);
  if (!input) return;
  input.checked = !input.checked;
  updateRouteTilesFromInputs();
  saveUiDraft();
}

function selectAllServers() {
  if (!state.loadedServers.length) return;
  state.selected = new Set(state.loadedServers.map((item) => item.id));
  renderServers(state.loadedServers);
  saveUiDraft();
}

function clearServerSelection() {
  state.selected = new Set();
  renderServers(state.loadedServers);
  saveUiDraft();
}

function normalizeManualDomain(value) {
  let next = (value || '').trim().toLowerCase();
  if (!next) return '';
  next = next.replace(/^[a-z][a-z0-9+.-]*:\/\//i, '');
  next = next.replace(/[/?#].*$/, '');
  next = next.replace(/:\d+$/, '');
  next = next.replace(/^\*\./, '');
  next = next.replace(/^\.+|\.+$/g, '');
  const ok = /^(xn--[a-z0-9-]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)(\.(xn--[a-z0-9-]+|[a-z0-9](?:[a-z0-9-]*[a-z0-9])?))+$/i.test(next);
  return ok ? next : '';
}

function setManualDomains(domains) {
  const next = [];
  const seen = new Set();
  for (const raw of Array.isArray(domains) ? domains : []) {
    const normalized = normalizeManualDomain(raw);
    if (!normalized || seen.has(normalized)) continue;
    seen.add(normalized);
    next.push(normalized);
  }
  next.sort();
  state.manualDomains = next;
}

function renderManualDomains() {
  const box = document.getElementById('manualDomainsList');
  if (!box) return;
  box.innerHTML = '';
  setManualDomains(state.manualDomains);
  if (!state.manualDomains.length) {
    const empty = document.createElement('span');
    empty.className = 'manual-domain-empty';
    empty.textContent = t('cloud.manual_empty');
    box.appendChild(empty);
    return;
  }
  for (const domain of state.manualDomains) {
    const chip = document.createElement('span');
    chip.className = 'manual-domain-chip';

    const label = document.createElement('span');
    label.textContent = domain;

    const removeBtn = document.createElement('button');
    removeBtn.type = 'button';
    removeBtn.className = 'manual-domain-remove';
    removeBtn.textContent = '×';
    removeBtn.title = t('buttons.remove_domain');
    removeBtn.setAttribute('aria-label', t('buttons.remove_domain'));
    removeBtn.addEventListener('click', () => removeManualDomain(domain));

    chip.appendChild(label);
    chip.appendChild(removeBtn);
    box.appendChild(chip);
  }
}

function addManualDomain() {
  const input = document.getElementById('manualDomainInput');
  if (!input) return;
  const domain = normalizeManualDomain(input.value);
  if (!domain) {
    setStatusText(t('messages.manual_domain_invalid'), true);
    input.focus();
    return;
  }
  if ((state.manualDomains || []).includes(domain)) {
    setStatusText(t('messages.manual_domain_duplicate', {domain}), true);
    input.value = '';
    return;
  }
  setManualDomains([...(state.manualDomains || []), domain]);
  input.value = '';
  renderManualDomains();
  saveUiDraft();
  setStatusText(t('messages.manual_domain_added', {domain}));
}

function removeManualDomain(domain) {
  setManualDomains((state.manualDomains || []).filter((item) => item !== domain));
  renderManualDomains();
  saveUiDraft();
  setStatusText(t('messages.manual_domain_removed', {domain}));
}

function updateLogToggleUI() {
  const card = document.getElementById('logCard');
  const btn = document.getElementById('logToggleBtn');
  const arrow = document.getElementById('logToggleArrow');
  const label = document.getElementById('logToggleLabel');
  if (!card) return;
  card.classList.toggle('collapsed', !!state.logCollapsed);
  if (btn) {
    btn.setAttribute('aria-expanded', state.logCollapsed ? 'false' : 'true');
  }
  if (arrow) {
    arrow.textContent = state.logCollapsed ? '▸' : '▾';
  }
  if (label) {
    label.textContent = state.logCollapsed ? t('log.expand') : t('log.hide');
  }
}

function setLogCollapsed(collapsed) {
  state.logCollapsed = !!collapsed;
  updateLogToggleUI();
  try {
    localStorage.setItem('gog_log_collapsed', state.logCollapsed ? '1' : '0');
  } catch (_) {}
}

function initLogCollapsed() {
  try {
    state.logCollapsed = localStorage.getItem('gog_log_collapsed') === '1';
  } catch (_) {
    state.logCollapsed = false;
  }
  updateLogToggleUI();
}

function toggleLogCollapse() {
  setLogCollapsed(!state.logCollapsed);
}

function updateProfileChips() {
  const profileValue = document.getElementById('profileValue');
  const routeValue = document.getElementById('routeValue');
  const dnsValue = document.getElementById('dnsValue');
  if (profileValue) profileValue.textContent = state.routingProfile || 'split';
  if (routeValue) routeValue.textContent = state.routeFinal || 'direct';
  if (dnsValue) dnsValue.textContent = state.dnsFinal || 'local-dns';
}

function formatDependencyScanTime(epoch) {
  const value = Number(epoch || 0);
  if (!Number.isFinite(value) || value <= 0) {
    return t('deps.last_scan_never');
  }
  try {
    const formatted = new Date(value * 1000).toLocaleString(state.lang === 'ru' ? 'ru-RU' : 'en-US');
    return t('deps.last_scan_at', {time: formatted});
  } catch (_) {
    return t('deps.last_scan_never');
  }
}

function formatUpdateCheckTime(epoch) {
  const value = Number(epoch || 0);
  if (!Number.isFinite(value) || value <= 0) return '-';
  try { return new Date(value * 1000).toLocaleString(state.lang === 'ru' ? 'ru-RU' : 'en-US'); }
  catch (_) { return String(value); }
}

function updateStateLabel(stateName) {
  const key = 'updates.state.' + String(stateName || 'idle');
  const value = t(key);
  return value === key ? String(stateName || 'idle') : value;
}

function normalizeUpdateData(data) {
  const d = data && typeof data === 'object' ? data : {};
  return {
    current_version: d.current_version || 'v1.91-sb1137',
    channel: d.channel || 'stable',
    compatibility: d.compatibility || 'sb1137',
    manifest_url: d.manifest_url || 'https://gog-sing-box-launcher.pages.dev/stable/update.json',
    auto_check_enabled: d.auto_check_enabled !== false,
    auto_install_enabled: d.auto_install_enabled === true,
    update_state: d.update_state || 'idle',
    last_check_epoch: Number(d.last_check_epoch || 0),
    latest_version: d.latest_version || '',
    update_available: d.update_available === true,
    update_kind: d.update_kind || 'none',
    auto_install_allowed: d.auto_install_allowed === true,
    package_url: d.package_url || '',
    package_sha256: d.package_sha256 || '',
    package_size: Number(d.package_size || 0),
    notes_url: d.notes_url || '',
    signature_required: d.signature_required !== false,
    signature_status: d.signature_status || 'not_checked',
    message: d.message || ''
  };
}

function renderUpdatePanel() {
  const data = normalizeUpdateData(state.updateData);
  state.updateData = data;
  const byId = (id) => document.getElementById(id);
  if (byId('updateStateTag')) byId('updateStateTag').textContent = updateStateLabel(data.update_state);
  if (byId('updateCurrentVersion')) byId('updateCurrentVersion').textContent = data.current_version || '-';
  if (byId('updateAvailableVersion')) byId('updateAvailableVersion').textContent = data.latest_version || '-';
  if (byId('updateLastCheck')) byId('updateLastCheck').textContent = formatUpdateCheckTime(data.last_check_epoch);
  if (byId('updateSignatureState')) byId('updateSignatureState').textContent = data.signature_status || '-';
  const manifestInput = byId('updateManifestUrl');
  if (manifestInput && document.activeElement !== manifestInput) {
    manifestInput.value = data.manifest_url || '';
  }
  if (byId('app_auto_update_check')) byId('app_auto_update_check').checked = data.auto_check_enabled;
  if (byId('app_auto_update_install')) byId('app_auto_update_install').checked = data.auto_install_enabled;
  if (byId('updateInstallBtn')) byId('updateInstallBtn').disabled = !(data.update_available && data.signature_status === 'verified');
  const msg = byId('updateMessage');
  if (msg) {
    msg.className = 'update-message' + (['invalid_manifest','incompatible','unsupported_current_version'].includes(data.update_state) ? ' error' : '');
    msg.textContent = data.message || '';
  }
}

async function refreshUpdateStatus() {
  try {
    const data = await api('update_status');
    state.updateData = normalizeUpdateData(data);
    renderUpdatePanel();
    return state.updateData;
  } catch (_) {
    renderUpdatePanel();
    return state.updateData;
  }
}

async function saveUpdateSettings() {
  const manifestNode = document.getElementById('updateManifestUrl');
  const payload = {
    manifest_url: manifestNode ? manifestNode.value.trim() : '',
    auto_check_enabled: !!(document.getElementById('app_auto_update_check') && document.getElementById('app_auto_update_check').checked),
    auto_install_enabled: !!(document.getElementById('app_auto_update_install') && document.getElementById('app_auto_update_install').checked)
  };
  try {
    const data = await apiMutation('update_save_settings', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload) + "\n"
    });
    state.updateData = normalizeUpdateData(data);
    renderUpdatePanel();
    setStatusText(t('messages.update_settings_saved'));
  } catch (e) {
    setStatusText(t('messages.update_settings_error', {error: e.message || fallbackErrorText()}), true);
  }
}

async function checkApplicationUpdate() {
  const btn = document.getElementById('updateCheckBtn');
  if (btn) btn.disabled = true;
  setStatusText(t('messages.update_checking'));
  try {
    const data = await api('update_check');
    state.updateData = normalizeUpdateData(data);
    renderUpdatePanel();
    setStatusText((data && data.message) || t('messages.update_check_done'));
  } catch (e) {
    setStatusText(t('messages.update_check_error', {error: e.message || fallbackErrorText()}), true);
  } finally {
    if (btn) btn.disabled = false;
  }
}

async function installApplicationUpdate() {
  if (!confirm(t('messages.update_install_confirm'))) return;
  try {
    const data = await apiMutation('update_install', {method: 'POST'});
    state.updateData = normalizeUpdateData(data);
    renderUpdatePanel();
    setStatusText((data && data.message) || t('messages.update_check_done'));
  } catch (e) {
    setStatusText(t('messages.update_install_error', {error: e.message || fallbackErrorText()}), true);
  }
}

async function rollbackApplicationUpdate() {
  if (!confirm(t('messages.update_rollback_confirm'))) return;
  try {
    const data = await apiMutation('update_rollback', {method: 'POST'});
    state.updateData = normalizeUpdateData(data);
    renderUpdatePanel();
    setStatusText((data && data.message) || updateStateLabel('rollback_done'));
    await refreshStatus();
  } catch (e) {
    setStatusText(t('messages.update_rollback_error', {error: e.message || fallbackErrorText()}), true);
  }
}

function normalizeDependencyData(data) {
  return {
    last_scan_epoch: Number((data && data.last_scan_epoch) || 0),
    profiles: Array.isArray(data && data.profiles) ? data.profiles : []
  };
}

function collectAcceptedDependencyDomains(exportableOnly = false) {
  const manualSet = new Set((state.manualDomains || []).map((item) => normalizeManualDomain(item)).filter(Boolean));
  const seen = new Set();
  const all = [];
  for (const profile of Array.isArray(state.dependencyData && state.dependencyData.profiles) ? state.dependencyData.profiles : []) {
    const accepted = Array.isArray(profile && profile.accepted) ? profile.accepted : [];
    for (const item of accepted) {
      const domain = normalizeManualDomain(item && item.domain);
      if (!domain || seen.has(domain)) continue;
      seen.add(domain);
      if (exportableOnly && manualSet.has(domain)) continue;
      all.push(domain);
    }
  }
  return all;
}

function getDependencyExportSummary() {
  const acceptedDomains = collectAcceptedDependencyDomains(false);
  const exportableDomains = collectAcceptedDependencyDomains(true);
  return {
    acceptedCount: acceptedDomains.length,
    exportableCount: exportableDomains.length,
    presentCount: acceptedDomains.length - exportableDomains.length,
    exportableDomains
  };
}

function setDependencyPanelBusy(busy) {
  const value = !!busy;
  for (const id of ['dependencyScanBtn', 'dependencyResetBtn', 'dependencyExportAcceptedBtn']) {
    const node = document.getElementById(id);
    if (node) node.disabled = value;
  }
  for (const node of document.querySelectorAll('[data-dependency-review-action]')) {
    node.disabled = value;
  }
}

function appendDependencySection(card, titleKey, items, serviceId, reviewState = '') {
  if (!Array.isArray(items) || !items.length) return;

  const section = document.createElement('div');
  section.className = 'dependency-section';

  const title = document.createElement('div');
  title.className = 'dependency-section-title';
  title.textContent = t(titleKey);
  section.appendChild(title);

  const box = document.createElement('div');
  box.className = 'dependency-candidates';

  for (const item of items) {
    const row = document.createElement('div');
    row.className = 'dependency-domain';

    const main = document.createElement('div');
    main.className = 'dependency-domain-main';

    const stateName = reviewState || item.state || 'candidate';
    const stateBadge = document.createElement('span');
    stateBadge.className = 'dependency-domain-state ' + stateName;
    stateBadge.textContent = t('deps.state.' + stateName);

    const domainText = document.createElement('span');
    domainText.textContent = escText(item.domain || '-');

    const meta = document.createElement('span');
    meta.className = 'dependency-meta';
    const metaBits = [];
    if (Number(item.hits || 0) > 0) metaBits.push('hits=' + Number(item.hits || 0));
    if (item.evidence_state) metaBits.push('evidence=' + item.evidence_state);
    meta.textContent = metaBits.join(' · ');

    main.appendChild(stateBadge);
    main.appendChild(domainText);
    if (metaBits.length) main.appendChild(meta);
    row.appendChild(main);

    const actions = document.createElement('div');
    actions.className = 'dependency-domain-actions';

    const addAction = (labelKey, cls, handler, disabled = false) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'dependency-action-btn ' + cls;
      btn.textContent = t(labelKey);
      btn.disabled = !!disabled;
      btn.setAttribute('data-dependency-review-action', '1');
      btn.addEventListener('click', handler);
      actions.appendChild(btn);
    };

    addAction('deps.action.accept', 'accept', () => reviewDependencyDecision('dependency_accept', serviceId, item.domain), reviewState === 'accepted');
    addAction('deps.action.reject', 'reject', () => reviewDependencyDecision('dependency_reject', serviceId, item.domain), reviewState === 'rejected');
    if (reviewState === 'accepted' || reviewState === 'rejected') {
      addAction('deps.action.clear', 'clear', () => reviewDependencyDecision('dependency_unreview', serviceId, item.domain));
    }

    row.appendChild(actions);
    box.appendChild(row);
  }

  section.appendChild(box);
  card.appendChild(section);
}

function renderDependencyProfiles() {
  const list = document.getElementById('dependencyList');
  const badge = document.getElementById('depsLastScanTag');
  const exportBox = document.getElementById('dependencyExportBox');
  const exportSummaryNode = document.getElementById('dependencyExportSummary');
  const exportBtn = document.getElementById('dependencyExportAcceptedBtn');
  if (!list || !badge) return;

  const data = normalizeDependencyData(state.dependencyData);
  const profiles = Array.isArray(data.profiles) ? data.profiles : [];
  badge.textContent = formatDependencyScanTime(data.last_scan_epoch);

  if (exportBox && exportSummaryNode && exportBtn) {
    const exportSummary = getDependencyExportSummary();
    if (exportSummary.acceptedCount > 0) {
      exportBox.classList.add('visible');
      exportSummaryNode.textContent = exportSummary.exportableCount > 0
        ? t('deps.export_summary_ready', {
            accepted: exportSummary.acceptedCount,
            present: exportSummary.presentCount,
            exportable: exportSummary.exportableCount
          })
        : t('deps.export_summary_done');
      exportBtn.disabled = exportSummary.exportableCount <= 0;
    } else {
      exportBox.classList.remove('visible');
      exportSummaryNode.textContent = '';
      exportBtn.disabled = true;
    }
  }

  list.innerHTML = '';
  if (!profiles.length) {
    list.innerHTML = '<div class="dependency-empty">' + escText(t('deps.empty')) + '</div>';
    return;
  }

  let renderedAny = false;
  for (const profile of profiles) {
    const summary = profile && profile.summary ? profile.summary : {};
    const candidates = Array.isArray(profile && profile.candidates) ? profile.candidates : [];
    const accepted = Array.isArray(profile && profile.accepted) ? profile.accepted : [];
    const rejected = Array.isArray(profile && profile.rejected) ? profile.rejected : [];
    const total = Number(summary.candidate_count || 0) + Number(summary.probation_count || 0) + Number(summary.suggested_count || 0) + Number(summary.accepted_count || 0) + Number(summary.rejected_count || 0);
    if (!total && !candidates.length && !accepted.length && !rejected.length) {
      continue;
    }
    renderedAny = true;

    const card = document.createElement('div');
    card.className = 'dependency-card';

    const head = document.createElement('div');
    head.className = 'dependency-head';

    const titleBox = document.createElement('div');
    const title = document.createElement('div');
    title.className = 'dependency-title';
    title.textContent = escText(profile.name || profile.id || '-');
    const subtitle = document.createElement('div');
    subtitle.className = 'dependency-subtitle';
    subtitle.textContent = (profile.seeds || []).join(', ') || '-';
    titleBox.appendChild(title);
    titleBox.appendChild(subtitle);

    const summaryBox = document.createElement('div');
    summaryBox.className = 'dependency-summary';
    const chips = [
      {cls: '', text: t('deps.count.candidate', {count: Number(summary.candidate_count || 0)})},
      {cls: 'probation', text: t('deps.count.probation', {count: Number(summary.probation_count || 0)})},
      {cls: 'suggested', text: t('deps.count.suggested', {count: Number(summary.suggested_count || 0)})},
      {cls: 'accepted', text: t('deps.count.accepted', {count: Number(summary.accepted_count || 0)})},
      {cls: 'rejected', text: t('deps.count.rejected', {count: Number(summary.rejected_count || 0)})}
    ];
    for (const item of chips) {
      const chip = document.createElement('span');
      chip.className = 'dependency-chip' + (item.cls ? ' ' + item.cls : '');
      chip.textContent = item.text;
      summaryBox.appendChild(chip);
    }

    head.appendChild(titleBox);
    head.appendChild(summaryBox);
    card.appendChild(head);

    appendDependencySection(card, 'deps.section.pending', candidates, profile.id || '');
    appendDependencySection(card, 'deps.section.accepted', accepted, profile.id || '', 'accepted');
    appendDependencySection(card, 'deps.section.rejected', rejected, profile.id || '', 'rejected');

    list.appendChild(card);
  }

  if (!renderedAny) {
    list.innerHTML = '<div class="dependency-empty">' + escText(t('deps.empty')) + '</div>';
  }
}

async function refreshDependencyStatus() {
  try {
    const data = await api('dependency_status');
    state.dependencyData = normalizeDependencyData(data);
    renderDependencyProfiles();
    return data;
  } catch (_) {
    return null;
  }
}

async function reviewDependencyDecision(action, serviceId, domain) {
  const serviceName = (state.dependencyData.profiles || []).find((item) => item && item.id === serviceId)?.name || serviceId;
  setDependencyPanelBusy(true);
  try {
    const data = await apiMutation(action, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({service_id: serviceId, domain}) + "\n"
    });
    state.dependencyData = normalizeDependencyData(data);
    renderDependencyProfiles();
    if (action === 'dependency_accept') {
      setStatusText(t('messages.deps_accept_done', {domain, service: serviceName}));
    } else if (action === 'dependency_reject') {
      setStatusText(t('messages.deps_reject_done', {domain, service: serviceName}));
    } else {
      setStatusText(t('messages.deps_clear_done', {domain}));
    }
  } catch (e) {
    setStatusText(t('messages.deps_review_error', {domain, error: e.message || fallbackErrorText()}), true);
  } finally {
    setDependencyPanelBusy(false);
  }
}

async function scanDependencies() {
  setDependencyPanelBusy(true);
  setStatusText(t('messages.deps_scanning'));
  try {
    const data = await apiMutation('dependency_scan', {method: 'POST'});
    state.dependencyData = normalizeDependencyData(data);
    renderDependencyProfiles();
    setStatusText(data.message || t('messages.deps_scan_done'));
  } catch (e) {
    setStatusText(t('messages.deps_scan_error', {error: e.message || fallbackErrorText()}), true);
  } finally {
    setDependencyPanelBusy(false);
  }
}

async function resetDependencies() {
  if (!confirm(t('messages.deps_reset_confirm'))) return;
  setDependencyPanelBusy(true);
  try {
    const data = await apiMutation('dependency_reset', {method: 'POST'});
    state.dependencyData = normalizeDependencyData(data);
    renderDependencyProfiles();
    setStatusText(data.message || t('messages.deps_reset_done'));
  } catch (e) {
    setStatusText(t('messages.deps_reset_error', {error: e.message || fallbackErrorText()}), true);
  } finally {
    setDependencyPanelBusy(false);
  }
}

function exportAcceptedDependencies() {
  const exportSummary = getDependencyExportSummary();
  if (exportSummary.exportableCount <= 0) {
    setStatusText(t('messages.deps_export_none'));
    return;
  }
  setManualDomains([...(state.manualDomains || []), ...exportSummary.exportableDomains]);
  renderManualDomains();
  renderDependencyProfiles();
  saveUiDraft();
  setStatusText(t('messages.deps_export_done', {count: exportSummary.exportableCount}));
}

function applyActionButtonVisuals() {
  const applyBtn = document.getElementById('applyBtn');
  const powerBtn = document.getElementById('powerBtn');
  const dark = state.uiMode === 'dark';
  if (applyBtn && applyBtn.style.display !== 'none') {
    applyBtn.style.backgroundColor = dark ? '#3f7488' : '#4774ca';
    applyBtn.style.borderColor = dark ? '#4e8aa0' : '#3f69b8';
    applyBtn.style.color = '#ffffff';
  }
  if (powerBtn) {
    if (state.running) {
      powerBtn.style.backgroundColor = dark ? '#b75d58' : '#c65252';
      powerBtn.style.borderColor = dark ? '#974e49' : '#a84545';
      powerBtn.style.color = '#ffffff';
    } else {
      powerBtn.style.backgroundColor = dark ? '#3f8d6b' : '#56ad79';
      powerBtn.style.borderColor = dark ? '#458f6f' : '#489a69';
      powerBtn.style.color = '#ffffff';
    }
  }
}

function setUiMode(mode, save=true) {
  state.uiMode = mode === 'dark' ? 'dark' : 'white';
  document.body.setAttribute('data-ui-mode', state.uiMode);
  const whiteBtn = document.getElementById('modeWhiteBtn');
  const darkBtn = document.getElementById('modeDarkBtn');
  if (whiteBtn) whiteBtn.classList.toggle('active', state.uiMode === 'white');
  if (darkBtn) darkBtn.classList.toggle('active', state.uiMode === 'dark');
  applyActionButtonVisuals();
  if (save) {
    try {
      localStorage.setItem('gog_ui_mode_v1', state.uiMode);
    } catch (_) {}
  }
}

function initUiMode() {
  let mode = 'white';
  try {
    mode = localStorage.getItem('gog_ui_mode_v1') || 'white';
  } catch (_) {
    mode = 'white';
  }
  setUiMode(mode, false);
}

function applyServerActivityIndicators() {
  const box = document.getElementById('serverList');
  if (!box) return;
  const activeId = state.activeServerId || '';
  for (const row of box.querySelectorAll('.server-item')) {
    const isActive = !!activeId && row.dataset.serverId === activeId;
    row.classList.toggle('active', isActive);
    const dot = row.querySelector('.server-dot');
    if (dot) {
      dot.classList.toggle('active', isActive);
      dot.title = isActive ? 'Сейчас используется балансировкой' : 'Сейчас не активен';
    }
  }
  updateActiveNodeBadge();
}

function setStatusText(text, isError=false) {
  const el = document.getElementById('statusLine');
  if (!el) return;
  el.textContent = text || '';
  el.style.color = isError ? '#b91c1c' : '#6b7280';
}

function updateRefilterButton() {
  const btn = document.getElementById('prepareRefilterBtn');
  const hint = document.getElementById('prepareRefilterHint');
  if (!btn || !hint) return;

  if (state.refilterBootstrapReady && state.refilterActiveReady) {
    btn.disabled = true;
    btn.textContent = t('refilter.button.ready');
    hint.textContent = t('refilter.hint.ready');
    return;
  }

  btn.disabled = false;
  btn.textContent = t('refilter.button.prepare');
  if (state.running) {
    hint.textContent = t('refilter.hint.running');
  } else {
    hint.textContent = t('refilter.hint.stopped');
  }
}

function markDraftTouched(id, touched = true) {
  if (!id) return;
  state.draftTouched[id] = !!touched;
}

function isDraftProtected(id) {
  const el = document.getElementById(id);
  return !!(el && (document.activeElement === el || state.draftTouched[id]));
}

function setTextInputFromStoredState(id, value, source) {
  const el = document.getElementById(id);
  if (!el) return;
  if (isDraftProtected(id)) return;
  const next = String(value || '');
  if (source === 'draft' && !next) return;
  el.value = next;
}

function normalizeSourceEditorText(value) {
  return String(value || '')
    .replace(/\r/g, '')
    .split('\n')
    .map((line) => {
      let item = line.trim();
      const bullet = item.replace(/^[-*]\s*/, '');
      if (/^(https?:\/\/|vless:\/\/|trojan:\/\/|hy2:\/\/|hysteria2:\/\/)/i.test(bullet)) {
        item = bullet;
      }
      return item;
    })
    .filter(Boolean)
    .join('\n');
}

function saveUiDraft() {
  try {
    const draft = {
      subUrl: document.getElementById('subUrl').value,
      customUrl: document.getElementById('customUrl').value,
      auto_update: document.getElementById('auto_update').checked,
      use_auto_redirect: document.getElementById('use_auto_redirect').checked,
      rules: {
        refilter: document.getElementById('rule_refilter').checked,
        proxy_ai: document.getElementById('rule_proxy_ai').checked,
        direct_ru: document.getElementById('rule_direct_ru').checked,
        force_ru_suffix: document.getElementById('rule_force_ru_suffix').checked
      },
      manualDomains: Array.from(state.manualDomains || []),
      selected: Array.from(state.selected)
    };
    localStorage.setItem('gog_ui_draft_v5', JSON.stringify(draft));
  } catch (_) {}
}

function loadUiDraft() {
  try {
    const raw = localStorage.getItem('gog_ui_draft_v5');
    if (!raw) return;
    const draft = JSON.parse(raw);
    setTextInputFromStoredState('subUrl', draft.subUrl, 'draft');
    setTextInputFromStoredState('customUrl', draft.customUrl, 'draft');
    if (typeof draft.auto_update === 'boolean') document.getElementById('auto_update').checked = draft.auto_update;
    if (typeof draft.use_auto_redirect === 'boolean') document.getElementById('use_auto_redirect').checked = draft.use_auto_redirect;
    if (draft.rules) {
      document.getElementById('rule_refilter').checked = draft.rules.refilter !== false;
      document.getElementById('rule_proxy_ai').checked = draft.rules.proxy_ai !== false;
      document.getElementById('rule_direct_ru').checked = draft.rules.direct_ru !== false;
      document.getElementById('rule_force_ru_suffix').checked = draft.rules.force_ru_suffix !== false;
    }
    if (Array.isArray(draft.manualDomains)) {
      setManualDomains(draft.manualDomains);
      renderManualDomains();
    }
    if (Array.isArray(draft.selected)) {
      state.selected = new Set(draft.selected);
    }
  } catch (_) {}
}

function resetUiToDefaults() {
  state.draftTouched = {};
  document.getElementById('subUrl').value = '';
  document.getElementById('customUrl').value = '';
  const manualDomainInput = document.getElementById('manualDomainInput');
  if (manualDomainInput) manualDomainInput.value = '';
  document.getElementById('rule_refilter').checked = true;
  document.getElementById('rule_proxy_ai').checked = true;
  document.getElementById('rule_direct_ru').checked = true;
  document.getElementById('rule_force_ru_suffix').checked = true;
  document.getElementById('auto_update').checked = true;
  document.getElementById('use_auto_redirect').checked = true;
  setManualDomains([]);
  renderManualDomains();
  state.selected = new Set();
  state.loadedServers = [];
  state.activeServerId = '';
  state.lastLogText = '';
  renderServers([]);
  updateRouteTilesFromInputs();
  updateActiveNodeBadge();
}

function updateButtons() {
  const badge = document.getElementById('topStatus');
  const powerBtn = document.getElementById('powerBtn');
  const applyBtn = document.getElementById('applyBtn');
  const modeLine = document.getElementById('modeLine');
  const actionsBox = document.getElementById('actionsBox');
  if (!badge || !powerBtn || !applyBtn || !modeLine) return;

  if (state.running) {
    badge.className = 'pill ok';
    badge.textContent = t('status.running_dot');
    powerBtn.className = 'btn danger';
    powerBtn.textContent = t('actions.power_off');
    applyBtn.style.display = 'block';
    applyBtn.className = 'btn primary';
    applyBtn.textContent = t('buttons.apply');
  } else {
    badge.className = 'pill';
    badge.textContent = t('status.stopped_dot');
    powerBtn.className = 'btn success';
    powerBtn.textContent = t('actions.power_on');
    applyBtn.style.display = 'none';
  }

  if (actionsBox) {
    actionsBox.classList.toggle('single', !state.running);
  }

  if (state.effectiveMode) {
    modeLine.textContent = t('status.mode_prefix', {mode: state.effectiveMode});
  } else {
    modeLine.textContent = '';
  }
  updateProfileChips();
  updateRefilterButton();
  updateActiveNodeBadge();
  applyActionButtonVisuals();
}

function renderServers(servers) {
  state.loadedServers = Array.isArray(servers) ? servers : [];
  const embeddedActive = state.loadedServers.find((item) => item && item.active);
  if (embeddedActive) {
    state.activeServerId = embeddedActive.id || state.activeServerId;
  }
  const box = document.getElementById('serverList');
  if (!box) return;
  box.innerHTML = '';
  if (!state.loadedServers.length) {
    box.innerHTML = '<div class="server-empty">' + escText(t('servers.empty_none')) + '</div>';
    updateServerCounters();
    updateActiveNodeBadge();
    return;
  }
  for (const item of state.loadedServers) {
    const row = document.createElement('label');
    row.className = 'server-item';
    row.dataset.serverId = item.id || '';

    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.value = item.id;
    cb.checked = state.selected.has(item.id);
    cb.addEventListener('change', () => {
      if (cb.checked) state.selected.add(item.id);
      else state.selected.delete(item.id);
      updateServerCounters();
      saveUiDraft();
    });

    const meta = document.createElement('span');
    meta.className = 'server-meta';

    const dot = document.createElement('span');
    dot.className = 'server-dot';

    const text = document.createElement('span');
    text.className = 'server-name';
    text.textContent = escText(item.name || item.id);

    const titleLine = document.createElement('span');
    titleLine.className = 'server-title-line';
    titleLine.appendChild(text);

    const protocolLabel = String(item.protocol_label || item.protocol || '').trim();
    if (protocolLabel) {
      const protocol = document.createElement('span');
      protocol.className = 'server-protocol';
      protocol.textContent = protocolLabel;
      titleLine.appendChild(protocol);
    }

    meta.appendChild(dot);
    meta.appendChild(titleLine);
    row.appendChild(cb);
    row.appendChild(meta);
    box.appendChild(row);
  }
  updateServerCounters();
  applyServerActivityIndicators();
}

async function api(action, options = {}) {
  const url = '/cgi-bin/myproxy_api?action=' + encodeURIComponent(action) + '&_=' + Date.now();
  const fetchOptions = Object.assign({cache: 'no-store', headers: {'Cache-Control': 'no-cache'}}, options || {});
  if (options && options.headers) {
    fetchOptions.headers = Object.assign({'Cache-Control': 'no-cache'}, options.headers);
  }
  const res = await fetch(url, fetchOptions);
  let data = null;
  try { data = await res.json(); } catch (_) {}
  if (!res.ok) {
    throw new Error((data && data.message) || ('HTTP ' + res.status));
  }
  if (data && data.status === 'error') {
    throw new Error(data.message || 'Ошибка');
  }
  return data || {};
}

async function apiMutation(action, options = {}) {
  try {
    return await api(action, options);
  } catch (primaryErr) {
    const url = '/cgi-bin/myproxy_api?action=' + encodeURIComponent(action) + '&_=' + Date.now();
    const fetchOptions = Object.assign({cache: 'no-store', headers: {'Cache-Control': 'no-cache'}}, options || {});
    if (options && options.headers) {
      fetchOptions.headers = Object.assign({'Cache-Control': 'no-cache'}, options.headers);
    }
    const res = await fetch(url, fetchOptions);
    const text = await res.text();
    let data = null;
    if (text.trim()) {
      try {
        data = JSON.parse(text);
      } catch (_) {
        throw new Error((primaryErr && primaryErr.message) ? (primaryErr.message + '; CGI non-JSON response') : 'CGI non-JSON response');
      }
    }
    if (!res.ok) {
      throw new Error((data && data.message) || ('HTTP ' + res.status));
    }
    if (data && data.status === 'error') {
      throw new Error(data.message || 'РћС€РёР±РєР°');
    }
    return data || {status: 'success'};
  }
}

async function apiApply(payload) {
  const body = JSON.stringify(payload) + "\n";
  try {
    return await api('apply', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body
    });
  } catch (primaryErr) {
    // Fallback for CGI environments that иногда отдают нестабильный JSON в fetch-wrapper.
    const res = await fetch('/cgi-bin/myproxy_api?action=apply&_=' + Date.now(), {
      method: 'POST',
      cache: 'no-store',
      headers: {'Cache-Control': 'no-cache', 'Content-Type': 'application/json'},
      body
    });
    const text = await res.text();
    let data = null;
    try { data = JSON.parse(text); } catch (_) {
      throw new Error((primaryErr && primaryErr.message) ? (primaryErr.message + '; CGI non-JSON response') : 'CGI non-JSON response');
    }
    if (!res.ok) throw new Error((data && data.message) || ('HTTP ' + res.status));
    if (data && data.status === 'error') throw new Error(data.message || 'Ошибка');
    return data || {};
  }
}

async function refreshStatus() {
  try {
    const data = await api('status');
    state.running = data && data.status === 'running';
    state.effectiveMode = (data && data.mode) || '';
    state.activeServerId = (data && data.active_server_id) || '';
    state.routingProfile = (data && data.routing_profile) || state.routingProfile || 'split';
    state.routeFinal = (data && data.route_final) || state.routeFinal || 'direct';
    state.dnsFinal = (data && data.dns_final) || state.dnsFinal || 'local-dns';
    state.manualStop = !!(data && data.manual_stop);
    state.refilterBootstrapReady = !!(data && data.refilter_bootstrap_ready);
    state.refilterActiveReady = !!(data && data.refilter_active_ready);
    updateButtons();
    applyServerActivityIndicators();
    const activeName = getLoadedServerName(state.activeServerId);
    const activePart = activeName ? (' · ' + t('status.active_segment', {node: activeName})) : '';
    if (state.running) {
      setStatusText(t('status.running_line', {
        mode: state.effectiveMode || '-',
        profile: state.routingProfile || 'split',
        route: state.routeFinal || '?',
        dns: state.dnsFinal || '?'
      }) + activePart);
    } else if (state.manualStop) {
      setStatusText(t('status.manual_stop'));
    } else if (data && data.last_error) {
      setStatusText(data.last_error, true);
    } else {
      setStatusText(t('status.stopped'));
    }
    return data;
  } catch (e) {
    // Fallback: если JSON от CGI нестабилен, определяем статус напрямую по сырому тексту.
    try {
      const res = await fetch('/cgi-bin/myproxy_api?action=status&_=' + Date.now(), {cache: 'no-store', headers: {'Cache-Control': 'no-cache'}});
      const text = await res.text();
      if (/"status"\s*:\s*"running"/.test(text)) {
        state.running = true;
      } else if (/"status"\s*:\s*"stopped"/.test(text)) {
        state.running = false;
      }
      const m = text.match(/"mode"\s*:\s*"([^"]*)"/);
      const activeMatch = text.match(/"active_server_id"\s*:\s*"([^"]*)"/);
      state.manualStop = /"manual_stop"\s*:\s*true/.test(text);
      state.refilterBootstrapReady = /"refilter_bootstrap_ready"\s*:\s*true/.test(text);
      state.refilterActiveReady = /"refilter_active_ready"\s*:\s*true/.test(text);
      state.effectiveMode = m ? m[1] : (state.effectiveMode || '');
      state.activeServerId = activeMatch ? activeMatch[1] : (state.activeServerId || '');
      const routingProfileMatch = text.match(/"routing_profile"\s*:\s*"([^"]*)"/);
      const routeFinalMatch = text.match(/"route_final"\s*:\s*"([^"]*)"/);
      const dnsFinalMatch = text.match(/"dns_final"\s*:\s*"([^"]*)"/);
      state.routingProfile = routingProfileMatch ? routingProfileMatch[1] : (state.routingProfile || 'split');
      state.routeFinal = routeFinalMatch ? routeFinalMatch[1] : (state.routeFinal || 'direct');
      state.dnsFinal = dnsFinalMatch ? dnsFinalMatch[1] : (state.dnsFinal || 'local-dns');
      updateButtons();
      applyServerActivityIndicators();
      const activeName = getLoadedServerName(state.activeServerId);
      const activePart = activeName ? (' · ' + t('status.active_segment', {node: activeName})) : '';
      if (state.running) {
        setStatusText(t('status.running_line', {
          mode: state.effectiveMode || '-',
          profile: state.routingProfile || 'split',
          route: state.routeFinal || '?',
          dns: state.dnsFinal || '?'
        }) + activePart);
      } else if (state.manualStop) {
        setStatusText(t('status.manual_stop'));
      } else {
        setStatusText(t('status.stopped'));
      }
    } catch (_) {}
    return null;
  }
}

async function loadLogs() {
  const box = document.getElementById('logBox');
  if (!box) return;
  const requestSeq = ++state.logRequestSeq;
  try {
    const data = await api('logs');
    if (requestSeq !== state.logRequestSeq) return;
    let out = '';
    if (data && data.log) out += data.log;
    if (data && data.last_error) {
      if (out) out += '\n\n';
      out += '[last_error]\n' + data.last_error;
    }
    if (data && data.incident_history) {
      if (out) out += '\n\n';
      out += '[incident_history]\n' + data.incident_history;
    }
    const backendRunning = !!(data && data.running === 'running');
    if (!out) {
      if (backendRunning && state.lastLogText) {
        out = state.lastLogText;
      } else {
        out = t('log.empty');
      }
    }
    if (out && out !== t('log.empty')) {
      state.lastLogText = out;
    } else if (!backendRunning && !(data && data.last_error)) {
      state.lastLogText = '';
    }
    box.textContent = out;
  } catch (e) {
    if (requestSeq !== state.logRequestSeq) return;
    if (state.lastLogText) {
      box.textContent = state.lastLogText;
    } else {
      box.textContent = t('messages.logs_error', {error: e.message || fallbackErrorText()});
    }
  }
}

function bindDraftChangeListeners() {
  if (draftBindingsDone) return;
  draftBindingsDone = true;
  for (const id of DRAFT_FIELD_IDS) {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener('change', saveUiDraft);
      if (id === 'subUrl' || id === 'customUrl') {
        el.addEventListener('focus', () => markDraftTouched(id, true));
        el.addEventListener('input', () => {
          markDraftTouched(id, true);
          saveUiDraft();
        });
        el.addEventListener('blur', saveUiDraft);
      }
    }
  }
  const manualDomainInput = document.getElementById('manualDomainInput');
  if (manualDomainInput) {
    manualDomainInput.addEventListener('keydown', (event) => {
      if (event.key !== 'Enter') return;
      event.preventDefault();
      addManualDomain();
    });
  }
}

function startUiPollers() {
  if (uiPollersStarted) return;
  uiPollersStarted = true;
  setInterval(async () => {
    await refreshStatus();
    if (!state.loadedServers.length) {
      await restoreConfig();
    }
  }, 3000);
  setInterval(loadLogs, 7000);
  setInterval(refreshUpdateStatus, 60000);
}

async function restoreConfig() {
  loadUiDraft();
  try {
    const data = await api('get_config');
    state.activeServerId = (data && data.active_server_id) || '';
    state.refilterBootstrapReady = !!(data && data.refilter_bootstrap_ready);
    state.refilterActiveReady = !!(data && data.refilter_active_ready);
  if (data.settings) {
      setTextInputFromStoredState('subUrl', data.settings.url, 'backend');
      setTextInputFromStoredState('customUrl', data.settings.custom_url, 'backend');
      if (data.settings.rules) {
        document.getElementById('rule_refilter').checked = data.settings.rules.refilter !== false;
        document.getElementById('rule_proxy_ai').checked = data.settings.rules.proxy_ai !== false;
        document.getElementById('rule_direct_ru').checked = data.settings.rules.direct_ru !== false;
        document.getElementById('rule_force_ru_suffix').checked = data.settings.rules.force_ru_suffix !== false;
      }
      if (typeof data.settings.auto_update === 'boolean') document.getElementById('auto_update').checked = data.settings.auto_update;
      if (typeof data.settings.use_auto_redirect === 'boolean') document.getElementById('use_auto_redirect').checked = data.settings.use_auto_redirect;
      if (Array.isArray(data.settings.manual_domains)) setManualDomains(data.settings.manual_domains);
      if (Array.isArray(data.settings.servers)) state.selected = new Set(data.settings.servers);
    }
    if (Array.isArray(data.servers) && data.servers.length) {
      renderServers(data.servers);
    } else {
      renderServers([]);
    }
  } catch (_) {}
  renderManualDomains();
  updateRouteTilesFromInputs();
  updateProfileChips();
  updateButtons();
  applyServerActivityIndicators();
  saveUiDraft();
}

async function loadServers() {
  const subUrlEl = document.getElementById('subUrl');
  const subUrl = normalizeSourceEditorText(subUrlEl.value);
  if (!subUrl) {
    setStatusText(t('messages.enter_subscription'), true);
    return;
  }
  if (subUrlEl.value !== subUrl) {
    subUrlEl.value = subUrl;
  }
  const btn = document.getElementById('loadBtn');
  btn.disabled = true;
  btn.textContent = t('buttons.loading_servers');
  setStatusText(t('messages.load_servers_loading'));
  try {
    const json = await api('get_servers', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({url: subUrl}) + "\n"
    });
    if (!json.servers || !json.servers.length) {
      renderServers([]);
      setStatusText(json.message || t('messages.load_servers_none'), true);
      return;
    }
    const previousSelected = new Set(state.selected);
    const backendSelected = json.servers.filter((item) => item && item.selected).map((item) => item.id);
    const useBackendSelected = previousSelected.size === 0 && state.loadedServers.length === 0;
    const backendHasReplenishedIds = backendSelected.some((id) => !previousSelected.has(id));
    const nextSelected = (useBackendSelected || backendHasReplenishedIds)
      ? backendSelected
      : json.servers.filter((item) => previousSelected.has(item.id)).map((item) => item.id);
    state.selected = new Set(nextSelected);
    renderServers(json.servers);
    markDraftTouched('subUrl', false);
    if (state.selected.size > 0) {
      setStatusText(t('messages.load_servers_found_selected', {total: json.servers.length, selected: state.selected.size}));
    } else {
      setStatusText(t('messages.load_servers_found_pick', {total: json.servers.length}));
    }
    saveUiDraft();
  } catch (e) {
    renderServers([]);
    setStatusText(t('messages.load_servers_error', {error: e.message || fallbackErrorText()}), true);
  } finally {
    btn.disabled = false;
    btn.textContent = t('buttons.load_servers');
  }
}

function collectPayload() {
  const rules = {
    refilter: document.getElementById('rule_refilter').checked,
    proxy_ai: document.getElementById('rule_proxy_ai').checked,
    direct_ru: document.getElementById('rule_direct_ru').checked,
    force_ru_suffix: document.getElementById('rule_force_ru_suffix').checked
  };
  const force_full_proxy = !rules.refilter
    && !rules.proxy_ai
    && !rules.direct_ru
    && !rules.force_ru_suffix;

  return {
    url: normalizeSourceEditorText(document.getElementById('subUrl').value),
    custom_url: document.getElementById('customUrl').value.trim(),
    auto_update: document.getElementById('auto_update').checked,
    use_auto_redirect: document.getElementById('use_auto_redirect').checked,
    manual_domains: Array.from(state.manualDomains || []),
    servers: Array.from(state.selected),
    rules,
    force_full_proxy
  };
}

function isFullProxyMode(payload) {
  if (!payload) return false;
  if (typeof payload.force_full_proxy === 'boolean') return payload.force_full_proxy;
  if (!payload.rules) return false;
  return !payload.rules.refilter
    && !payload.rules.proxy_ai
    && !payload.rules.direct_ru
    && !payload.rules.force_ru_suffix;
}

async function applyInternal() {
  const payload = collectPayload();
  if (!payload.url) {
    setStatusText(t('messages.subscription_empty'), true);
    return false;
  }
  if (!payload.servers.length) {
    setStatusText(t('messages.need_server'), true);
    return false;
  }
  if (isFullProxyMode(payload)) {
    const ok = confirm(t('messages.full_vpn_confirm'));
    if (!ok) {
      setStatusText(t('messages.start_cancelled'));
      return false;
    }
  }
  saveUiDraft();
  setStatusText(t('messages.building_config'));
  try {
    const data = await apiApply(payload);
    state.running = true;
    state.effectiveMode = data.mode || '';
    updateButtons();
    if (isFullProxyMode(payload)) {
      setStatusText((data.message || t('messages.config_applied')) + ' ' + t('messages.full_vpn_enabled'));
    } else {
      setStatusText(data.message || t('messages.config_applied'));
    }
    markDraftTouched('subUrl', false);
    markDraftTouched('customUrl', false);
    await refreshStatus();
    return true;
  } catch (e) {
    setStatusText(t('messages.apply_error', {error: e.message || fallbackErrorText()}), true);
    return false;
  }
}

async function waitForStatus(expected, attempts = 20, delayMs = 500) {
  for (let i = 0; i < attempts; i++) {
    await new Promise(r => setTimeout(r, delayMs));
    const st = await refreshStatus();
    if (st && st.status === expected) return true;
  }
  return false;
}

async function stopServiceOnly() {
  setStatusText(t('messages.stop_progress'));
  await apiMutation('stop', {method: 'POST'});
  const stopped = await waitForStatus('stopped', 16, 400);
  if (!stopped) {
    const st = await refreshStatus();
    if (st && st.status === 'running') {
      setStatusText(t('messages.stop_pending'), true);
      return;
    }
    state.running = false;
    state.effectiveMode = '';
    state.activeServerId = '';
    state.manualStop = true;
    updateButtons();
    applyServerActivityIndicators();
    setStatusText(t('messages.stop_sent'));
  }
}

async function prepareRefilter() {
  const btn = document.getElementById('prepareRefilterBtn');
  if (!btn || btn.disabled) return;
  btn.disabled = true;
  btn.textContent = t('buttons.preparing_refilter');
  setStatusText(t('messages.refilter_preparing'));
  try {
    const data = await apiMutation('prepare_refilter', {method: 'POST'});
    await refreshStatus();
    await loadLogs();
    setStatusText((data && data.message) ? data.message : t('messages.refilter_ready'));
  } catch (e) {
    setStatusText(t('messages.refilter_prepare_error', {error: e.message || fallbackErrorText()}), true);
  } finally {
    updateRefilterButton();
  }
}

async function powerAction() {
  const btn = document.getElementById('powerBtn');
  let keepErrorVisible = false;
    btn.disabled = true;
    try {
      await refreshStatus();
      if (state.running) {
        await stopServiceOnly();
        return;
      }

    btn.textContent = t('buttons.power_turning_on');
    btn.className = 'btn primary';
    const applied = await applyInternal();
    if (!applied) {
      keepErrorVisible = true;
      return;
    }

    const started = await waitForStatus('running', 24, 500);
    if (!started) {
      setStatusText(t('messages.power_wait_running'), true);
      await refreshStatus();
    }
  } catch (e) {
    keepErrorVisible = true;
    setStatusText(t('messages.generic_error', {error: e.message || fallbackErrorText()}), true);
  } finally {
    btn.disabled = false;
    if (!keepErrorVisible) {
      await refreshStatus();
    } else {
      updateButtons();
    }
  }
}

async function applyChanges() {
  const btn = document.getElementById('applyBtn');
  btn.disabled = true;
  btn.textContent = t('buttons.applying');
  await applyInternal();
  btn.disabled = false;
  btn.textContent = t('buttons.apply');
}

async function clearConfig() {
  if (!confirm(t('messages.clear_confirm'))) return;
  setStatusText(t('messages.clear_progress'));
  try {
    const data = await apiMutation('clear', {method: 'POST'});
    localStorage.removeItem('gog_ui_draft_v5');
    resetUiToDefaults();
    state.running = false;
    state.effectiveMode = '';
    state.activeServerId = '';
    state.manualStop = true;
    updateButtons();
    applyServerActivityIndicators();
    await refreshStatus();
    await loadLogs();
    setStatusText(data.message || t('messages.clear_deleted'));
  } catch (e) {
    setStatusText(t('messages.clear_error', {error: e.message || fallbackErrorText()}), true);
  }
}

async function bootstrapUi(forceConfigRefresh = false) {
  if (uiBootstrapPromise) return uiBootstrapPromise;
  uiBootstrapPromise = (async () => {
    bindDraftChangeListeners();
    initUiMode();
    initLanguage();
    initLogCollapsed();
    renderManualDomains();
    if (forceConfigRefresh || !state.loadedServers.length) {
      await restoreConfig();
    }
    for (let i = 0; i < 5; i++) {
      await refreshStatus();
      await new Promise(r => setTimeout(r, 300));
    }
    await refreshDependencyStatus();
    await refreshUpdateStatus();
    await loadLogs();
    startUiPollers();
  })().catch((e) => {
    setStatusText(t('messages.init_error', {error: (e && e.message) ? e.message : fallbackErrorText()}), true);
  }).finally(() => {
    uiBootstrapPromise = null;
  });
  return uiBootstrapPromise;
}

function scheduleUiBootstrap(forceConfigRefresh = false) {
  setTimeout(() => {
    bootstrapUi(forceConfigRefresh);
  }, 0);
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    scheduleUiBootstrap(true);
  }, {once: true});
} else {
  scheduleUiBootstrap(true);
}

window.addEventListener('pageshow', () => {
  scheduleUiBootstrap(!state.loadedServers.length);
});
</script>
</body>
</html>
EOF


echo "[5/5] Установка CGI API..."
cat <<'EOF' > /www/cgi-bin/myproxy_api
#!/bin/sh
echo "Content-Type: application/json; charset=utf-8"
echo "Cache-Control: no-store, no-cache, must-revalidate, max-age=0"
echo "Pragma: no-cache"
echo "Expires: 0"
echo ""

BASE_DIR="/etc/sing-box"
TMP_DIR="/tmp/gog-build"
RAW_FILE="$BASE_DIR/raw_sub.txt"
CUSTOM_FILE="$BASE_DIR/custom_list.txt"
SETTINGS_FILE="$BASE_DIR/myproxy_settings.json"
PAYLOAD_FILE="$BASE_DIR/last_payload.json"
CONFIG_FILE="$BASE_DIR/config.json"
SERVERS_CACHE="$BASE_DIR/servers_cache.txt"
REFILTER_DOMAINS_FILE="$BASE_DIR/refilter_domains.srs"
REFILTER_IPSUM_FILE="$BASE_DIR/refilter_ipsum.srs"
REFILTER_BOOTSTRAP_DIR="/etc/gog/refilter-cache"
REFILTER_DOMAINS_CACHE_FILE="$REFILTER_BOOTSTRAP_DIR/refilter_domains.srs"
REFILTER_IPSUM_CACHE_FILE="$REFILTER_BOOTSTRAP_DIR/refilter_ipsum.srs"
REFILTER_DOMAINS_URL="https://github.com/1andrevich/Re-filter-lists/releases/latest/download/ruleset-domain-refilter_domains.srs"
REFILTER_IPSUM_URL="https://github.com/1andrevich/Re-filter-lists/releases/latest/download/ruleset-ip-refilter_ipsum.srs"
ACTIVE_SELECTED_IDS_FILE="$BASE_DIR/active_selected_ids.txt"
MODE_FILE="$BASE_DIR/active_mode.txt"
MANUAL_STOP_FILE="$BASE_DIR/manual_stop.flag"
ERR_FILE="/tmp/gog_last_error.txt"
INCIDENT_LOG_FILE="/tmp/gog_incident_history.log"
LOG_FILE="/tmp/gog.log"
ACTIVE_SERVER_OBS_FILE="/tmp/gog_active_server_observation.txt"
ACTIVE_SERVER_OBS_TTL=300
ACTIVE_SERVER_OBS_REFRESH_INTERVAL=60
LOG_ROTATE_MAX_BYTES=262144
INCIDENT_LOG_MAX_BYTES=1048576
INCIDENT_LOG_API_TAIL_LINES=120
WATCHDOG_FAIL_FILE="/tmp/gog_watchdog_fail_count.txt"
PROBE_STATE_FILE="/tmp/gog_last_probe_state.txt"
QUARANTINE_FILE="/tmp/gog_quarantined_server_ids.txt"
WATCHDOG_MIN_FAILS=2
URLTEST_INTERVAL="3m"
URLTEST_TOLERANCE=150
SERVICE_DEPS_DIR="/etc/gog/service-deps"
SERVICE_DEP_CANDIDATE_DIR="$SERVICE_DEPS_DIR/candidates"
SERVICE_DEP_ACCEPTED_DIR="$SERVICE_DEPS_DIR/accepted"
SERVICE_DEP_REJECTED_DIR="$SERVICE_DEPS_DIR/rejected"
SERVICE_DEP_SEEN_FILE="$SERVICE_DEPS_DIR/processed_log_hashes.txt"
SERVICE_DEP_LAST_SCAN_FILE="$SERVICE_DEPS_DIR/last_scan_epoch.txt"
SERVICE_DEP_WINDOW_LINES=8
SERVICE_DEP_MAX_SEEN_HASHES=4000
SERVICE_DEP_MAX_CANDIDATES_PER_SERVICE=64
SERVICE_DEP_LOG_TAIL_LINES=800
SERVICE_DEP_TTL_SECONDS=604800
SERVICE_DEP_PROBATION_HITS=2
SERVICE_DEP_SUGGESTED_HITS=4
GOG_APP_VERSION="v1.91-sb1137"
GOG_UPDATE_CHANNEL="stable"
GOG_UPDATE_COMPATIBILITY="sb1137"
GOG_UPDATE_DEFAULT_MANIFEST_URL="https://gog-sing-box-launcher.pages.dev/stable/update.json"
GOG_UPDATE_DIR="/etc/gog/update"
GOG_UPDATE_BACKUP_DIR="$GOG_UPDATE_DIR/backups"
GOG_UPDATE_SETTINGS_FILE="$GOG_UPDATE_DIR/settings.json"
GOG_UPDATE_STATUS_FILE="$GOG_UPDATE_DIR/status.json"
GOG_UPDATE_TRUSTED_PUB_FILE="$GOG_UPDATE_DIR/trusted.pub"
GOG_UPDATE_DOWNLOADED_PACKAGE_FILE="$GOG_UPDATE_DIR/downloaded_package_path.txt"
GOG_UPDATE_LAST_INSTALL_LOG="$GOG_UPDATE_DIR/last_install.log"
GOG_UPDATE_DOWNLOAD_DIR="/tmp/gog-update"
GOG_UPDATE_MAX_BACKUPS=3
LOCK_DIR="$TMP_DIR/action.lock"
LOCK_PID_FILE="$LOCK_DIR/pid"
LOCK_TS_FILE="$LOCK_DIR/epoch"
LOCK_WAIT_SECONDS=30
LOCK_STALE_SECONDS=900

mkdir -p "$BASE_DIR" "$TMP_DIR" "$REFILTER_BOOTSTRAP_DIR" "$SERVICE_DEP_CANDIDATE_DIR" "$GOG_UPDATE_DIR" "$GOG_UPDATE_BACKUP_DIR"

ACTION=$(printf '%s' "${QUERY_STRING:-}" | sed -n 's/.*action=\([^&]*\).*/\1/p')
[ -z "$ACTION" ] && ACTION="status"

now_epoch() {
    date +%s 2>/dev/null || echo 0
}

is_pid_running() {
    pid="$1"
    case "$pid" in
        ''|*[!0-9]*) return 1 ;;
    esac
    kill -0 "$pid" >/dev/null 2>&1
}

clear_action_lock() {
    rm -f "$LOCK_PID_FILE" "$LOCK_TS_FILE" 2>/dev/null || true
    rmdir "$LOCK_DIR" 2>/dev/null || true
}

release_action_lock() {
    owner_pid=""
    [ -s "$LOCK_PID_FILE" ] && owner_pid=$(cat "$LOCK_PID_FILE" 2>/dev/null || true)
    if [ "$owner_pid" = "$$" ]; then
        clear_action_lock
    fi
    trap - EXIT HUP INT TERM
}

acquire_action_lock() {
    waited=0
    while :; do
        if mkdir "$LOCK_DIR" 2>/dev/null; then
            printf '%s' "$$" > "$LOCK_PID_FILE"
            printf '%s' "$(now_epoch)" > "$LOCK_TS_FILE"
            trap 'release_action_lock' EXIT HUP INT TERM
            return 0
        fi

        if [ ! -s "$LOCK_PID_FILE" ] && [ ! -s "$LOCK_TS_FILE" ] && [ "$waited" -ge 2 ]; then
            clear_action_lock
            continue
        fi

        owner_pid=""
        owner_ts=0
        current_ts=0
        [ -s "$LOCK_PID_FILE" ] && owner_pid=$(cat "$LOCK_PID_FILE" 2>/dev/null || true)
        [ -s "$LOCK_TS_FILE" ] && owner_ts=$(cat "$LOCK_TS_FILE" 2>/dev/null || echo 0)
        current_ts=$(now_epoch)

        case "$owner_ts" in
            ''|*[!0-9]*) owner_ts=0 ;;
        esac
        case "$current_ts" in
            ''|*[!0-9]*) current_ts=0 ;;
        esac

        stale="false"
        if [ -n "$owner_pid" ] && ! is_pid_running "$owner_pid"; then
            stale="true"
        fi
        if [ "$stale" = "false" ] && [ "$owner_ts" -gt 0 ] && [ "$current_ts" -gt 0 ]; then
            age=$((current_ts - owner_ts))
            [ "$age" -gt "$LOCK_STALE_SECONDS" ] && stale="true"
        fi
        if [ "$stale" = "true" ]; then
            clear_action_lock
            continue
        fi

        [ "$waited" -ge "$LOCK_WAIT_SECONDS" ] && fail_json_transient "Другой запрос уже меняет конфигурацию. Повтори через 30 секунд."
        sleep 1
        waited=$((waited + 1))
    done
}

json_escape() {
    first=1
    printf '%s' "$1" | while IFS= read -r line || [ -n "$line" ]; do
        escaped_line=$(printf '%s' "$line" | sed \
            -e 's/\\/\\\\/g' \
            -e 's/"/\\"/g' \
            -e 's/\r//g')
        if [ "$first" -eq 0 ]; then
            printf '\\n'
        fi
        printf '%s' "$escaped_line"
        first=0
    done
}

url_decode() {
    encoded="$1"
    encoded=$(printf '%s' "$encoded" | sed 's/+/ /g')
    printf '%b' "$(printf '%s' "$encoded" | sed 's/%/\\x/g')"
}

url_component_decode() {
    url_decode "$1"
}

json_get_string_raw_from_text() {
    key="$1"
    text="$2"
    printf '%s' "$text" | awk -v key="$key" '
        function skip_ws(str, pos,    ch) {
            while (pos <= length(str)) {
                ch = substr(str, pos, 1)
                if (ch !~ /[ \t\r\n]/) {
                    return pos
                }
                pos++
            }
            return pos
        }
        BEGIN { RS = ""; ORS = "" }
        {
            json = $0
            token = "\"" key "\""
            pos = index(json, token)
            if (pos == 0) {
                exit
            }
            pos += length(token)
            pos = skip_ws(json, pos)
            if (substr(json, pos, 1) != ":") {
                exit
            }
            pos++
            pos = skip_ws(json, pos)
            if (substr(json, pos, 1) != "\"") {
                exit
            }
            pos++
            out = ""
            escaped = 0
            while (pos <= length(json)) {
                ch = substr(json, pos, 1)
                if (escaped) {
                    out = out "\\" ch
                    escaped = 0
                    pos++
                    continue
                }
                if (ch == "\\") {
                    escaped = 1
                    pos++
                    continue
                }
                if (ch == "\"") {
                    printf "%s", out
                    exit
                }
                out = out ch
                pos++
            }
        }
    '
}

json_unescape_string() {
    value="$1"
    printf '%s' "$value" | awk '
        BEGIN { RS = ""; ORS = "" }
        {
            text = $0
            pos = 1
            while (pos <= length(text)) {
                ch = substr(text, pos, 1)
                if (ch != "\\") {
                    printf "%s", ch
                    pos++
                    continue
                }
                pos++
                if (pos > length(text)) {
                    printf "\\"
                    break
                }
                esc = substr(text, pos, 1)
                if (esc == "n") {
                    printf "\n"
                } else if (esc == "r") {
                    printf "\r"
                } else if (esc == "t") {
                    printf "\t"
                } else if (esc == "b") {
                    printf "\b"
                } else if (esc == "f") {
                    printf "\f"
                } else if (esc == "\"") {
                    printf "\""
                } else if (esc == "\\") {
                    printf "\\"
                } else if (esc == "/") {
                    printf "/"
                } else {
                    printf "%s", esc
                }
                pos++
            }
        }
    '
}

json_get_string_from_text() {
    key="$1"
    text="$2"
    raw_value=$(json_get_string_raw_from_text "$key" "$text")
    if [ -z "$raw_value" ]; then
        return 0
    fi
    json_unescape_string "$raw_value"
}

json_get_string() {
    key="$1"
    json_get_string_from_text "$key" "$POST_DATA"
}

json_get_bool() {
    key="$1"
    if printf '%s' "$POST_DATA" | grep -q '"'$key'"[[:space:]]*:[[:space:]]*true'; then
        printf 'true'
    else
        printf 'false'
    fi
}

json_get_bool_from_text() {
    key="$1"
    text="$2"
    if printf '%s' "$text" | grep -q '"'$key'"[[:space:]]*:[[:space:]]*true'; then
        printf 'true'
    else
        printf 'false'
    fi
}

json_get_number_from_text() {
    key="$1"
    text="$2"
    printf '%s' "$text" | tr '\r\n' '  ' | sed -n 's/.*"'$key'"[[:space:]]*:[[:space:]]*\([0-9][0-9]*\).*/\1/p' | head -n 1
}

json_string_array_from_text() {
    key="$1"
    text="$2"
    normalized_text=$(printf '%s' "$text" | tr '\r\n' '  ')
    printf '%s' "$normalized_text" | sed -n 's/.*"'$key'"[[:space:]]*:[[:space:]]*\[\([^]]*\)\].*/\1/p' | \
        tr ',' '\n' | \
        sed 's/^[[:space:]]*"//; s/"[[:space:]]*$//; /^[[:space:]]*$/d'
}

json_servers_from_text() {
    json_string_array_from_text "servers" "$1"
}

json_get_servers() {
    json_servers_from_text "$POST_DATA"
}

json_get_manual_domains() {
    json_string_array_from_text "manual_domains" "$POST_DATA"
}

normalize_domain_value() {
    value="$1"
    value=$(printf '%s' "$value" | tr 'A-Z' 'a-z' | tr -d '\015')
    value=$(printf '%s' "$value" | sed 's#^[a-z][a-z0-9+.-]*://##')
    value=$(printf '%s' "$value" | sed 's#[/?#].*$##')
    value=$(printf '%s' "$value" | sed 's/:[0-9][0-9]*$//')
    value=$(printf '%s' "$value" | sed 's/^\*\.//; s/^\.+//; s/\.+$//')
    [ -n "$value" ] || return 1
    if printf '%s\n' "$value" | grep -Eq '^(xn--[a-z0-9-]+|[a-z0-9]([a-z0-9-]*[a-z0-9])?)(\.(xn--[a-z0-9-]+|[a-z0-9]([a-z0-9-]*[a-z0-9])?))+$'; then
        printf '%s' "$value"
        return 0
    fi
    return 1
}

manual_domains_json_from_payload() {
    input_file="$TMP_DIR/manual_domains.input.$$.$RANDOM.txt"
    seen_file="$TMP_DIR/manual_domains.seen.$$.$RANDOM.txt"
    out_file="$TMP_DIR/manual_domains.out.$$.$RANDOM.txt"
    : > "$seen_file"
    : > "$out_file"
    json_get_manual_domains > "$input_file"

    while IFS= read -r raw || [ -n "$raw" ]; do
        domain=$(normalize_domain_value "$raw" 2>/dev/null || true)
        [ -n "$domain" ] || continue
        if ! grep -Fxq "$domain" "$seen_file"; then
            printf '%s\n' "$domain" >> "$seen_file"
            printf '"%s"\n' "$(json_escape "$domain")" >> "$out_file"
        fi
    done < "$input_file"

    if [ -s "$out_file" ]; then
        awk 'BEGIN { first = 1 } { if (!first) printf ", "; printf "%s", $0; first = 0 }' "$out_file"
    fi

    rm -f "$input_file" "$seen_file" "$out_file"
}

read_post_body() {
    if [ -n "${CONTENT_LENGTH:-}" ]; then
        case "$CONTENT_LENGTH" in
            ''|*[!0-9]*) ;;
            *)
                if [ "$CONTENT_LENGTH" -gt 0 ] 2>/dev/null; then
                    dd bs=1 count="$CONTENT_LENGTH" 2>/dev/null || true
                    return 0
                fi
                ;;
        esac
    fi
    if [ -t 0 ]; then
        return 0
    fi
    cat 2>/dev/null || true
}

strip_utf8_bom_text() {
    text="$1"
    bom="$(printf '\357\273\277')"
    case "$text" in
        "$bom"*)
            printf '%s' "${text#"$bom"}"
            ;;
        *)
            printf '%s' "$text"
            ;;
    esac
}

read_text_file_clean() {
    file="$1"
    [ -f "$file" ] || return 0
    content=$(cat "$file" 2>/dev/null || true)
    strip_utf8_bom_text "$content"
}

copy_text_file_clean() {
    src="$1"
    dest="$2"
    content=$(read_text_file_clean "$src")
    printf '%s' "$content" > "$dest"
}

settings_get_selected_ids() {
    selected_cache="${1:-$SERVERS_CACHE}"
    settings_self_heal_from_stronger_state "$selected_cache" >/dev/null 2>&1 || true
    if [ -s "$SETTINGS_FILE" ]; then
        settings_selected_tmp="$TMP_DIR/settings.selected.$$.$RANDOM.txt"
        json_servers_from_text "$(read_text_file_clean "$SETTINGS_FILE")" > "$settings_selected_tmp"
        if [ -s "$settings_selected_tmp" ]; then
            cat "$settings_selected_tmp"
            rm -f "$settings_selected_tmp"
            return 0
        fi
        rm -f "$settings_selected_tmp"
    fi
    if [ -s "$PAYLOAD_FILE" ]; then
        json_servers_from_text "$(read_text_file_clean "$PAYLOAD_FILE")"
        return 0
    fi
    if [ -s "$ACTIVE_SELECTED_IDS_FILE" ]; then
        cat "$ACTIVE_SELECTED_IDS_FILE"
    fi
}

json_file_has_selected_servers() {
    json_file="$1"
    [ -s "$json_file" ] || return 1
    json_selected_tmp="$TMP_DIR/json.selected.$$.$RANDOM.txt"
    json_servers_from_text "$(read_text_file_clean "$json_file")" > "$json_selected_tmp"
    [ -s "$json_selected_tmp" ]
    result=$?
    rm -f "$json_selected_tmp"
    return "$result"
}

selected_ids_file_has_records() {
    selected_file="$1"
    [ -s "$selected_file" ] || return 1
    awk 'NF { found = 1; exit } END { exit(found ? 0 : 1) }' "$selected_file" >/dev/null 2>&1
}

settings_self_heal_from_stronger_state() {
    settings_cache="${1:-$SERVERS_CACHE}"
    payload_selected_tmp="$TMP_DIR/settings_heal.payload.$$.$RANDOM.txt"
    payload_available_tmp="$TMP_DIR/settings_heal.payload.available.$$.$RANDOM.txt"
    active_available_tmp="$TMP_DIR/settings_heal.active.available.$$.$RANDOM.txt"
    repaired_tmp="$TMP_DIR/settings_heal.repaired.$$.$RANDOM.json"
    base_file=""

    [ -s "$settings_cache" ] || return 0
    if json_file_has_selected_servers "$SETTINGS_FILE"; then
        return 0
    fi

    if json_file_has_selected_servers "$PAYLOAD_FILE"; then
        json_servers_from_text "$(read_text_file_clean "$PAYLOAD_FILE")" > "$payload_selected_tmp"
        build_available_selected_ids "$payload_selected_tmp" "$settings_cache" "$payload_available_tmp"
        if selected_ids_file_has_records "$payload_available_tmp"; then
            sanitize_json_servers_against_cache "$PAYLOAD_FILE" "$settings_cache" "$repaired_tmp"
            if [ -s "$repaired_tmp" ]; then
                copy_text_file_clean "$repaired_tmp" "$SETTINGS_FILE"
                rm -f "$payload_selected_tmp" "$payload_available_tmp" "$active_available_tmp" "$repaired_tmp"
                return 0
            fi
        fi
    fi

    if [ -s "$ACTIVE_SELECTED_IDS_FILE" ]; then
        build_available_selected_ids "$ACTIVE_SELECTED_IDS_FILE" "$settings_cache" "$active_available_tmp"
        if selected_ids_file_has_records "$active_available_tmp"; then
            if [ -s "$SETTINGS_FILE" ]; then
                base_file="$SETTINGS_FILE"
            elif [ -s "$PAYLOAD_FILE" ]; then
                base_file="$PAYLOAD_FILE"
            fi
            if [ -n "$base_file" ]; then
                rewrite_json_servers_from_selected_file "$base_file" "$active_available_tmp" "$repaired_tmp"
                if [ -s "$repaired_tmp" ]; then
                    copy_text_file_clean "$repaired_tmp" "$SETTINGS_FILE"
                fi
            fi
        fi
    fi

    rm -f "$payload_selected_tmp" "$payload_available_tmp" "$active_available_tmp" "$repaired_tmp"
}

server_cache_has_id() {
    lookup_sid="$1"
    lookup_cache="$2"
    [ -s "$lookup_cache" ] || return 1
    awk -F '\t' -v sid="$lookup_sid" '$1 == sid { found=1; exit } END { exit(found ? 0 : 1) }' "$lookup_cache"
}

reset_quarantined_servers() {
    rm -f "$QUARANTINE_FILE"
}

is_server_quarantined() {
    sid="$1"
    [ -n "$sid" ] || return 1
    [ -s "$QUARANTINE_FILE" ] || return 1
    grep -Fxq "$sid" "$QUARANTINE_FILE" 2>/dev/null
}

quarantine_server_id() {
    sid="$1"
    [ -n "$sid" ] || return 1
    if ! is_server_quarantined "$sid"; then
        printf '%s\n' "$sid" >> "$QUARANTINE_FILE"
    fi
}

build_effective_selected_ids() {
    effective_selected_file="$1"
    effective_cache="$2"
    effective_out_file="$3"
    effective_available_tmp="$TMP_DIR/selected_ids.available.txt"
    effective_filtered_tmp="$TMP_DIR/selected_ids.filtered.txt"

    : > "$effective_out_file"
    : > "$effective_available_tmp"
    : > "$effective_filtered_tmp"
    [ -s "$effective_selected_file" ] || return 0

    while IFS= read -r sid || [ -n "$sid" ]; do
        [ -n "$sid" ] || continue
        if ! server_cache_has_id "$sid" "$effective_cache"; then
            continue
        fi
        printf '%s\n' "$sid" >> "$effective_available_tmp"
        if ! is_server_quarantined "$sid"; then
            printf '%s\n' "$sid" >> "$effective_filtered_tmp"
        fi
    done < "$effective_selected_file"

    if [ -s "$effective_filtered_tmp" ]; then
        cp "$effective_filtered_tmp" "$effective_out_file"
    else
        cp "$effective_available_tmp" "$effective_out_file"
    fi
}

build_available_selected_ids() {
    available_selected_file="$1"
    available_cache="$2"
    available_out_file="$3"

    : > "$available_out_file"
    [ -s "$available_selected_file" ] || return 0

    while IFS= read -r sid || [ -n "$sid" ]; do
        [ -n "$sid" ] || continue
        if ! server_cache_has_id "$sid" "$available_cache"; then
            continue
        fi
        if grep -Fxq "$sid" "$available_out_file" 2>/dev/null; then
            continue
        fi
        printf '%s\n' "$sid" >> "$available_out_file"
    done < "$available_selected_file"
}

build_best_available_selected_ids() {
    best_cache="$1"
    best_out_file="$2"
    best_settings_ids_tmp="$TMP_DIR/best_selected.settings.ids.$$.$RANDOM.txt"
    best_settings_available_tmp="$TMP_DIR/best_selected.settings.available.$$.$RANDOM.txt"
    best_payload_ids_tmp="$TMP_DIR/best_selected.payload.ids.$$.$RANDOM.txt"
    best_payload_available_tmp="$TMP_DIR/best_selected.payload.available.$$.$RANDOM.txt"
    best_active_available_tmp="$TMP_DIR/best_selected.active.available.$$.$RANDOM.txt"
    best_count=0

    : > "$best_out_file"
    [ -s "$best_cache" ] || return 0

    if [ -s "$SETTINGS_FILE" ]; then
        json_servers_from_text "$(read_text_file_clean "$SETTINGS_FILE")" > "$best_settings_ids_tmp"
        build_available_selected_ids "$best_settings_ids_tmp" "$best_cache" "$best_settings_available_tmp"
        current_count=$(count_lines_in_file "$best_settings_available_tmp")
        if [ "$current_count" -gt "$best_count" ] 2>/dev/null; then
            cp "$best_settings_available_tmp" "$best_out_file"
            best_count="$current_count"
        fi
    fi

    if [ -s "$PAYLOAD_FILE" ]; then
        json_servers_from_text "$(read_text_file_clean "$PAYLOAD_FILE")" > "$best_payload_ids_tmp"
        build_available_selected_ids "$best_payload_ids_tmp" "$best_cache" "$best_payload_available_tmp"
        current_count=$(count_lines_in_file "$best_payload_available_tmp")
        if [ "$current_count" -gt "$best_count" ] 2>/dev/null; then
            cp "$best_payload_available_tmp" "$best_out_file"
            best_count="$current_count"
        fi
    fi

    if [ -s "$ACTIVE_SELECTED_IDS_FILE" ]; then
        build_available_selected_ids "$ACTIVE_SELECTED_IDS_FILE" "$best_cache" "$best_active_available_tmp"
        current_count=$(count_lines_in_file "$best_active_available_tmp")
        if [ "$current_count" -gt "$best_count" ] 2>/dev/null; then
            cp "$best_active_available_tmp" "$best_out_file"
            best_count="$current_count"
        fi
    fi

    rm -f \
        "$best_settings_ids_tmp" \
        "$best_settings_available_tmp" \
        "$best_payload_ids_tmp" \
        "$best_payload_available_tmp" \
        "$best_active_available_tmp"
}

json_servers_array_literal_from_file() {
    selected_file="$1"
    first=1
    printf '['
    if [ -f "$selected_file" ]; then
        while IFS= read -r sid || [ -n "$sid" ]; do
            [ -n "$sid" ] || continue
            [ $first -eq 0 ] && printf ','
            printf '"%s"' "$(json_escape "$sid")"
            first=0
        done < "$selected_file"
    fi
    printf ']'
}

sanitize_json_servers_against_cache() {
    src="$1"
    cache="$2"
    dest="$3"
    selected_tmp="$TMP_DIR/json_servers.selected.txt"
    available_tmp="$TMP_DIR/json_servers.available.txt"

    content=$(read_text_file_clean "$src")
    if [ -z "$content" ]; then
        : > "$dest"
        return 0
    fi

    json_servers_from_text "$content" > "$selected_tmp"
    build_available_selected_ids "$selected_tmp" "$cache" "$available_tmp"
    rewrite_json_servers_from_selected_file "$src" "$available_tmp" "$dest"
}

rewrite_json_servers_from_selected_file() {
    src="$1"
    selected_file="$2"
    dest="$3"

    content=$(read_text_file_clean "$src")
    if [ -z "$content" ]; then
        : > "$dest"
        return 0
    fi
    normalized_content=$(printf '%s' "$content" | tr '\r\n' '  ')

    servers_json=$(json_servers_array_literal_from_file "$selected_file")
    if printf '%s' "$normalized_content" | grep -q '"servers"[[:space:]]*:'; then
        printf '%s' "$normalized_content" | sed "s/\"servers\"[[:space:]]*:[[:space:]]*\\[[^]]*\\]/\"servers\":$servers_json/" > "$dest"
    else
        printf '%s' "$normalized_content" > "$dest"
    fi
}

server_replenish_bucket_from_name() {
    name="$1"
    [ -n "$name" ] || return 1

    prefix=""
    rest="$name"
    case "$name" in
        *-*)
            first="${name%%-*}"
            tail="${name#*-}"
            if [ -n "$first" ] && ! printf '%s' "$first" | grep -q '[A-Za-z0-9]'; then
                prefix="$first"
                rest="$tail"
            fi
            ;;
    esac

    case "$rest" in
        [A-Z][A-Z]-*) rest="${rest#*-}" ;;
        [A-Z][A-Z][A-Z]-*) rest="${rest#*-}" ;;
        [A-Z][A-Z][A-Z][A-Z]-*) rest="${rest#*-}" ;;
        [A-Z][A-Z][A-Z][A-Z][A-Z]-*) rest="${rest#*-}" ;;
    esac

    rest="${rest%%.*}"

    if [ -n "$prefix" ]; then
        printf '%s' "$prefix"
        return 0
    fi

    [ -n "$rest" ] || return 1
    printf '%s' "$rest"
}

server_replenish_bucket_from_id() {
    bucket_sid="$1"
    bucket_cache="$2"
    [ -n "$bucket_sid" ] || return 1
    [ -s "$bucket_cache" ] || return 1
    bucket_name=$(server_name_from_id "$bucket_sid" "$bucket_cache" || true)
    [ -n "$bucket_name" ] || return 1
    server_replenish_bucket_from_name "$bucket_name"
}

build_replenished_selected_ids() {
    replenish_old_selected_file="$1"
    replenish_old_cache="$2"
    replenish_new_cache="$3"
    replenish_out_file="$4"
    replenish_surviving_tmp="$TMP_DIR/replenish.surviving.$$.$RANDOM.txt"
    replenish_missing_tmp="$TMP_DIR/replenish.missing.$$.$RANDOM.txt"
    replenish_new_only_tmp="$TMP_DIR/replenish.new_only.$$.$RANDOM.txt"

    : > "$replenish_out_file"
    [ -s "$replenish_new_cache" ] || return 0

    build_available_selected_ids "$replenish_old_selected_file" "$replenish_new_cache" "$replenish_surviving_tmp"
    if [ -s "$replenish_surviving_tmp" ]; then
        cp "$replenish_surviving_tmp" "$replenish_out_file"
    fi

    [ -s "$replenish_old_selected_file" ] || return 0
    [ -s "$replenish_old_cache" ] || return 0

    : > "$replenish_missing_tmp"
    while IFS= read -r sid || [ -n "$sid" ]; do
        [ -n "$sid" ] || continue
        if ! server_cache_has_id "$sid" "$replenish_new_cache"; then
            printf '%s\n' "$sid" >> "$replenish_missing_tmp"
        fi
    done < "$replenish_old_selected_file"
    [ -s "$replenish_missing_tmp" ] || return 0

    : > "$replenish_new_only_tmp"
    while IFS="$(printf '\t')" read -r sid sname stag sline; do
        [ -n "$sid" ] || continue
        if ! server_cache_has_id "$sid" "$replenish_old_cache"; then
            printf '%s\n' "$sid" >> "$replenish_new_only_tmp"
        fi
    done < "$replenish_new_cache"
    [ -s "$replenish_new_only_tmp" ] || return 0

    while IFS= read -r missing_sid || [ -n "$missing_sid" ]; do
        [ -n "$missing_sid" ] || continue
        bucket=$(server_replenish_bucket_from_id "$missing_sid" "$replenish_old_cache" || true)
        [ -n "$bucket" ] || continue

        replacement_sid=""
        while IFS="$(printf '\t')" read -r cand_sid cand_name cand_tag cand_line; do
            [ -n "$cand_sid" ] || continue
            grep -Fxq "$cand_sid" "$replenish_new_only_tmp" 2>/dev/null || continue
            grep -Fxq "$cand_sid" "$replenish_out_file" 2>/dev/null && continue
            cand_bucket=$(server_replenish_bucket_from_name "$cand_name" || true)
            [ -n "$cand_bucket" ] || continue
            [ "$cand_bucket" = "$bucket" ] || continue
            replacement_sid="$cand_sid"
            break
        done < "$replenish_new_cache"

        if [ -n "$replacement_sid" ]; then
            printf '%s\n' "$replacement_sid" >> "$replenish_out_file"
        fi
    done < "$replenish_missing_tmp"
}

repair_persisted_selection_file_if_needed() {
    src="$1"
    cache="$2"
    temp_file="$TMP_DIR/selection_repair.$$.$RANDOM.json"

    [ -s "$src" ] || return 0
    [ -s "$cache" ] || return 0

    sanitize_json_servers_against_cache "$src" "$cache" "$temp_file"
    [ -f "$temp_file" ] || return 0

    src_hash=$(md5sum "$src" 2>/dev/null | awk '{print $1}' | tr -d '\n')
    tmp_hash=$(md5sum "$temp_file" 2>/dev/null | awk '{print $1}' | tr -d '\n')
    if [ -n "$tmp_hash" ] && [ "$src_hash" != "$tmp_hash" ]; then
        copy_text_file_clean "$temp_file" "$src"
    fi
    rm -f "$temp_file"
}

repair_persisted_selected_state_if_needed() {
    cache="${1:-$SERVERS_CACHE}"
    [ -s "$cache" ] || return 0
    repair_persisted_selection_file_if_needed "$SETTINGS_FILE" "$cache"
    repair_persisted_selection_file_if_needed "$PAYLOAD_FILE" "$cache"
    settings_self_heal_from_stronger_state "$cache"
}

md5_line() {
    printf '%s' "$1" | md5sum | awk '{print $1}'
}

server_tag_from_id() {
    printf 'srv-%s' "$1"
}

share_link_protocol_from_line() {
    share_line="$1"
    case "$share_line" in
        vless://*) printf 'vless' ;;
        trojan://*) printf 'trojan' ;;
        hy2://*|hysteria2://*) printf 'hysteria2' ;;
        *) return 1 ;;
    esac
}

share_link_protocol_label() {
    share_protocol="$1"
    case "$share_protocol" in
        vless) printf 'VLESS' ;;
        trojan) printf 'Trojan' ;;
        hysteria2) printf 'Hysteria2' ;;
        *) printf 'ShareLink' ;;
    esac
}

share_link_protocol_label_from_line() {
    share_line="$1"
    share_protocol=$(share_link_protocol_from_line "$share_line" || true)
    case "$share_protocol" in
        vless)
            share_no_name="${share_line%%#*}"
            share_params="${share_no_name#*\?}"
            [ "$share_params" = "$share_no_name" ] && share_params=""
            share_security=$(share_link_query_value_any "$share_params" security type_security tls || true)
            share_pbk=$(share_link_query_value_any "$share_params" pbk publicKey public_key || true)
            share_security=$(share_link_lower "$share_security")
            if [ "$share_security" = "reality" ] || [ -n "$share_pbk" ]; then
                printf 'VLESS + Reality'
            else
                printf 'VLESS'
            fi
            ;;
        trojan) printf 'Trojan' ;;
        hysteria2) printf 'Hysteria2' ;;
        *) share_link_protocol_label "$share_protocol" ;;
    esac
}

share_link_label_decode() {
    share_label="$1"
    share_raw_label="$share_label"
    share_decoded_input=$(printf '%s' "$share_label" | sed 's/+/ /g')
    share_decoded=$(printf '%b' "$(printf '%s' "$share_decoded_input" | sed 's/%/\\x/g')" 2>/dev/null || true)
    if [ -n "$share_decoded" ]; then
        printf '%s' "$share_decoded"
    else
        printf '%s' "$share_raw_label"
    fi
}

share_link_query_value() {
    share_params="$1"
    share_key="$2"
    [ -n "$share_params" ] || return 1
    share_value=$(printf '%s' "$share_params" | tr '&' '\n' | sed -n "s/^${share_key}=//p" | sed -n '1p')
    [ -n "$share_value" ] || return 1
    url_component_decode "$share_value"
}

share_link_query_value_any() {
    share_params="$1"
    shift
    for share_key in "$@"; do
        share_value=$(share_link_query_value "$share_params" "$share_key" || true)
        if [ -n "$share_value" ]; then
            printf '%s' "$share_value"
            return 0
        fi
    done
    return 1
}

share_link_lower() {
    printf '%s' "$1" | tr 'A-Z' 'a-z'
}

share_link_truthy() {
    share_bool=$(share_link_lower "$1")
    case "$share_bool" in
        1|true|yes|on) return 0 ;;
    esac
    return 1
}

share_link_query_truthy_any() {
    share_params="$1"
    shift
    share_value=$(share_link_query_value_any "$share_params" "$@" || true)
    share_link_truthy "$share_value"
}

share_link_first_csv_value() {
    printf '%s' "$1" | tr ',' '\n' | sed -n '1{s/^[[:space:]]*//;s/[[:space:]]*$//;p;}'
}

share_link_json_array_from_csv() {
    share_csv="$1"
    share_tmp="$TMP_DIR/share.csv.$$.$RANDOM.json"
    : > "$share_tmp"
    printf '%s' "$share_csv" | tr ',' '\n' | while IFS= read -r share_item || [ -n "$share_item" ]; do
        share_trimmed=$(printf '%s' "$share_item" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [ -n "$share_trimmed" ] || continue
        printf '"%s",\n' "$(json_escape "$share_trimmed")"
    done > "$share_tmp"
    sed '$ s/,$//' "$share_tmp" 2>/dev/null | tr '\n' ' '
    rm -f "$share_tmp"
}

share_link_split_host_port() {
    share_host_port="$1"
    share_host_port=${share_host_port%%/*}
    share_host=""
    share_port=""
    case "$share_host_port" in
        \[*\]:*)
            share_host=$(printf '%s' "$share_host_port" | sed -n 's/^\[\([^]]*\)\]:.*/\1/p')
            share_port=$(printf '%s' "$share_host_port" | sed -n 's/^\[[^]]*\]:\([0-9][0-9]*\)$/\1/p')
            ;;
        *)
            share_host=${share_host_port%:*}
            share_port=${share_host_port##*:}
            [ "$share_host" = "$share_host_port" ] && share_host=""
            ;;
    esac
    [ -n "$share_host" ] || return 1
    [ -n "$share_port" ] || return 1
    case "$share_port" in
        *[!0-9]*) return 1 ;;
    esac
    printf '%s\t%s\n' "$share_host" "$share_port"
}

share_link_endpoint_from_line() {
    share_line="$1"
    share_protocol=$(share_link_protocol_from_line "$share_line" || true)
    [ -n "$share_protocol" ] || return 1
    share_core=${share_line%%#*}
    share_core=${share_core%%\?*}
    share_rest=$(printf '%s' "$share_core" | sed 's#^[a-zA-Z0-9]\+://##')
    share_host_port=${share_rest##*@}
    share_link_split_host_port "$share_host_port"
}

server_name_from_line() {
    line="$1"
    share_name=""
    share_fragment="${line#*#}"
    if [ "$share_fragment" != "$line" ] && [ -n "$share_fragment" ]; then
        share_name=$(share_link_label_decode "$share_fragment")
    fi
    if [ -z "$share_name" ]; then
        share_protocol=$(share_link_protocol_from_line "$line" || true)
        share_name=$(share_link_protocol_label_from_line "$line")
    fi
    [ -n "$share_name" ] || share_name="server"
    printf '%s' "$share_name"
}

share_link_lines_from_file() {
    file="$1"
    [ -f "$file" ] || return 0
    grep -E '^(vless|trojan|hy2|hysteria2)://' "$file" || true
}

build_server_cache() {
    src="$1"
    out="$2"
    : > "$out"
    [ -f "$src" ] || return 0
    while IFS= read -r line || [ -n "$line" ]; do
        share_protocol=$(share_link_protocol_from_line "$line" || true)
        [ -n "$share_protocol" ] || continue
        share_link_endpoint_from_line "$line" >/dev/null 2>&1 || continue
        [ -n "$line" ] || continue
        id=$(md5_line "$line")
        name=$(server_name_from_line "$line")
        tag=$(server_tag_from_id "$id")
        printf '%s\t%s\t%s\t%s\n' "$id" "$name" "$tag" "$line" >> "$out"
    done < "$src"
}

print_servers_array() {
    render_cache="$1"
    render_active_sid="${2:-}"
    render_selected_override_file="${3:-}"
    selected_tmp="$TMP_DIR/selected_ids.txt"
    selected_available_tmp="$TMP_DIR/selected_ids.available.runtime.txt"
    render_seen_tmp="$TMP_DIR/render_servers.seen.$$.$RANDOM.txt"
    [ -n "$render_active_sid" ] || render_active_sid=$(current_active_server_id || true)
    if [ -n "$render_selected_override_file" ] && [ -f "$render_selected_override_file" ]; then
        cp "$render_selected_override_file" "$selected_tmp"
    else
        settings_get_selected_ids "$render_cache" > "$selected_tmp"
    fi
    build_available_selected_ids "$selected_tmp" "$render_cache" "$selected_available_tmp"
    : > "$render_seen_tmp"
    printf '['
    first=1
    [ -f "$render_cache" ] || { printf ']'; rm -f "$selected_tmp" "$selected_available_tmp" "$render_seen_tmp"; return; }
    while IFS="$(printf '\t')" read -r sid sname stag sline; do
        [ -n "$sid" ] || continue
        if grep -Fxq "$sid" "$render_seen_tmp" 2>/dev/null; then
            continue
        fi
        printf '%s\n' "$sid" >> "$render_seen_tmp"
        selected="false"
        active="false"
        if grep -Fxq "$sid" "$selected_available_tmp" 2>/dev/null; then
            selected="true"
        fi
        if [ -n "$render_active_sid" ] && [ "$sid" = "$render_active_sid" ]; then
            active="true"
        fi
        esc_name=$(json_escape "$sname")
        share_protocol=$(share_link_protocol_from_line "$sline" || true)
        share_protocol_label=$(share_link_protocol_label_from_line "$sline")
        [ $first -eq 0 ] && printf ','
        printf '{"id":"%s","name":"%s","protocol":"%s","protocol_label":"%s","selected":%s,"active":%s}' \
            "$sid" "$esc_name" "$(json_escape "$share_protocol")" "$(json_escape "$share_protocol_label")" "$selected" "$active"
        first=0
    done < "$render_cache"
    printf ']'
    rm -f "$selected_tmp" "$selected_available_tmp" "$render_seen_tmp"
}

current_mode_label() {
    ensure_mode_file_for_running_runtime >/dev/null 2>&1 || true
    if [ -s "$MODE_FILE" ]; then
        cat "$MODE_FILE"
    else
        printf 'auto_redirect / auto_detect_interface / strict_route=true'
    fi
}

runtime_config_path() {
    ps w 2>/dev/null | sed -n 's#.*sing-box run -c \([^ ]*\).*#\1#p' | head -n 1
}

mode_label_from_config_file() {
    config_file="$1"
    [ -s "$config_file" ] || return 1

    mode_name="classic"
    route_mode="auto_detect_interface"
    strict_mode="true"

    if grep -q '"auto_redirect"[[:space:]]*:[[:space:]]*true' "$config_file" 2>/dev/null; then
        mode_name="auto_redirect"
    fi
    if grep -q '"default_interface"[[:space:]]*:' "$config_file" 2>/dev/null; then
        route_mode="default_interface"
    fi
    if grep -q '"strict_route"[[:space:]]*:[[:space:]]*false' "$config_file" 2>/dev/null; then
        strict_mode="false"
    fi

    printf '%s / %s / strict_route=%s' "$mode_name" "$route_mode" "$strict_mode"
}

ensure_mode_file_for_running_runtime() {
    [ -s "$MODE_FILE" ] && return 0
    pidof sing-box >/dev/null 2>&1 || return 1

    runtime_cfg=$(runtime_config_path || true)
    [ -n "$runtime_cfg" ] || runtime_cfg="$CONFIG_FILE"

    mode_label=$(mode_label_from_config_file "$runtime_cfg" || true)
    [ -n "$mode_label" ] || return 1

    printf '%s' "$mode_label" > "$MODE_FILE"
    return 0
}

current_mode_name() {
    case "$(current_mode_label)" in
        auto_redirect*) printf 'auto_redirect' ;;
        *) printf 'mixed' ;;
    esac
}

current_route_mode() {
    case "$(current_mode_label)" in
        *" / default_interface / "*) printf 'default_interface' ;;
        *) printf 'auto_detect_interface' ;;
    esac
}

current_strict_mode() {
    case "$(current_mode_label)" in
        *"strict_route=false"*) printf 'false' ;;
        *) printf 'true' ;;
    esac
}

count_lines_in_file() {
    file="$1"
    if [ ! -s "$file" ]; then
        printf '0'
        return 0
    fi
    awk 'END { print NR + 0 }' "$file" 2>/dev/null | tr -d '[:space:]'
}

append_runtime_note() {
    note="$1"
    [ -n "$note" ] || return 0
    printf '%s %s\n' "$(date '+%F %T')" "$note" >> "$LOG_FILE"
}

clear_active_server_observation() {
    rm -f "$ACTIVE_SERVER_OBS_FILE"
}

last_proxy_observation_line() {
    [ -s "$LOG_FILE" ] || return 1
    tail -n 400 "$LOG_FILE" 2>/dev/null | tr -d '\033' | sed 's/\[[0-9;]*m//g' | grep -E 'outbound/(vless|trojan|hysteria2)\[srv-' | tail -n 1
}

refresh_active_server_observation() {
    line=$(last_proxy_observation_line || true)
    [ -n "$line" ] || return 0

    sid=$(printf '%s' "$line" | sed -n 's/.*outbound\/[a-z0-9-]*\[srv-\([0-9a-f]\{32\}\)\].*/\1/p')
    [ -n "$sid" ] || return 0

    saved_sid=""
    saved_signature=""
    saved_epoch=""
    if [ -s "$ACTIVE_SERVER_OBS_FILE" ]; then
        saved_epoch=$(sed -n '1p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
        saved_sid=$(sed -n '2p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
        saved_signature=$(sed -n '3p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
    fi

    current_epoch=$(now_epoch)
    needs_refresh="false"
    if [ "$sid" != "$saved_sid" ] || [ "$line" != "$saved_signature" ]; then
        needs_refresh="true"
    else
        case "$saved_epoch" in
            ''|*[!0-9]*)
                needs_refresh="true"
                ;;
            *)
                obs_age=$(( current_epoch - saved_epoch ))
                if [ "$obs_age" -ge "$ACTIVE_SERVER_OBS_REFRESH_INTERVAL" ] 2>/dev/null; then
                    needs_refresh="true"
                fi
                ;;
        esac
    fi

    if [ "$needs_refresh" = "true" ]; then
        {
            printf '%s\n' "$current_epoch"
            printf '%s\n' "$sid"
            printf '%s\n' "$line"
        } > "$ACTIVE_SERVER_OBS_FILE"
    fi
}

active_server_sid_is_runtime_eligible() {
    sid="$1"
    [ -n "$sid" ] || return 1
    if [ -s "$ACTIVE_SELECTED_IDS_FILE" ]; then
        grep -Fxq "$sid" "$ACTIVE_SELECTED_IDS_FILE" 2>/dev/null
        return $?
    fi
    if [ -s "$CONFIG_FILE" ]; then
        grep -Fq "srv-$sid" "$CONFIG_FILE" 2>/dev/null
        if [ $? -eq 0 ]; then
            return 0
        fi
    fi
    if [ -s "$SERVERS_CACHE" ]; then
        server_cache_has_id "$sid" "$SERVERS_CACHE"
        return $?
    fi
    return 1
}

current_active_server_id() {
    stale_obs_sid=""
    if [ -s "$ACTIVE_SERVER_OBS_FILE" ]; then
        obs_epoch=$(sed -n '1p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
        obs_sid=$(sed -n '2p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
        if [ -n "$obs_epoch" ] && [ -n "$obs_sid" ]; then
            stale_obs_sid="$obs_sid"
            case "$obs_epoch" in
                ''|*[!0-9]*) ;;
                *)
                    current_epoch=$(now_epoch)
                    age=$(( current_epoch - obs_epoch ))
                    if [ "$age" -le "$ACTIVE_SERVER_OBS_TTL" ] 2>/dev/null && active_server_sid_is_runtime_eligible "$obs_sid"; then
                        printf '%s' "$obs_sid"
                        return 0
                    fi
                    ;;
            esac
        fi
    fi

    refresh_active_server_observation
    [ -s "$ACTIVE_SERVER_OBS_FILE" ] || return 1

    obs_epoch=$(sed -n '1p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
    obs_sid=$(sed -n '2p' "$ACTIVE_SERVER_OBS_FILE" 2>/dev/null || true)
    [ -n "$obs_epoch" ] || return 1
    [ -n "$obs_sid" ] || return 1

    case "$obs_epoch" in
        ''|*[!0-9]*) return 1 ;;
    esac

    current_epoch=$(now_epoch)
    age=$(( current_epoch - obs_epoch ))
    if [ "$age" -le "$ACTIVE_SERVER_OBS_TTL" ] 2>/dev/null; then
        printf '%s' "$obs_sid"
        return 0
    fi

    if pidof sing-box >/dev/null 2>&1 && [ -n "$stale_obs_sid" ] && active_server_sid_is_runtime_eligible "$stale_obs_sid"; then
        printf '%s' "$stale_obs_sid"
        return 0
    fi
    return 1
}

ensure_service_dependency_dirs() {
    mkdir -p "$SERVICE_DEPS_DIR" "$SERVICE_DEP_CANDIDATE_DIR" "$SERVICE_DEP_ACCEPTED_DIR" "$SERVICE_DEP_REJECTED_DIR"
    touch "$SERVICE_DEP_SEEN_FILE" 2>/dev/null || true
}

service_dependency_review_file() {
    review_state="$1"
    service_id="$2"
    case "$review_state" in
        accepted) printf '%s/%s.tsv' "$SERVICE_DEP_ACCEPTED_DIR" "$service_id" ;;
        rejected) printf '%s/%s.tsv' "$SERVICE_DEP_REJECTED_DIR" "$service_id" ;;
        *) return 1 ;;
    esac
}

service_dependency_review_domain_exists_in_file() {
    file="$1"
    domain="$2"
    [ -n "$domain" ] || return 1
    [ -s "$file" ] || return 1
    awk -F '\t' -v lookup="$domain" '$1 == lookup { found=1; exit } END { exit(found ? 0 : 1) }' "$file"
}

service_dependency_review_exists() {
    review_state="$1"
    service_id="$2"
    domain="$3"
    file=$(service_dependency_review_file "$review_state" "$service_id") || return 1
    service_dependency_review_domain_exists_in_file "$file" "$domain"
}

service_dependency_any_review_exists() {
    service_id="$1"
    domain="$2"
    service_dependency_review_exists accepted "$service_id" "$domain" && return 0
    service_dependency_review_exists rejected "$service_id" "$domain" && return 0
    return 1
}

service_dependency_candidate_exists() {
    service_id="$1"
    domain="$2"
    file=$(service_dependency_candidate_file "$service_id")
    [ -s "$file" ] || return 1
    awk -F '\t' -v lookup="$domain" '$1 == lookup { found=1; exit } END { exit(found ? 0 : 1) }' "$file"
}

service_dependency_known_domain() {
    service_id="$1"
    domain="$2"
    service_dependency_candidate_exists "$service_id" "$domain" && return 0
    service_dependency_any_review_exists "$service_id" "$domain" && return 0
    return 1
}

service_dependency_update_review_file() {
    file="$1"
    domain="$2"
    now_ts=$(now_epoch)
    tmp="$TMP_DIR/service_dep_review.$$.$RANDOM.tsv"
    ensure_service_dependency_dirs
    touch "$file" 2>/dev/null || true
    awk -F '\t' -v OFS='\t' -v domain="$domain" -v now_ts="$now_ts" '
        BEGIN { found = 0 }
        $1 == domain {
            found = 1
            first_seen = ($2 ~ /^[0-9]+$/ ? $2 : now_ts)
            print $1, first_seen, now_ts
            next
        }
        NF > 0 { print }
        END {
            if (!found) {
                print domain, now_ts, now_ts
            }
        }
    ' "$file" > "$tmp"
    mv "$tmp" "$file"
}

service_dependency_remove_review_from_file() {
    file="$1"
    domain="$2"
    tmp="$TMP_DIR/service_dep_review_remove.$$.$RANDOM.tsv"
    touch "$file" 2>/dev/null || true
    awk -F '\t' -v OFS='\t' -v domain="$domain" '$1 != domain && NF > 0 { print }' "$file" > "$tmp"
    mv "$tmp" "$file"
}

service_dependency_set_review_decision() {
    review_state="$1"
    service_id="$2"
    domain="$3"
    case "$review_state" in
        accepted)
            target_file=$(service_dependency_review_file accepted "$service_id")
            opposite_file=$(service_dependency_review_file rejected "$service_id")
            ;;
        rejected)
            target_file=$(service_dependency_review_file rejected "$service_id")
            opposite_file=$(service_dependency_review_file accepted "$service_id")
            ;;
        *)
            return 1
            ;;
    esac
    service_dependency_remove_review_from_file "$opposite_file" "$domain"
    service_dependency_update_review_file "$target_file" "$domain"
}

service_dependency_clear_review_decision() {
    service_id="$1"
    domain="$2"
    accepted_file=$(service_dependency_review_file accepted "$service_id")
    rejected_file=$(service_dependency_review_file rejected "$service_id")
    service_dependency_remove_review_from_file "$accepted_file" "$domain"
    service_dependency_remove_review_from_file "$rejected_file" "$domain"
}

service_dependency_last_scan_epoch() {
    if [ -s "$SERVICE_DEP_LAST_SCAN_FILE" ]; then
        cat "$SERVICE_DEP_LAST_SCAN_FILE" 2>/dev/null || echo 0
        return 0
    fi
    echo 0
}

write_service_dependency_last_scan_epoch() {
    printf '%s' "$(now_epoch)" > "$SERVICE_DEP_LAST_SCAN_FILE"
}

service_profile_rows() {
    cat <<'SERVICE_PROFILES'
youtube	YouTube	youtube.com youtu.be
chatgpt	ChatGPT	chatgpt.com chat.openai.com
gemini	Gemini	gemini.google.com
codex	Codex	codex.openai.com
SERVICE_PROFILES
}

service_profile_exists() {
    lookup_service="$1"
    service_profile_rows | awk -F '\t' -v sid="$lookup_service" '$1 == sid { found=1; exit } END { exit(found ? 0 : 1) }'
}

service_profile_name() {
    lookup_service="$1"
    service_profile_rows | awk -F '\t' -v sid="$lookup_service" '$1 == sid { print $2; exit }'
}

service_profile_seeds() {
    lookup_service="$1"
    service_profile_rows | awk -F '\t' -v sid="$lookup_service" '$1 == sid { print $3; exit }'
}

service_dependency_candidate_file() {
    printf '%s/%s.tsv' "$SERVICE_DEP_CANDIDATE_DIR" "$1"
}

service_dependency_state_for_hits() {
    hits="${1:-0}"
    case "$hits" in
        ''|*[!0-9]*) hits=0 ;;
    esac
    if [ "$hits" -ge "$SERVICE_DEP_SUGGESTED_HITS" ]; then
        printf '%s' "suggested"
        return 0
    fi
    if [ "$hits" -ge "$SERVICE_DEP_PROBATION_HITS" ]; then
        printf '%s' "probation"
        return 0
    fi
    printf '%s' "candidate"
}

prune_service_dependency_candidates_file() {
    file="$1"
    now_ts=$(now_epoch)
    cutoff=$((now_ts - SERVICE_DEP_TTL_SECONDS))
    tmp="$TMP_DIR/service_dep_prune.$$.$RANDOM.tsv"
    touch "$file" 2>/dev/null || true
    awk -F '\t' -v OFS='\t' -v cutoff="$cutoff" '
        NF > 0 {
            last_seen = ($3 ~ /^[0-9]+$/ ? $3 : 0)
            if (last_seen >= cutoff) {
                print
            }
        }
    ' "$file" > "$tmp"
    mv "$tmp" "$file"
}

prune_all_service_dependency_candidates() {
    ensure_service_dependency_dirs
    service_profile_rows | while IFS="$(printf '\t')" read -r service_id service_name seeds; do
        [ -n "$service_id" ] || continue
        prune_service_dependency_candidates_file "$(service_dependency_candidate_file "$service_id")"
    done
}

reset_service_dependency_state() {
    ensure_service_dependency_dirs
    rm -f "$SERVICE_DEP_CANDIDATE_DIR"/*.tsv 2>/dev/null || true
    rm -f "$SERVICE_DEP_ACCEPTED_DIR"/*.tsv 2>/dev/null || true
    rm -f "$SERVICE_DEP_REJECTED_DIR"/*.tsv 2>/dev/null || true
    rm -f "$SERVICE_DEP_LAST_SCAN_FILE" 2>/dev/null || true
    : > "$SERVICE_DEP_SEEN_FILE"
}

print_service_dependency_summary_json() {
    service_id="$1"
    candidate_file=$(service_dependency_candidate_file "$service_id")
    accepted_file=$(service_dependency_review_file accepted "$service_id")
    rejected_file=$(service_dependency_review_file rejected "$service_id")
    candidate_count=0
    probation_count=0
    suggested_count=0
    accepted_count=$(count_lines_in_file "$accepted_file")
    rejected_count=$(count_lines_in_file "$rejected_file")

    touch "$candidate_file" "$accepted_file" "$rejected_file" 2>/dev/null || true
    prune_service_dependency_candidates_file "$candidate_file"

    while IFS="$(printf '\t')" read -r domain first_seen last_seen hits score || [ -n "$domain" ]; do
        [ -n "$domain" ] || continue
        if service_dependency_review_domain_exists_in_file "$accepted_file" "$domain"; then
            continue
        fi
        if service_dependency_review_domain_exists_in_file "$rejected_file" "$domain"; then
            continue
        fi
        state=$(service_dependency_state_for_hits "$hits")
        case "$state" in
            suggested) suggested_count=$((suggested_count + 1)) ;;
            probation) probation_count=$((probation_count + 1)) ;;
            *) candidate_count=$((candidate_count + 1)) ;;
        esac
    done < "$candidate_file"

    printf '{"candidate_count":%s,"probation_count":%s,"suggested_count":%s,"accepted_count":%s,"rejected_count":%s}' \
        "$candidate_count" "$probation_count" "$suggested_count" "$accepted_count" "$rejected_count"
}

domain_matches_seed() {
    host="$1"
    seed="$2"
    [ -n "$host" ] || return 1
    [ -n "$seed" ] || return 1
    [ "$host" = "$seed" ] && return 0
    case "$host" in
        *."$seed") return 0 ;;
    esac
    return 1
}

host_matches_service_seeds() {
    host="$1"
    seeds="$2"
    for seed in $seeds; do
        if domain_matches_seed "$host" "$seed"; then
            return 0
        fi
    done
    return 1
}

dependency_noise_domain() {
    host="$1"
    case "$host" in
        google-analytics.com|*.google-analytics.com|doubleclick.net|*.doubleclick.net|googletagmanager.com|*.googletagmanager.com|googlesyndication.com|*.googlesyndication.com|sentry.io|*.sentry.io|segment.io|*.segment.io)
            return 0
            ;;
    esac
    return 1
}

extract_domain_from_observation_line() {
    line="$1"
    host=$(printf '%s' "$line" | sed -n 's/.*connection to \([^: ]*\):[0-9][0-9]*.*/\1/p')
    [ -n "$host" ] || return 1
    normalize_domain_value "$host" 2>/dev/null || return 1
}

service_dependency_record_hit() {
    service_id="$1"
    domain="$2"
    now_ts=$(now_epoch)
    file=$(service_dependency_candidate_file "$service_id")
    tmp="$TMP_DIR/service_dep.$service_id.$$.$RANDOM.tsv"

    ensure_service_dependency_dirs
    touch "$file" 2>/dev/null || true

    awk -F '\t' -v OFS='\t' -v domain="$domain" -v now_ts="$now_ts" '
        BEGIN { found = 0 }
        $1 == domain {
            found = 1
            hits = ($4 ~ /^[0-9]+$/ ? $4 : 0) + 1
            score = ($5 ~ /^[0-9]+$/ ? $5 : 0) + 1
            print $1, $2, now_ts, hits, score
            next
        }
        NF > 0 { print }
        END {
            if (!found) {
                print domain, now_ts, now_ts, 1, 1
            }
        }
    ' "$file" > "$tmp"

    sort -t "$(printf '\t')" -k5,5nr -k4,4nr -k3,3nr "$tmp" | head -n "$SERVICE_DEP_MAX_CANDIDATES_PER_SERVICE" > "$file"
    rm -f "$tmp"
}

collect_recent_domain_observation_stream() {
    ensure_service_dependency_dirs
    dep_stream_tmp="$TMP_DIR/service_dep.stream.$$.$RANDOM.txt"
    {
        for src in "$LOG_FILE.1" "$LOG_FILE"; do
            [ -s "$src" ] || continue
            tail -n "$SERVICE_DEP_LOG_TAIL_LINES" "$src" 2>/dev/null
        done
    } | tr -d '\033' | sed 's/\[[0-9;]*m//g' | sed -n 's/.*connection to \([^: ]*\):[0-9][0-9]*.*/\1/p' | tr 'A-Z' 'a-z' | sed 's/^\*\.//; s/^\.+//; s/\.+$//' | awk '
        $0 == "" { next }
        $0 ~ /(^|[.])google-analytics[.]com$/ { next }
        $0 ~ /(^|[.])doubleclick[.]net$/ { next }
        $0 ~ /(^|[.])googletagmanager[.]com$/ { next }
        $0 ~ /(^|[.])googlesyndication[.]com$/ { next }
        $0 ~ /(^|[.])sentry[.]io$/ { next }
        $0 ~ /(^|[.])segment[.]io$/ { next }
        { print }
    ' > "$dep_stream_tmp"

    cat "$dep_stream_tmp"
    rm -f "$dep_stream_tmp"
}

service_dependency_scan_all() {
    profiles_tmp="$TMP_DIR/service_dep_profiles.$$.$RANDOM.tsv"
    stream_tmp="$TMP_DIR/service_dep_hosts.$$.$RANDOM.txt"
    match_tmp="$TMP_DIR/service_dep_match.$$.$RANDOM.tsv"
    batch_dir="$TMP_DIR/service_dep_batch.$$.$RANDOM"
    ensure_service_dependency_dirs
    mkdir -p "$batch_dir"
    service_profile_rows > "$profiles_tmp"
    collect_recent_domain_observation_stream > "$stream_tmp"

    while IFS="$(printf '\t')" read -r service_id service_name seeds; do
        eval "dep_window_$service_id=0"
    done < "$profiles_tmp"

    while IFS= read -r host || [ -n "$host" ]; do
        [ -n "$host" ] || continue
        : > "$match_tmp"
        while IFS="$(printf '\t')" read -r service_id service_name seeds; do
            if host_matches_service_seeds "$host" "$seeds"; then
                printf '%s\n' "$service_id" >> "$match_tmp"
            fi
        done < "$profiles_tmp"

        if [ -s "$match_tmp" ]; then
            while IFS="$(printf '\t')" read -r service_id service_name seeds; do
                eval "dep_window_$service_id=0"
            done < "$profiles_tmp"
            while IFS="$(printf '\t')" read -r service_id service_name seeds; do
                if grep -Fxq "$service_id" "$match_tmp" 2>/dev/null; then
                    eval "dep_window_$service_id=$SERVICE_DEP_WINDOW_LINES"
                fi
            done < "$profiles_tmp"
            continue
        fi

        while IFS="$(printf '\t')" read -r service_id service_name seeds; do
            eval "window=\${dep_window_$service_id:-0}"
            if [ "$window" -gt 0 ] 2>/dev/null; then
                printf '%s\n' "$host" >> "$batch_dir/$service_id.txt"
                window=$((window - 1))
                eval "dep_window_$service_id=$window"
            fi
        done < "$profiles_tmp"
    done < "$stream_tmp"

    while IFS="$(printf '\t')" read -r service_id service_name seeds; do
        batch_file="$batch_dir/$service_id.txt"
        [ -s "$batch_file" ] || continue
        sort -u "$batch_file" | while IFS= read -r domain || [ -n "$domain" ]; do
            [ -n "$domain" ] || continue
            service_dependency_record_hit "$service_id" "$domain"
        done
    done < "$profiles_tmp"

    rm -rf "$batch_dir"
    rm -f "$profiles_tmp" "$stream_tmp" "$match_tmp"
}

print_service_dependency_reviewed_json() {
    review_state="$1"
    service_id="$2"
    ensure_service_dependency_dirs
    review_file=$(service_dependency_review_file "$review_state" "$service_id")
    candidate_file=$(service_dependency_candidate_file "$service_id")
    now_ts=$(now_epoch)
    touch "$review_file" "$candidate_file" 2>/dev/null || true
    prune_service_dependency_candidates_file "$candidate_file"
    printf '['
    first=1
    while IFS="$(printf '\t')" read -r domain first_decided last_decided || [ -n "$domain" ]; do
        [ -n "$domain" ] || continue
        candidate_line=$(awk -F '\t' -v lookup="$domain" '$1 == lookup { print; exit }' "$candidate_file" 2>/dev/null || true)
        c_first=0
        c_last=0
        hits=0
        score=0
        evidence_state=""
        age_seconds=0
        if [ -n "$candidate_line" ]; then
            c_first=$(printf '%s' "$candidate_line" | awk -F '\t' '{print $2}')
            c_last=$(printf '%s' "$candidate_line" | awk -F '\t' '{print $3}')
            hits=$(printf '%s' "$candidate_line" | awk -F '\t' '{print $4}')
            score=$(printf '%s' "$candidate_line" | awk -F '\t' '{print $5}')
            evidence_state=$(service_dependency_state_for_hits "$hits")
            case "$c_last" in
                ''|*[!0-9]*) c_last=0 ;;
            esac
            if [ "$now_ts" -ge "$c_last" ] 2>/dev/null; then
                age_seconds=$((now_ts - c_last))
            fi
        fi
        [ $first -eq 0 ] && printf ','
        printf '{"domain":"%s","state":"%s","first_decided":%s,"last_decided":%s,"evidence_state":"%s","hits":%s,"score":%s,"age_seconds":%s,"ttl_seconds":%s}' \
            "$(json_escape "$domain")" \
            "$(json_escape "$review_state")" \
            "${first_decided:-0}" \
            "${last_decided:-0}" \
            "$(json_escape "$evidence_state")" \
            "${hits:-0}" \
            "${score:-0}" \
            "$age_seconds" \
            "$SERVICE_DEP_TTL_SECONDS"
        first=0
    done < "$review_file"
    printf ']'
}

print_service_dependency_candidates_json() {
    service_id="$1"
    ensure_service_dependency_dirs
    file=$(service_dependency_candidate_file "$service_id")
    accepted_file=$(service_dependency_review_file accepted "$service_id")
    rejected_file=$(service_dependency_review_file rejected "$service_id")
    sorted_file="$TMP_DIR/service_dep_sorted.$$.$RANDOM.tsv"
    prune_service_dependency_candidates_file "$file"
    now_ts=$(now_epoch)
    touch "$accepted_file" "$rejected_file" 2>/dev/null || true
    printf '['
    first=1
    [ -s "$file" ] || { printf ']'; return 0; }
    sort -t "$(printf '\t')" -k5,5nr -k4,4nr -k3,3nr "$file" | head -n 15 > "$sorted_file"
    while IFS="$(printf '\t')" read -r domain first_seen last_seen hits score || [ -n "$domain" ]; do
        [ -n "$domain" ] || continue
        if service_dependency_review_domain_exists_in_file "$accepted_file" "$domain"; then
            continue
        fi
        if service_dependency_review_domain_exists_in_file "$rejected_file" "$domain"; then
            continue
        fi
        age_seconds=0
        case "$last_seen" in
            ''|*[!0-9]*) last_seen=0 ;;
        esac
        case "$now_ts" in
            ''|*[!0-9]*) now_ts=0 ;;
        esac
        if [ "$now_ts" -ge "$last_seen" ] 2>/dev/null; then
            age_seconds=$((now_ts - last_seen))
        fi
        state=$(service_dependency_state_for_hits "$hits")
        [ $first -eq 0 ] && printf ','
        printf '{"domain":"%s","first_seen":%s,"last_seen":%s,"hits":%s,"score":%s,"age_seconds":%s,"ttl_seconds":%s,"state":"%s","review_ready":%s}' \
            "$(json_escape "$domain")" \
            "${first_seen:-0}" \
            "${last_seen:-0}" \
            "${hits:-0}" \
            "${score:-0}" \
            "$age_seconds" \
            "$SERVICE_DEP_TTL_SECONDS" \
            "$(json_escape "$state")" \
            "$( [ "$state" = "candidate" ] && printf '%s' "false" || printf '%s' "true" )"
        first=0
    done < "$sorted_file"
    rm -f "$sorted_file"
    printf ']'
}

print_service_dependency_status_json() {
    ensure_service_dependency_dirs
    prune_all_service_dependency_candidates
    last_scan_epoch=$(service_dependency_last_scan_epoch)
    printf '['
    first=1
    service_profile_rows | while IFS="$(printf '\t')" read -r service_id service_name seeds; do
        [ -n "$service_id" ] || continue
        file=$(service_dependency_candidate_file "$service_id")
        [ $first -eq 0 ] && printf ','
        printf '{"id":"%s","name":"%s","last_scan_epoch":%s,"summary":' \
            "$(json_escape "$service_id")" \
            "$(json_escape "$service_name")" \
            "$last_scan_epoch"
        print_service_dependency_summary_json "$service_id"
        printf ',"seeds":['
        seed_first=1
        for seed in $seeds; do
            [ $seed_first -eq 0 ] && printf ','
            printf '"%s"' "$(json_escape "$seed")"
            seed_first=0
        done
        printf '],"candidates":'
        print_service_dependency_candidates_json "$service_id"
        printf ',"accepted":'
        print_service_dependency_reviewed_json accepted "$service_id"
        printf ',"rejected":'
        print_service_dependency_reviewed_json rejected "$service_id"
        printf '}'
        first=0
    done
    printf ']'
}

collect_recent_urltest_failures() {
    emitted="false"
    for src in "$LOG_FILE" "$LOG_FILE.1"; do
        [ -s "$src" ] || continue
        matches=$(tail -n 600 "$src" 2>/dev/null | grep 'outbound/urltest\[AUTO-BALANCE\]: dial tcp ' 2>/dev/null | sed -n 's/.*dial tcp \([^: ]*\):\([0-9][0-9]*\):.*/\1\t\2/p' || true)
        if [ -n "$matches" ]; then
            printf '%s\n' "$matches"
            emitted="true"
        fi
    done
    [ "$emitted" = "true" ]
}

server_id_from_endpoint() {
    host="$1"
    port="$2"
    cache="$3"
    [ -n "$host" ] || return 1
    [ -n "$port" ] || return 1
    [ -s "$cache" ] || return 1
    awk -F '\t' -v needle="@$host:$port" '$4 != "" && index($4, needle) > 0 { print $1; exit }' "$cache"
}

server_name_from_id() {
    lookup_sid="$1"
    lookup_cache="$2"
    [ -n "$lookup_sid" ] || return 1
    [ -s "$lookup_cache" ] || return 1
    awk -F '\t' -v needle="$lookup_sid" '$1 == needle { print $2; exit }' "$lookup_cache"
}

summarize_recent_attributed_urltest_failures() {
    cache="$1"
    failure_file="$TMP_DIR/urltest_failures.summary.attributed.txt"
    count_file="$TMP_DIR/urltest_failure_counts.summary.attributed.txt"
    emitted="false"
    [ -s "$cache" ] || return 1

    : > "$failure_file"
    : > "$count_file"
    if ! collect_recent_urltest_failures > "$failure_file"; then
        return 1
    fi
    [ -s "$failure_file" ] || return 1

    sort "$failure_file" | uniq -c | sort -nr | head -n 5 > "$count_file"
    [ -s "$count_file" ] || return 1

    while IFS= read -r raw_line || [ -n "$raw_line" ]; do
        count=$(printf '%s' "$raw_line" | awk '{ print $1 }')
        host=$(printf '%s' "$raw_line" | awk '{ print $2 }')
        port=$(printf '%s' "$raw_line" | awk '{ print $3 }')
        [ -n "$count" ] || continue
        [ -n "$host" ] || continue
        [ -n "$port" ] || continue
        sid=$(server_id_from_endpoint "$host" "$port" "$cache" || true)
        [ -n "$sid" ] || continue
        sname=""
        [ -n "$sid" ] && sname=$(server_name_from_id "$sid" "$cache" || true)
        if [ -n "$sid" ] && [ -n "$sname" ]; then
            printf '%sx %s:%s -> %s (%s)\n' "$count" "$host" "$port" "$sname" "$sid"
        elif [ -n "$sid" ]; then
            printf '%sx %s:%s -> %s\n' "$count" "$host" "$port" "$sid"
        fi
        emitted="true"
    done < "$count_file"

    [ "$emitted" = "true" ]
}

summarize_recent_unmapped_urltest_failures() {
    cache="$1"
    failure_file="$TMP_DIR/urltest_failures.summary.unmapped.txt"
    count_file="$TMP_DIR/urltest_failure_counts.summary.unmapped.txt"
    emitted="false"
    emitted_count=0

    : > "$failure_file"
    : > "$count_file"
    if ! collect_recent_urltest_failures > "$failure_file"; then
        return 1
    fi
    [ -s "$failure_file" ] || return 1

    sort "$failure_file" | uniq -c | sort -nr > "$count_file"
    [ -s "$count_file" ] || return 1

    while IFS= read -r raw_line || [ -n "$raw_line" ]; do
        count=$(printf '%s' "$raw_line" | awk '{ print $1 }')
        host=$(printf '%s' "$raw_line" | awk '{ print $2 }')
        port=$(printf '%s' "$raw_line" | awk '{ print $3 }')
        [ -n "$count" ] || continue
        [ -n "$host" ] || continue
        [ -n "$port" ] || continue
        sid=$(server_id_from_endpoint "$host" "$port" "$cache" || true)
        [ -n "$sid" ] && continue
        printf '%sx %s:%s\n' "$count" "$host" "$port"
        emitted="true"
        emitted_count=$((emitted_count + 1))
        [ "$emitted_count" -lt 5 ] || break
    done < "$count_file"

    [ "$emitted" = "true" ]
}

detect_repeated_urltest_failure_id() {
    cache="$1"
    failure_file="$TMP_DIR/urltest_failures.txt"
    count_file="$TMP_DIR/urltest_failure_counts.txt"
    mapped_file="$TMP_DIR/urltest_failure_counts.mapped.txt"
    mapped_unique_file="$TMP_DIR/urltest_failure_counts.mapped.unique.txt"

    : > "$failure_file"
    : > "$count_file"
    : > "$mapped_file"
    : > "$mapped_unique_file"
    if ! collect_recent_urltest_failures > "$failure_file"; then
        return 1
    fi
    [ -s "$failure_file" ] || return 1

    sort "$failure_file" | uniq -c | sort -nr > "$count_file"

    while IFS= read -r raw_line || [ -n "$raw_line" ]; do
        count=$(printf '%s' "$raw_line" | awk '{ print $1 }')
        host=$(printf '%s' "$raw_line" | awk '{ print $2 }')
        port=$(printf '%s' "$raw_line" | awk '{ print $3 }')
        [ -n "$count" ] || continue
        [ -n "$host" ] || continue
        [ -n "$port" ] || continue
        sid=$(server_id_from_endpoint "$host" "$port" "$cache" || true)
        if [ -n "$sid" ]; then
            printf '%s\t%s\t%s\t%s\n' "$count" "$host" "$port" "$sid" >> "$mapped_file"
            if [ "$count" -ge 2 ] 2>/dev/null; then
                printf '%s' "$sid"
                return 0
            fi
        fi
    done < "$count_file"

    if [ -s "$mapped_file" ]; then
        awk -F '\t' '$4 != "" { print $4 }' "$mapped_file" | sort -u > "$mapped_unique_file"
        unique_count=$(grep -c '.' "$mapped_unique_file" 2>/dev/null || true)
        if [ "$unique_count" -eq 1 ] 2>/dev/null; then
            head -n 1 "$mapped_unique_file" | tr -d '\n'
            return 0
        fi
    fi

    return 1
}

count_recent_urltest_failures_for_server_id() {
    sid="$1"
    cache="$2"
    failure_file="$TMP_DIR/urltest_failures.by_sid.txt"
    count_file="$TMP_DIR/urltest_failure_counts.by_sid.txt"
    total=0

    [ -n "$sid" ] || { printf '0'; return 0; }
    [ -s "$cache" ] || { printf '0'; return 0; }

    : > "$failure_file"
    : > "$count_file"
    if ! collect_recent_urltest_failures > "$failure_file"; then
        printf '0'
        return 0
    fi
    [ -s "$failure_file" ] || { printf '0'; return 0; }

    sort "$failure_file" | uniq -c | sort -nr > "$count_file"
    while IFS= read -r raw_line || [ -n "$raw_line" ]; do
        count=$(printf '%s' "$raw_line" | awk '{ print $1 }')
        host=$(printf '%s' "$raw_line" | awk '{ print $2 }')
        port=$(printf '%s' "$raw_line" | awk '{ print $3 }')
        [ -n "$count" ] || continue
        [ -n "$host" ] || continue
        [ -n "$port" ] || continue
        mapped_sid=$(server_id_from_endpoint "$host" "$port" "$cache" || true)
        [ "$mapped_sid" = "$sid" ] || continue
        total=$((total + count))
    done < "$count_file"

    printf '%s' "$total"
}

detect_quarantine_candidate_id() {
    cache="$1"
    active_sid=$(current_active_server_id || true)

    if [ -n "$active_sid" ]; then
        active_fail_count=$(count_recent_urltest_failures_for_server_id "$active_sid" "$cache")
        if [ "$active_fail_count" -ge 2 ] 2>/dev/null; then
            printf '%s' "$active_sid"
            return 0
        fi
    fi

    detect_repeated_urltest_failure_id "$cache"
}

print_servers_json() {
    cache="$1"
    active_sid="${2:-}"
    selected_override_file="${3:-}"
    printf '{"servers":'
    print_servers_array "$cache" "$active_sid" "$selected_override_file"
    printf '}'
}

fail_json() {
    msg=$(json_escape "$1")
    archive_current_error_if_any
    printf '%s' "$1" > "$ERR_FILE"
    printf '{"status":"error","message":"%s"}\n' "$msg"
    exit 0
}

fail_json_transient() {
    msg=$(json_escape "$1")
    printf '{"status":"error","message":"%s"}\n' "$msg"
    exit 0
}

ok_json() {
    msg=$(json_escape "$1")
    printf '{"status":"success","message":"%s"}\n' "$msg"
    exit 0
}

subscription_source_kind() {
    source_text=$(printf '%s' "$1" | tr -d '\r')
    case "$source_text" in
        http://*|https://*)
            printf 'remote'
            return 0
            ;;
        *vless://*|*trojan://*|*hy2://*|*hysteria2://*)
            printf 'inline'
            return 0
            ;;
    esac
    return 1
}

write_inline_subscription_source() {
    source_text="$1"
    dest="$2"
    rm -f "$dest"
    printf '%s' "$source_text" | tr -d '\r' > "$dest"
    [ -s "$dest" ]
}

prepare_subscription_source_file() {
    source_text="$1"
    dest="$2"
    source_mode=$(subscription_source_kind "$source_text" || true)
    case "$source_mode" in
        remote)
            download_file "$source_text" "$dest"
            ;;
        inline)
            write_inline_subscription_source "$source_text" "$dest"
            ;;
        *)
            return 1
            ;;
    esac
}

download_file() {
    url="$1"
    dest="$2"
    tmp="${dest}.part.$$"
    rm -f "$dest" "$tmp"
    if command -v curl >/dev/null 2>&1; then
        if curl -fsSL --connect-timeout 10 --max-time 90 -A "v2rayN/6.23" "$url" -o "$tmp" >/dev/null 2>&1 && [ -s "$tmp" ]; then
            mv "$tmp" "$dest" && return 0
        fi
        rm -f "$tmp"
    fi
    if command -v wget >/dev/null 2>&1; then
        if wget -qO "$tmp" --timeout=90 --user-agent="v2rayN/6.23" "$url" >/dev/null 2>&1 && [ -s "$tmp" ]; then
            mv "$tmp" "$dest" && return 0
        fi
        rm -f "$tmp"
    fi
    return 1
}

download_file_via_interface() {
    url="$1"
    dest="$2"
    iface="$3"
    tmp="${dest}.part.$$"
    rm -f "$dest" "$tmp"
    command -v curl >/dev/null 2>&1 || return 1
    ip link show "$iface" >/dev/null 2>&1 || return 1
    if curl -fsSL --interface "$iface" --connect-timeout 10 --max-time 90 -A "v2rayN/6.23" "$url" -o "$tmp" >/dev/null 2>&1 && [ -s "$tmp" ]; then
        mv "$tmp" "$dest" && return 0
    fi
    rm -f "$tmp"
    return 1
}

download_refilter_asset() {
    url="$1"
    dest="$2"
    attempts="${3:-3}"
    delay_seconds="${4:-2}"
    if download_file_with_retries "$url" "$dest" "$attempts" "$delay_seconds"; then
        return 0
    fi
    if ! ip link show tun0 >/dev/null 2>&1; then
        return 1
    fi
    i=1
    while [ "$i" -le "$attempts" ]; do
        if download_file_via_interface "$url" "$dest" "tun0"; then
            return 0
        fi
        i=$((i + 1))
        [ "$i" -le "$attempts" ] && sleep "$delay_seconds"
    done
    return 1
}

download_file_with_retries() {
    url="$1"
    dest="$2"
    attempts="${3:-3}"
    delay_seconds="${4:-2}"
    i=1
    while [ "$i" -le "$attempts" ]; do
        if download_file "$url" "$dest"; then
            return 0
        fi
        i=$((i + 1))
        [ "$i" -le "$attempts" ] && sleep "$delay_seconds"
    done
    return 1
}

copy_file_atomic() {
    src="$1"
    dest="$2"
    dest_tmp="$TMP_DIR/.$(basename "$dest").$$.tmp"
    [ -s "$src" ] || return 1
    cp "$src" "$dest_tmp" 2>/dev/null || cat "$src" > "$dest_tmp" 2>/dev/null || return 1
    mv "$dest_tmp" "$dest" 2>/dev/null || {
        cp "$dest_tmp" "$dest" 2>/dev/null || {
            rm -f "$dest_tmp"
            return 1
        }
        rm -f "$dest_tmp"
    }
    [ -s "$dest" ]
}

ensure_update_dirs() {
    mkdir -p "$GOG_UPDATE_DIR" "$GOG_UPDATE_BACKUP_DIR" "$GOG_UPDATE_DOWNLOAD_DIR" 2>/dev/null || true
}

update_manifest_url() {
    upd_manifest_url=""
    if [ -s "$GOG_UPDATE_SETTINGS_FILE" ]; then
        upd_manifest_url=$(json_get_string_from_text "manifest_url" "$(read_text_file_clean "$GOG_UPDATE_SETTINGS_FILE")")
    fi
    case "$upd_manifest_url" in
        http://*|https://*) printf '%s' "$upd_manifest_url" ;;
        *) printf '%s' "$GOG_UPDATE_DEFAULT_MANIFEST_URL" ;;
    esac
}

update_auto_check_enabled() {
    if [ -s "$GOG_UPDATE_SETTINGS_FILE" ]; then
        upd_auto_check=$(json_get_bool_from_text "auto_check_enabled" "$(read_text_file_clean "$GOG_UPDATE_SETTINGS_FILE")")
        [ "$upd_auto_check" = "false" ] && { printf 'false'; return 0; }
    fi
    printf 'true'
}

update_auto_install_enabled() {
    if [ -s "$GOG_UPDATE_SETTINGS_FILE" ]; then
        upd_auto_install=$(json_get_bool_from_text "auto_install_enabled" "$(read_text_file_clean "$GOG_UPDATE_SETTINGS_FILE")")
        [ "$upd_auto_install" = "true" ] && { printf 'true'; return 0; }
    fi
    printf 'false'
}

update_write_settings() {
    upd_manifest_url="$1"
    upd_auto_check="$2"
    upd_auto_install="$3"
    ensure_update_dirs
    case "$upd_manifest_url" in
        http://*|https://*) ;;
        *) upd_manifest_url="$GOG_UPDATE_DEFAULT_MANIFEST_URL" ;;
    esac
    [ "$upd_auto_check" = "false" ] || upd_auto_check="true"
    [ "$upd_auto_install" = "true" ] || upd_auto_install="false"
    upd_settings_tmp="$TMP_DIR/update_settings.$$.$RANDOM.json"
    {
        printf '{'
        printf '"manifest_url":"%s",' "$(json_escape "$upd_manifest_url")"
        printf '"auto_check_enabled":%s,' "$upd_auto_check"
        printf '"auto_install_enabled":%s' "$upd_auto_install"
        printf '}\n'
    } > "$upd_settings_tmp"
    copy_file_atomic "$upd_settings_tmp" "$GOG_UPDATE_SETTINGS_FILE"
    rm -f "$upd_settings_tmp"
}

update_version_sort_key() {
    upd_version="$1"
    printf '%s' "$upd_version" | awk '
        {
            v=$0
            sub(/^v/, "", v)
            sub(/-.*/, "", v)
            n=split(v, parts, ".")
            major=(n>=1 && parts[1] ~ /^[0-9]+$/) ? parts[1] : 0
            minor=(n>=2 && parts[2] ~ /^[0-9]+$/) ? parts[2] : 0
            patch=(n>=3 && parts[3] ~ /^[0-9]+$/) ? parts[3] : 0
            printf "%d\n", major * 1000000 + minor * 1000 + patch
        }
    '
}

update_manifest_signature_status() {
    upd_manifest_url="$1"
    upd_sig_tmp="$TMP_DIR/update_manifest.sig.$$.$RANDOM"
    upd_sig_status="missing"
    rm -f "$upd_sig_tmp"
    if download_file_with_retries "$upd_manifest_url.sig" "$upd_sig_tmp" 1 0; then
        if grep -q 'PLACEHOLDER_SIGNATURE_NOT_FOR_PRODUCTION' "$upd_sig_tmp" 2>/dev/null; then
            upd_sig_status="placeholder"
        elif command -v usign >/dev/null 2>&1 && [ -s "$GOG_UPDATE_TRUSTED_PUB_FILE" ]; then
            # Verification is wired for the future signed manifest flow.
            # Current placeholder manifests remain read-only and non-installable.
            upd_manifest_tmp="${2:-}"
            if [ -n "$upd_manifest_tmp" ] && usign -V -p "$GOG_UPDATE_TRUSTED_PUB_FILE" -m "$upd_manifest_tmp" -x "$upd_sig_tmp" >/dev/null 2>&1; then
                upd_sig_status="verified"
            else
                upd_sig_status="invalid"
            fi
        else
            upd_sig_status="unverified"
        fi
    fi
    rm -f "$upd_sig_tmp"
    printf '%s' "$upd_sig_status"
}

update_print_status_json() {
    upd_state="$1"
    upd_message="$2"
    upd_last_check_epoch="${3:-0}"
    upd_latest_version="${4:-}"
    upd_available="${5:-false}"
    upd_kind="${6:-none}"
    upd_auto_install_allowed="${7:-false}"
    upd_package_url="${8:-}"
    upd_package_sha256="${9:-}"
    shift 9 || true
    upd_package_size="${1:-0}"
    upd_notes_url="${2:-}"
    upd_signature_status="${3:-not_checked}"
    upd_downloaded_package_path="${4:-}"
    case "$upd_last_check_epoch" in ''|*[!0-9]*) upd_last_check_epoch=0 ;; esac
    case "$upd_package_size" in ''|*[!0-9]*) upd_package_size=0 ;; esac
    [ "$upd_available" = "true" ] || upd_available="false"
    [ "$upd_auto_install_allowed" = "true" ] || upd_auto_install_allowed="false"
    printf '{'
    printf '"status":"success",'
    printf '"current_version":"%s",' "$(json_escape "$GOG_APP_VERSION")"
    printf '"channel":"%s",' "$(json_escape "$GOG_UPDATE_CHANNEL")"
    printf '"compatibility":"%s",' "$(json_escape "$GOG_UPDATE_COMPATIBILITY")"
    printf '"manifest_url":"%s",' "$(json_escape "$(update_manifest_url)")"
    printf '"auto_check_enabled":%s,' "$(update_auto_check_enabled)"
    printf '"auto_install_enabled":%s,' "$(update_auto_install_enabled)"
    printf '"update_state":"%s",' "$(json_escape "$upd_state")"
    printf '"last_check_epoch":%s,' "$upd_last_check_epoch"
    printf '"latest_version":"%s",' "$(json_escape "$upd_latest_version")"
    printf '"update_available":%s,' "$upd_available"
    printf '"update_kind":"%s",' "$(json_escape "$upd_kind")"
    printf '"auto_install_allowed":%s,' "$upd_auto_install_allowed"
    printf '"package_url":"%s",' "$(json_escape "$upd_package_url")"
    printf '"package_sha256":"%s",' "$(json_escape "$upd_package_sha256")"
    printf '"package_size":%s,' "$upd_package_size"
    printf '"notes_url":"%s",' "$(json_escape "$upd_notes_url")"
    printf '"signature_required":true,'
    printf '"signature_status":"%s",' "$(json_escape "$upd_signature_status")"
    printf '"downloaded_package_path":"%s",' "$(json_escape "$upd_downloaded_package_path")"
    printf '"message":"%s"' "$(json_escape "$upd_message")"
    printf '}\n'
}

update_write_status_json() {
    ensure_update_dirs
    upd_status_tmp="$TMP_DIR/update_status.$$.$RANDOM.json"
    update_print_status_json "$@" > "$upd_status_tmp"
    copy_file_atomic "$upd_status_tmp" "$GOG_UPDATE_STATUS_FILE"
    rm -f "$upd_status_tmp"
}

update_emit_status_json() {
    ensure_update_dirs
    if [ -s "$GOG_UPDATE_STATUS_FILE" ]; then
        upd_status_text=$(read_text_file_clean "$GOG_UPDATE_STATUS_FILE")
        upd_state=$(json_get_string_from_text "update_state" "$upd_status_text")
        upd_message=$(json_get_string_from_text "message" "$upd_status_text")
        upd_last_check_epoch=$(json_get_number_from_text "last_check_epoch" "$upd_status_text")
        upd_latest_version=$(json_get_string_from_text "latest_version" "$upd_status_text")
        upd_available=$(json_get_bool_from_text "update_available" "$upd_status_text")
        upd_kind=$(json_get_string_from_text "update_kind" "$upd_status_text")
        upd_auto_install_allowed=$(json_get_bool_from_text "auto_install_allowed" "$upd_status_text")
        upd_package_url=$(json_get_string_from_text "package_url" "$upd_status_text")
        upd_package_sha256=$(json_get_string_from_text "package_sha256" "$upd_status_text")
        upd_package_size=$(json_get_number_from_text "package_size" "$upd_status_text")
        upd_notes_url=$(json_get_string_from_text "notes_url" "$upd_status_text")
        upd_signature_status=$(json_get_string_from_text "signature_status" "$upd_status_text")
        upd_downloaded_package_path=$(json_get_string_from_text "downloaded_package_path" "$upd_status_text")
        [ -n "$upd_state" ] || upd_state="idle"
        [ -n "$upd_kind" ] || upd_kind="none"
        [ -n "$upd_signature_status" ] || upd_signature_status="not_checked"
        update_print_status_json "$upd_state" "$upd_message" "$upd_last_check_epoch" "$upd_latest_version" "$upd_available" "$upd_kind" "$upd_auto_install_allowed" "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_downloaded_package_path"
        return 0
    fi
    update_write_status_json "idle" "Update checker has not run yet." 0 "" false none false "" "" 0 "" "not_checked"
    update_emit_status_json
}

update_check_manifest() {
    ensure_update_dirs
    upd_manifest_url=$(update_manifest_url)
    upd_manifest_tmp="$TMP_DIR/update_manifest.$$.$RANDOM.json"
    rm -f "$upd_manifest_tmp"

    if ! download_file_with_retries "$upd_manifest_url" "$upd_manifest_tmp" 2 1; then
        upd_now=$(now_epoch)
        update_write_status_json "update_unavailable" "Update manifest is unavailable; runtime was left untouched." "$upd_now" "" false none false "" "" 0 "" "not_checked"
        rm -f "$upd_manifest_tmp"
        return 0
    fi

    upd_manifest_text=$(read_text_file_clean "$upd_manifest_tmp")
    upd_schema=$(json_get_number_from_text "schema" "$upd_manifest_text")
    upd_version=$(json_get_string_from_text "version" "$upd_manifest_text")
    upd_compat=$(json_get_string_from_text "compatibility" "$upd_manifest_text")
    upd_kind=$(json_get_string_from_text "update_kind" "$upd_manifest_text")
    upd_min_supported=$(json_get_string_from_text "min_supported_version" "$upd_manifest_text")
    upd_package_url=$(json_get_string_from_text "package_url" "$upd_manifest_text")
    upd_package_sha256=$(json_get_string_from_text "package_sha256" "$upd_manifest_text")
    upd_package_size=$(json_get_number_from_text "package_size" "$upd_manifest_text")
    upd_notes_url=$(json_get_string_from_text "notes_url" "$upd_manifest_text")
    upd_auto_install_allowed=$(json_get_bool_from_text "auto_install_allowed" "$upd_manifest_text")
    upd_sig_status=$(update_manifest_signature_status "$upd_manifest_url" "$upd_manifest_tmp")
    upd_now=$(now_epoch)
    [ -n "$upd_kind" ] || upd_kind="none"
    [ -n "$upd_package_size" ] || upd_package_size=0

    if [ "$upd_schema" != "1" ] || [ -z "$upd_version" ] || [ -z "$upd_compat" ]; then
        update_write_status_json "invalid_manifest" "Update manifest is invalid; runtime was left untouched." "$upd_now" "$upd_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_sig_status"
        rm -f "$upd_manifest_tmp"
        return 0
    fi

    if [ "$upd_compat" != "$GOG_UPDATE_COMPATIBILITY" ]; then
        update_write_status_json "incompatible" "Update manifest targets another compatibility line; runtime was left untouched." "$upd_now" "$upd_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_sig_status"
        rm -f "$upd_manifest_tmp"
        return 0
    fi

    if [ -n "$upd_min_supported" ]; then
        upd_current_key=$(update_version_sort_key "$GOG_APP_VERSION")
        upd_min_key=$(update_version_sort_key "$upd_min_supported")
        if [ "$upd_current_key" -lt "$upd_min_key" ] 2>/dev/null; then
            update_write_status_json "unsupported_current_version" "Current version is older than manifest minimum; manual update is required." "$upd_now" "$upd_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_sig_status"
            rm -f "$upd_manifest_tmp"
            return 0
        fi
    fi

    upd_current_key=$(update_version_sort_key "$GOG_APP_VERSION")
    upd_latest_key=$(update_version_sort_key "$upd_version")
    if [ "$upd_latest_key" -gt "$upd_current_key" ] 2>/dev/null && [ "$upd_kind" != "none" ] && [ -n "$upd_package_url" ]; then
        update_write_status_json "update_available" "Update is available." "$upd_now" "$upd_version" true "$upd_kind" "$upd_auto_install_allowed" "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_sig_status"
    else
        update_write_status_json "no_update" "No update is available." "$upd_now" "$upd_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_sig_status"
    fi

    rm -f "$upd_manifest_tmp"
    return 0
}

update_backup_path() {
    upd_version="$1"
    upd_ts=$(date +%Y-%m-%d_%H-%M-%S 2>/dev/null || now_epoch)
    printf '%s/%s_%s' "$GOG_UPDATE_BACKUP_DIR" "$upd_version" "$upd_ts"
}

update_create_backup() {
    ensure_update_dirs
    upd_backup_dir=$(update_backup_path "$GOG_APP_VERSION")
    mkdir -p "$upd_backup_dir/etc-sing-box" "$upd_backup_dir/etc-gog" "$upd_backup_dir/www" "$upd_backup_dir/usr-bin" "$upd_backup_dir/etc" 2>/dev/null || return 1
    for upd_file in "$SETTINGS_FILE" "$PAYLOAD_FILE" "$CONFIG_FILE" "$RAW_FILE" "$SERVERS_CACHE" "$ACTIVE_SELECTED_IDS_FILE" "$CUSTOM_FILE" "$MODE_FILE"; do
        [ -f "$upd_file" ] && cp "$upd_file" "$upd_backup_dir/etc-sing-box/$(basename "$upd_file")" 2>/dev/null || true
    done
    [ -d "$REFILTER_BOOTSTRAP_DIR" ] && cp -R "$REFILTER_BOOTSTRAP_DIR" "$upd_backup_dir/etc-gog/refilter-cache" 2>/dev/null || true
    [ -d "$SERVICE_DEPS_DIR" ] && cp -R "$SERVICE_DEPS_DIR" "$upd_backup_dir/etc-gog/service-deps" 2>/dev/null || true
    mkdir -p "$upd_backup_dir/etc-gog/update" 2>/dev/null || true
    [ -f "$GOG_UPDATE_SETTINGS_FILE" ] && cp "$GOG_UPDATE_SETTINGS_FILE" "$upd_backup_dir/etc-gog/update/settings.json" 2>/dev/null || true
    [ -f "$GOG_UPDATE_TRUSTED_PUB_FILE" ] && cp "$GOG_UPDATE_TRUSTED_PUB_FILE" "$upd_backup_dir/etc-gog/update/trusted.pub" 2>/dev/null || true
    [ -f /www/myproxy/index.html ] && cp /www/myproxy/index.html "$upd_backup_dir/www/index.html" 2>/dev/null || true
    [ -f /www/cgi-bin/myproxy_api ] && cp /www/cgi-bin/myproxy_api "$upd_backup_dir/www/myproxy_api" 2>/dev/null || true
    [ -f /usr/bin/gog-proxy-start ] && cp /usr/bin/gog-proxy-start "$upd_backup_dir/usr-bin/gog-proxy-start" 2>/dev/null || true
    [ -f /usr/bin/gog-proxy-stop ] && cp /usr/bin/gog-proxy-stop "$upd_backup_dir/usr-bin/gog-proxy-stop" 2>/dev/null || true
    [ -f /usr/bin/gog-self-update ] && cp /usr/bin/gog-self-update "$upd_backup_dir/usr-bin/gog-self-update" 2>/dev/null || true
    [ -f /etc/rc.local ] && cp /etc/rc.local "$upd_backup_dir/etc/rc.local" 2>/dev/null || true
    [ -f /etc/crontabs/root ] && cp /etc/crontabs/root "$upd_backup_dir/etc/crontab-root" 2>/dev/null || true
    printf '%s\n' "$upd_backup_dir" > "$GOG_UPDATE_DIR/last_backup_path.txt"
    update_prune_backups
    printf '%s' "$upd_backup_dir"
}

update_restore_backup() {
    upd_backup_path="$1"
    case "$upd_backup_path" in
        "$GOG_UPDATE_BACKUP_DIR"/*) ;;
        *) return 1 ;;
    esac
    [ -d "$upd_backup_path" ] || return 1

    if [ -f "$upd_backup_path/www/index.html" ]; then
        cp "$upd_backup_path/www/index.html" /www/myproxy/index.html || return 1
    fi
    if [ -f "$upd_backup_path/www/myproxy_api" ]; then
        cp "$upd_backup_path/www/myproxy_api" /www/cgi-bin/myproxy_api || return 1
        chmod +x /www/cgi-bin/myproxy_api
    fi
    if [ -f "$upd_backup_path/usr-bin/gog-proxy-start" ]; then
        cp "$upd_backup_path/usr-bin/gog-proxy-start" /usr/bin/gog-proxy-start || return 1
        chmod +x /usr/bin/gog-proxy-start
    fi
    if [ -f "$upd_backup_path/usr-bin/gog-proxy-stop" ]; then
        cp "$upd_backup_path/usr-bin/gog-proxy-stop" /usr/bin/gog-proxy-stop || return 1
        chmod +x /usr/bin/gog-proxy-stop
    fi
    if [ -f "$upd_backup_path/usr-bin/gog-self-update" ]; then
        cp "$upd_backup_path/usr-bin/gog-self-update" /usr/bin/gog-self-update || return 1
        chmod +x /usr/bin/gog-self-update
    fi
    if [ -f "$upd_backup_path/etc/rc.local" ]; then
        cp "$upd_backup_path/etc/rc.local" /etc/rc.local || return 1
    fi
    if [ -f "$upd_backup_path/etc/crontab-root" ]; then
        cp "$upd_backup_path/etc/crontab-root" /etc/crontabs/root || return 1
        /etc/init.d/cron restart >/dev/null 2>&1 || true
    fi
    for upd_file in myproxy_settings.json last_payload.json config.json raw_sub.txt servers_cache.txt active_selected_ids.txt custom_list.txt mode.txt; do
        if [ -f "$upd_backup_path/etc-sing-box/$upd_file" ]; then
            cp "$upd_backup_path/etc-sing-box/$upd_file" "$BASE_DIR/$upd_file" || return 1
        fi
    done
    if [ -d "$upd_backup_path/etc-gog/refilter-cache" ]; then
        rm -rf "$REFILTER_BOOTSTRAP_DIR"
        mkdir -p "$(dirname "$REFILTER_BOOTSTRAP_DIR")"
        cp -R "$upd_backup_path/etc-gog/refilter-cache" "$REFILTER_BOOTSTRAP_DIR" || return 1
    fi
    if [ -d "$upd_backup_path/etc-gog/service-deps" ]; then
        rm -rf "$SERVICE_DEPS_DIR"
        mkdir -p "$(dirname "$SERVICE_DEPS_DIR")"
        cp -R "$upd_backup_path/etc-gog/service-deps" "$SERVICE_DEPS_DIR" || return 1
    fi
    mkdir -p "$GOG_UPDATE_DIR" 2>/dev/null || true
    if [ -f "$upd_backup_path/etc-gog/update/settings.json" ]; then
        cp "$upd_backup_path/etc-gog/update/settings.json" "$GOG_UPDATE_SETTINGS_FILE" || return 1
    fi
    if [ -f "$upd_backup_path/etc-gog/update/trusted.pub" ]; then
        cp "$upd_backup_path/etc-gog/update/trusted.pub" "$GOG_UPDATE_TRUSTED_PUB_FILE" || return 1
        chmod 0644 "$GOG_UPDATE_TRUSTED_PUB_FILE" 2>/dev/null || true
    fi
    if [ -s "$CONFIG_FILE" ]; then
        previous_mode="$(current_mode_label || true)"
        [ -n "$previous_mode" ] || previous_mode="update-rollback"
        try_runtime_start "$CONFIG_FILE" "$previous_mode" "$PAYLOAD_FILE" >/dev/null 2>&1 || true
    fi
    write_probe_state "ok"
    return 0
}

update_prune_backups() {
    [ -d "$GOG_UPDATE_BACKUP_DIR" ] || return 0
    ls -1dt "$GOG_UPDATE_BACKUP_DIR"/* 2>/dev/null | awk -v keep="$GOG_UPDATE_MAX_BACKUPS" 'NR > keep { print }' | while IFS= read -r upd_old_backup || [ -n "$upd_old_backup" ]; do
        case "$upd_old_backup" in
            "$GOG_UPDATE_BACKUP_DIR"/*) rm -rf "$upd_old_backup" ;;
        esac
    done
}

download_update_package_file() {
    upd_url="$1"
    upd_dest="$2"
    upd_tmp="${upd_dest}.part.$$"
    rm -f "$upd_dest" "$upd_tmp"
    command -v curl >/dev/null 2>&1 || return 1
    upd_i=1
    while [ "$upd_i" -le 3 ]; do
        rm -f "$upd_tmp"
        if curl -fsSL --connect-timeout 10 --max-time 45 -A "GOG-Updater/1.0" "$upd_url" -o "$upd_tmp" >/dev/null 2>&1 && [ -s "$upd_tmp" ]; then
            mv "$upd_tmp" "$upd_dest" && return 0
        fi
        rm -f "$upd_tmp"
        upd_i=$((upd_i + 1))
        [ "$upd_i" -le 3 ] && sleep 2
    done
    return 1
}

update_download_verified_package() {
    ensure_update_dirs
    [ -s "$GOG_UPDATE_STATUS_FILE" ] || return 1
    upd_status_text=$(read_text_file_clean "$GOG_UPDATE_STATUS_FILE")
    upd_state=$(json_get_string_from_text "update_state" "$upd_status_text")
    upd_package_url=$(json_get_string_from_text "package_url" "$upd_status_text")
    upd_package_sha256=$(json_get_string_from_text "package_sha256" "$upd_status_text")
    upd_package_size=$(json_get_number_from_text "package_size" "$upd_status_text")
    upd_signature_status=$(json_get_string_from_text "signature_status" "$upd_status_text")
    case "$upd_state" in
        update_available|package_downloaded) ;;
        *) return 1 ;;
    esac
    [ -n "$upd_package_url" ] || return 1
    [ -n "$upd_package_sha256" ] || return 1
    [ "$upd_signature_status" = "verified" ] || return 2
    rm -rf "$GOG_UPDATE_DOWNLOAD_DIR"
    mkdir -p "$GOG_UPDATE_DOWNLOAD_DIR" || return 1
    upd_pkg="$GOG_UPDATE_DOWNLOAD_DIR/update-package.tar.gz"
    download_update_package_file "$upd_package_url" "$upd_pkg" || return 1
    if [ -n "$upd_package_size" ] && [ "$upd_package_size" -gt 0 ] 2>/dev/null; then
        upd_actual_size=$(wc -c < "$upd_pkg" 2>/dev/null | tr -d ' ')
        [ "$upd_actual_size" = "$upd_package_size" ] || return 1
    fi
    upd_actual_sha=$(sha256sum "$upd_pkg" 2>/dev/null | awk '{print $1}')
    [ "$upd_actual_sha" = "$upd_package_sha256" ] || return 1
    printf '%s\n' "$upd_pkg" > "$GOG_UPDATE_DOWNLOADED_PACKAGE_FILE"
    printf '%s' "$upd_pkg"
}

ensure_refilter_rule_sets_ready() {
    domains_ready="false"
    ipsum_ready="false"

    if [ -s "$REFILTER_DOMAINS_FILE" ]; then
        domains_ready="true"
    elif [ -s "$REFILTER_DOMAINS_CACHE_FILE" ] && copy_file_atomic "$REFILTER_DOMAINS_CACHE_FILE" "$REFILTER_DOMAINS_FILE"; then
        domains_ready="true"
        append_runtime_note "refilter domain ruleset restored from persistent bootstrap cache"
    fi

    if [ -s "$REFILTER_IPSUM_FILE" ]; then
        ipsum_ready="true"
    elif [ -s "$REFILTER_IPSUM_CACHE_FILE" ] && copy_file_atomic "$REFILTER_IPSUM_CACHE_FILE" "$REFILTER_IPSUM_FILE"; then
        ipsum_ready="true"
        append_runtime_note "refilter ip ruleset restored from persistent bootstrap cache"
    fi

    [ "$domains_ready" = "true" ] && [ "$ipsum_ready" = "true" ]
}

refilter_bootstrap_ready() {
    [ -s "$REFILTER_DOMAINS_CACHE_FILE" ] && [ -s "$REFILTER_IPSUM_CACHE_FILE" ]
}

refilter_active_ready() {
    [ -s "$REFILTER_DOMAINS_FILE" ] && [ -s "$REFILTER_IPSUM_FILE" ]
}

refresh_refilter_rule_sets() {
    domains_tmp="$TMP_DIR/refilter_domains.new.srs"
    ipsum_tmp="$TMP_DIR/refilter_ipsum.new.srs"
    domains_ready="false"
    ipsum_ready="false"

    rm -f "$domains_tmp" "$ipsum_tmp"

    if download_refilter_asset "$REFILTER_DOMAINS_URL" "$domains_tmp" 3 2 && [ -s "$domains_tmp" ] && \
       copy_file_atomic "$domains_tmp" "$REFILTER_DOMAINS_FILE" && \
       copy_file_atomic "$domains_tmp" "$REFILTER_DOMAINS_CACHE_FILE"; then
        domains_ready="true"
    elif [ -s "$REFILTER_DOMAINS_FILE" ]; then
        domains_ready="true"
        [ -s "$REFILTER_DOMAINS_CACHE_FILE" ] || copy_file_atomic "$REFILTER_DOMAINS_FILE" "$REFILTER_DOMAINS_CACHE_FILE" || true
        append_runtime_note "refilter domain ruleset refresh failed, reused active local copy"
    elif [ -s "$REFILTER_DOMAINS_CACHE_FILE" ] && copy_file_atomic "$REFILTER_DOMAINS_CACHE_FILE" "$REFILTER_DOMAINS_FILE"; then
        domains_ready="true"
        append_runtime_note "refilter domain ruleset refresh failed, restored persistent bootstrap cache"
    fi

    if download_refilter_asset "$REFILTER_IPSUM_URL" "$ipsum_tmp" 3 2 && [ -s "$ipsum_tmp" ] && \
       copy_file_atomic "$ipsum_tmp" "$REFILTER_IPSUM_FILE" && \
       copy_file_atomic "$ipsum_tmp" "$REFILTER_IPSUM_CACHE_FILE"; then
        ipsum_ready="true"
    elif [ -s "$REFILTER_IPSUM_FILE" ]; then
        ipsum_ready="true"
        [ -s "$REFILTER_IPSUM_CACHE_FILE" ] || copy_file_atomic "$REFILTER_IPSUM_FILE" "$REFILTER_IPSUM_CACHE_FILE" || true
        append_runtime_note "refilter ip ruleset refresh failed, reused active local copy"
    elif [ -s "$REFILTER_IPSUM_CACHE_FILE" ] && copy_file_atomic "$REFILTER_IPSUM_CACHE_FILE" "$REFILTER_IPSUM_FILE"; then
        ipsum_ready="true"
        append_runtime_note "refilter ip ruleset refresh failed, restored persistent bootstrap cache"
    fi

    rm -f "$domains_tmp" "$ipsum_tmp"
    [ "$domains_ready" = "true" ] && [ "$ipsum_ready" = "true" ]
}

jsonfilter_get_first() {
    file="$1"
    pattern="$2"
    command -v jsonfilter >/dev/null 2>&1 || return 1
    jsonfilter -q -i "$file" -e "$pattern" 2>/dev/null | sed -n '1p'
}

normalize_provider_json_subscription() {
    src="$1"
    dest="$2"
    tmp="$TMP_DIR/sub.provider_json.$$.$RANDOM.txt"
    compact_lead=""

    [ -s "$src" ] || return 1
    command -v jsonfilter >/dev/null 2>&1 || return 1

    compact_lead=$(tr -d '\r\n\t ' < "$src" | cut -c1)
    case "$compact_lead" in
        '['|'{') ;;
        *) return 1 ;;
    esac

    grep -q '"outbounds"' "$src" 2>/dev/null || return 1

    : > "$tmp"
    idx=0
    while [ "$idx" -lt 256 ]; do
        remarks=$(jsonfilter_get_first "$src" "@[$idx].remarks")
        address=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].settings.vnext[0].address")
        port=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].settings.vnext[0].port")
        uuid=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].settings.vnext[0].users[0].id")

        if [ -z "$remarks$address$uuid" ]; then
            break
        fi

        if [ -z "$address" ] || [ -z "$uuid" ]; then
            idx=$((idx + 1))
            continue
        fi

        flow=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].settings.vnext[0].users[0].flow")
        security=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.security")
        network=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.network")
        sni=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.realitySettings.serverName")
        [ -n "$sni" ] || sni=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.tlsSettings.serverName")
        fp=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.realitySettings.fingerprint")
        [ -n "$fp" ] || fp=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.tlsSettings.fingerprint")
        pbk=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.realitySettings.publicKey")
        sid=$(jsonfilter_get_first "$src" "@[$idx].outbounds[@.protocol=\"vless\"].streamSettings.realitySettings.shortId")

        [ -n "$port" ] || port="443"
        [ -n "$network" ] || network="tcp"
        remarks=$(printf '%s' "$remarks" | tr -d '\r\n')

        params="encryption=none"
        [ -n "$flow" ] && params="$params&flow=$flow"
        [ -n "$security" ] && params="$params&security=$security"
        [ -n "$sni" ] && params="$params&sni=$sni"
        [ -n "$fp" ] && params="$params&fp=$fp"
        [ -n "$pbk" ] && params="$params&pbk=$pbk"
        [ -n "$sid" ] && params="$params&sid=$sid"
        params="$params&type=$network&headerType=none"

        if [ -n "$remarks" ]; then
            printf 'vless://%s@%s:%s?%s#%s\n' "$uuid" "$address" "$port" "$params" "$remarks" >> "$tmp"
        else
            printf 'vless://%s@%s:%s?%s\n' "$uuid" "$address" "$port" "$params" >> "$tmp"
        fi

        idx=$((idx + 1))
    done

    [ -s "$tmp" ] || {
        rm -f "$tmp"
        return 1
    }

    mv "$tmp" "$dest"
    return 0
}

normalize_subscription_file() {
    file="$1"
    tmp1="$TMP_DIR/sub.normalize.$$.$RANDOM.1"
    tmp2="$TMP_DIR/sub.normalize.$$.$RANDOM.2"
    [ -s "$file" ] || return 1

    tr -d '\r' < "$file" | sed \
        -e 's#,[[:space:]]*vless://# vless://#g' \
        -e 's#,[[:space:]]*trojan://# trojan://#g' \
        -e 's#,[[:space:]]*hy2://# hy2://#g' \
        -e 's#,[[:space:]]*hysteria2://# hysteria2://#g' > "$tmp1"
    if grep -Eq '(vless|trojan|hy2|hysteria2)://' "$tmp1"; then
        grep -Eo '(vless|trojan|hy2|hysteria2)://[^[:space:]]*' "$tmp1" > "$tmp2" || true
        [ -s "$tmp2" ] || cp "$tmp1" "$tmp2"
        mv "$tmp2" "$file"
        rm -f "$tmp1" "$tmp2"
        return 0
    fi

    compact=$(tr -d '\r\n\t ' < "$tmp1")
    [ -n "$compact" ] || { rm -f "$tmp1" "$tmp2"; return 1; }
    if printf '%s' "$compact" | base64 -d > "$tmp2" 2>/dev/null; then
        tr -d '\r' < "$tmp2" | grep -Eo '(vless|trojan|hy2|hysteria2)://[^[:space:]]*' > "$file" || true
        if [ -s "$file" ]; then
            rm -f "$tmp1" "$tmp2"
            return 0
        fi
    fi

    if normalize_provider_json_subscription "$tmp1" "$file"; then
        if [ -s "$file" ]; then
            rm -f "$tmp1" "$tmp2"
            return 0
        fi
    fi
    rm -f "$tmp1" "$tmp2"
    return 1
}

validate_subscription_file() {
    file="$1"
    [ -s "$file" ] || return 1
    normalize_subscription_file "$file" || return 1
    grep -Eq '^(vless|trojan|hy2|hysteria2)://' "$file"
}

validate_custom_list_file() {
    file="$1"
    [ -f "$file" ] || return 0
    return 0
}

get_current_settings_json() {
    settings_cache="${1:-${SERVERS_CACHE:-}}"
    settings_selected_override="${2:-}"
    settings_selected_tmp="$TMP_DIR/get_config.selected.$$.$RANDOM.txt"
    settings_repaired_tmp="$TMP_DIR/get_config.settings.$$.$RANDOM.json"

    : > "$settings_selected_tmp"
    if [ -n "$settings_selected_override" ] && [ -s "$settings_selected_override" ]; then
        cp "$settings_selected_override" "$settings_selected_tmp"
    elif [ -s "$settings_cache" ]; then
        build_best_available_selected_ids "$settings_cache" "$settings_selected_tmp"
    fi

    if selected_ids_file_has_records "$settings_selected_tmp"; then
        if [ -s "$SETTINGS_FILE" ]; then
            rewrite_json_servers_from_selected_file "$SETTINGS_FILE" "$settings_selected_tmp" "$settings_repaired_tmp"
            if [ -s "$settings_repaired_tmp" ]; then
                read_text_file_clean "$settings_repaired_tmp"
                rm -f "$settings_selected_tmp" "$settings_repaired_tmp"
                return 0
            fi
        fi
        if [ -s "$PAYLOAD_FILE" ]; then
            rewrite_json_servers_from_selected_file "$PAYLOAD_FILE" "$settings_selected_tmp" "$settings_repaired_tmp"
            if [ -s "$settings_repaired_tmp" ]; then
                read_text_file_clean "$settings_repaired_tmp"
                rm -f "$settings_selected_tmp" "$settings_repaired_tmp"
                return 0
            fi
        fi
    fi

    rm -f "$settings_selected_tmp" "$settings_repaired_tmp"
    if [ -s "$SETTINGS_FILE" ]; then
        read_text_file_clean "$SETTINGS_FILE"
    elif [ -s "$PAYLOAD_FILE" ]; then
        read_text_file_clean "$PAYLOAD_FILE"
    else
        printf '{}'
    fi
}

bool_is_true() {
    [ "$1" = "true" ]
}

has_check_command() {
    command -v sing-box >/dev/null 2>&1 || return 1
    sing-box check -h >/dev/null 2>&1
}

validate_config() {
    candidate="$1"
    if has_check_command; then
        sing-box check -c "$candidate" >/tmp/gog_singbox_check.log 2>&1
        return $?
    fi
    return 0
}

detect_default_interface() {
    iface=$(ip route show default 2>/dev/null | awk '/default/ {print $5; exit}')
    [ -n "$iface" ] && { printf '%s' "$iface"; return; }
    iface=$(route -n 2>/dev/null | awk '$1=="0.0.0.0" {print $8; exit}')
    printf '%s' "$iface"
}

ensure_rc_local() {
    if [ ! -f /etc/rc.local ]; then
        cat <<'RC' > /etc/rc.local
#!/bin/sh
exit 0
RC
        chmod +x /etc/rc.local
    fi
}

disable_stock_singbox_service() {
    if [ -x /etc/init.d/sing-box ]; then
        /etc/init.d/sing-box stop >/dev/null 2>&1 || true
        /etc/init.d/sing-box disable >/dev/null 2>&1 || true
    fi
}

set_autostart() {
    ensure_rc_local
    disable_stock_singbox_service
    sed -i '/gog-proxy-start/d' /etc/rc.local 2>/dev/null || true
    sed -i '\|/usr/bin/sing-box run -c /etc/sing-box/config.json|d' /etc/rc.local 2>/dev/null || true
    if grep -q 'exit 0' /etc/rc.local; then
        sed -i '/exit 0/i\/usr/bin/gog-proxy-start /etc/sing-box/config.json \&' /etc/rc.local
    else
        echo '/usr/bin/gog-proxy-start /etc/sing-box/config.json &' >> /etc/rc.local
    fi
}

remove_autostart() {
    disable_stock_singbox_service
    sed -i '/gog-proxy-start/d' /etc/rc.local 2>/dev/null || true
    sed -i '\|/usr/bin/sing-box run -c /etc/sing-box/config.json|d' /etc/rc.local 2>/dev/null || true
}

cleanup_cron_entries() {
    # Remove both old and new cron formats for this API.
    sed -i '\|/www/cgi-bin/myproxy_api|d' /etc/crontabs/root 2>/dev/null || true
    sed -i '\|/usr/bin/gog-self-update|d' /etc/crontabs/root 2>/dev/null || true
}

install_cron() {
    cleanup_cron_entries
    echo '20 */6 * * * QUERY_STRING="action=log_maint" /www/cgi-bin/myproxy_api >/dev/null 2>&1' >> /etc/crontabs/root
    echo '*/3 * * * * QUERY_STRING="action=watchdog" /www/cgi-bin/myproxy_api >/dev/null 2>&1' >> /etc/crontabs/root
    echo '0 22 * * 0 /usr/bin/gog-self-update weekly >/dev/null 2>&1' >> /etc/crontabs/root
    if grep -q '"auto_update":true' "$SETTINGS_FILE" 2>/dev/null; then
        echo '0 */10 * * * QUERY_STRING="action=cron" /www/cgi-bin/myproxy_api >/dev/null 2>&1' >> /etc/crontabs/root
    fi
    /etc/init.d/cron restart >/dev/null 2>&1 || true
}

restart_previous_if_possible() {
    restore_mode="${1:-sync}"
    [ -s "$CONFIG_FILE" ] || return 0
    if [ "$restore_mode" = "async" ]; then
        (
            /usr/bin/gog-proxy-start "$CONFIG_FILE" >/dev/null 2>&1 || true
        ) >/dev/null 2>&1 &
        return 0
    fi
    /usr/bin/gog-proxy-start "$CONFIG_FILE" >/dev/null 2>&1 || true
}

force_stop_runtime() {
    disable_stock_singbox_service
    /usr/bin/gog-proxy-stop >/dev/null 2>&1 || true

    if pidof sing-box >/dev/null 2>&1; then
        killall -9 sing-box >/dev/null 2>&1 || true
        sleep 1
    fi

    if ip link show tun0 >/dev/null 2>&1; then
        ip link set tun0 down >/dev/null 2>&1 || true
        ip tuntap del dev tun0 mode tun >/dev/null 2>&1 || ip link delete tun0 >/dev/null 2>&1 || true
    fi

    ! pidof sing-box >/dev/null 2>&1
}

mark_manual_stop() {
    printf '%s\n' "$(date '+%d-%m-%Y %H:%M:%S' 2>/dev/null || printf 'manual-stop')" > "$MANUAL_STOP_FILE"
}

clear_manual_stop() {
    rm -f "$MANUAL_STOP_FILE"
}

manual_stop_requested() {
    [ -f "$MANUAL_STOP_FILE" ]
}

capture_last_runtime_error() {
    archive_current_error_if_any
    if [ -s "$LOG_FILE" ]; then
        tail -n 20 "$LOG_FILE" > "$ERR_FILE"
    else
        echo "sing-box не запустился, а лог пуст." > "$ERR_FILE"
    fi
}

trim_incident_history_if_needed() {
    [ -f "$INCIDENT_LOG_FILE" ] || return 0
    size=$(wc -c < "$INCIDENT_LOG_FILE" 2>/dev/null || echo 0)
    case "$size" in
        ''|*[!0-9]*) return 0 ;;
    esac
    [ "$size" -le "$INCIDENT_LOG_MAX_BYTES" ] && return 0
    trimmed_tmp="$TMP_DIR/incident_history.trimmed.txt"
    aligned_tmp="$TMP_DIR/incident_history.aligned.txt"
    tail -c "$INCIDENT_LOG_MAX_BYTES" "$INCIDENT_LOG_FILE" > "$trimmed_tmp" 2>/dev/null || true
    if [ -s "$trimmed_tmp" ]; then
        sed -n '/^\[[0-9][0-9]-[0-9][0-9]-[0-9][0-9][0-9][0-9] [0-9][0-9]:[0-9][0-9]:[0-9][0-9]\]$/,$p' "$trimmed_tmp" > "$aligned_tmp" 2>/dev/null || true
        if [ -s "$aligned_tmp" ]; then
            mv "$aligned_tmp" "$trimmed_tmp" 2>/dev/null || {
                cp "$aligned_tmp" "$trimmed_tmp" 2>/dev/null || true
                rm -f "$aligned_tmp"
            }
        else
            rm -f "$aligned_tmp"
        fi
        mv "$trimmed_tmp" "$INCIDENT_LOG_FILE" 2>/dev/null || {
            cp "$trimmed_tmp" "$INCIDENT_LOG_FILE" 2>/dev/null || true
            rm -f "$trimmed_tmp"
        }
    else
        rm -f "$trimmed_tmp"
    fi
}

archive_current_error_if_any() {
    [ -s "$ERR_FILE" ] || return 0
    ts=$(date '+%d-%m-%Y %H:%M:%S' 2>/dev/null || printf 'unknown-time')
    {
        printf '[%s]\n' "$ts"
        cat "$ERR_FILE"
        printf '\n\n'
    } >> "$INCIDENT_LOG_FILE"
    trim_incident_history_if_needed
}

clear_current_error() {
    archive_current_error_if_any
    rm -f "$ERR_FILE"
}

current_error_is_transient_control_plane() {
    [ -s "$ERR_FILE" ] || return 1
    err_text=$(cat "$ERR_FILE" 2>/dev/null || true)
    [ -n "$err_text" ] || return 1
    case "$err_text" in
        "Другой запрос уже меняет конфигурацию."*|\
        "Неизвестное действие:"*|\
        "Пустой POST payload."*|\
        "В payload отсутствует ссылка на подписку."*|\
        "Не выбран ни один сервер."*|\
        "Пустая ссылка на подписку."*|\
        "Не удалось подготовить базы Re:filter."*)
            return 0
            ;;
    esac
    return 1
}

discard_transient_current_error_if_healthy() {
    runtime_status="$1"
    probe_state="$2"
    [ "$runtime_status" = "running" ] || return 1
    [ "$probe_state" = "ok" ] || return 1
    current_error_is_transient_control_plane || return 1
    rm -f "$ERR_FILE"
    return 0
}

bounded_log_snapshot() {
    src="$1"
    dst="$2"
    limit="${3:-$LOG_ROTATE_MAX_BYTES}"
    [ -s "$src" ] || { rm -f "$dst"; return 0; }
    tail -c "$limit" "$src" > "$dst" 2>/dev/null || cp "$src" "$dst" 2>/dev/null || true
}

rotate_log_if_needed() {
    [ -f "$LOG_FILE" ] || return 0
    size=$(wc -c < "$LOG_FILE" 2>/dev/null || echo 0)
    case "$size" in
        ''|*[!0-9]*) return 0 ;;
    esac
    [ "$size" -le "$LOG_ROTATE_MAX_BYTES" ] && return 0
    bounded_log_snapshot "$LOG_FILE" "$LOG_FILE.1" "$LOG_ROTATE_MAX_BYTES"
    : > "$LOG_FILE"
}

read_log_snapshot() {
    src_file="$1"
    src_lines="$2"
    [ -s "$src_file" ] || return 0
    tail -n "$src_lines" "$src_file" 2>/dev/null | tr -d '\033' | sed 's/\[[0-9;]*m//g' || true
}

read_watchdog_fail_count() {
    [ -s "$WATCHDOG_FAIL_FILE" ] || { printf '0'; return; }
    count=$(cat "$WATCHDOG_FAIL_FILE" 2>/dev/null || echo 0)
    case "$count" in
        ''|*[!0-9]*) count=0 ;;
    esac
    printf '%s' "$count"
}

write_watchdog_fail_count() {
    printf '%s' "$1" > "$WATCHDOG_FAIL_FILE"
}

reset_watchdog_fail_count() {
    rm -f "$WATCHDOG_FAIL_FILE"
}

increment_watchdog_fail_count() {
    count=$(read_watchdog_fail_count)
    count=$((count + 1))
    write_watchdog_fail_count "$count"
    printf '%s' "$count"
}

runtime_has_process_and_tun() {
    pidof sing-box >/dev/null 2>&1 && ip link show tun0 >/dev/null 2>&1
}

write_probe_state() {
    printf '%s' "$1" > "$PROBE_STATE_FILE"
}

read_probe_state() {
    [ -s "$PROBE_STATE_FILE" ] || { printf 'unknown'; return; }
    cat "$PROBE_STATE_FILE" 2>/dev/null || printf 'unknown'
}

proxy_marker_seen_in_log() {
    marker="$1"
    before_lines="${2:-0}"
    wait_round=0

    while [ "$wait_round" -lt 3 ]; do
        after_lines=$(wc -l < "$LOG_FILE" 2>/dev/null || echo 0)
        if [ "$after_lines" -gt "$before_lines" ]; then
            if sed -n "$((before_lines + 1)),$((after_lines))p" "$LOG_FILE" 2>/dev/null | grep -E 'outbound/(vless|trojan|hysteria2)' | grep -F "$marker" >/dev/null 2>&1; then
                return 0
            fi
        fi
        if tail -n 80 "$LOG_FILE" 2>/dev/null | grep -E 'outbound/(vless|trojan|hysteria2)' | grep -F "$marker" >/dev/null 2>&1; then
            return 0
        fi
        wait_round=$((wait_round+1))
        [ "$wait_round" -lt 3 ] && sleep 1
    done
    return 1
}

proxy_activity_seen_in_log() {
    before_lines="${1:-0}"
    wait_round=0

    while [ "$wait_round" -lt 3 ]; do
        after_lines=$(wc -l < "$LOG_FILE" 2>/dev/null || echo 0)
        if [ "$after_lines" -gt "$before_lines" ]; then
            if sed -n "$((before_lines + 1)),$((after_lines))p" "$LOG_FILE" 2>/dev/null | grep -E 'outbound/(vless|trojan|hysteria2)\[' >/dev/null 2>&1; then
                return 0
            fi
        fi
        if tail -n 80 "$LOG_FILE" 2>/dev/null | grep -E 'outbound/(vless|trojan|hysteria2)\[' >/dev/null 2>&1; then
            return 0
        fi
        wait_round=$((wait_round+1))
        [ "$wait_round" -lt 3 ] && sleep 1
    done
    return 1
}

json_file_bool() {
    file="$1"
    key="$2"
    [ -s "$file" ] || { printf 'false'; return; }
    if read_text_file_clean "$file" | grep -q '"'$key'"[[:space:]]*:[[:space:]]*true'; then
        printf 'true'
    else
        printf 'false'
    fi
}

runtime_probe_direct_path() {
    probe_profile="${1:-default}"
    urls='https://www.gstatic.com/generate_204 https://cp.cloudflare.com/generate_204'
    case "$probe_profile" in
        quick_inline_single|quick_apply)
        urls='https://www.gstatic.com/generate_204'
            ;;
    esac
    ok_count=0
    for u in $urls; do
        if command -v curl >/dev/null 2>&1; then
            if curl -fsS --connect-timeout 3 --max-time 6 -o /dev/null "$u" >/dev/null 2>&1; then
                ok_count=$((ok_count+1))
            fi
        elif command -v wget >/dev/null 2>&1; then
            if wget -q --timeout=6 --spider "$u" >/dev/null 2>&1; then
                ok_count=$((ok_count+1))
            fi
        fi
    done
    [ "$ok_count" -ge 1 ] && return 0
    return 1
}

choose_proxy_probe_targets() {
    settings_file="$1"
    probe_profile="${2:-default}"
    force_full=$(json_file_bool "$settings_file" "force_full_proxy")
    proxy_ai=$(json_file_bool "$settings_file" "proxy_ai")
    refilter=$(json_file_bool "$settings_file" "refilter")
    targets=""

    if [ "$force_full" = "true" ] || [ "$proxy_ai" = "true" ]; then
        targets="$targets https://chatgpt.com|chatgpt.com"
    fi
    if [ "$force_full" = "true" ] || [ "$refilter" = "true" ]; then
        targets="$targets https://www.youtube.com|youtube"
    fi

    case "$probe_profile" in
        quick_inline_single|quick_apply)
        set -- $targets
        printf '%s' "${1:-}"
        return 0
            ;;
    esac

    printf '%s' "$targets"
}

runtime_probe_proxy_path() {
    settings_file="$1"
    probe_profile="${2:-default}"
    targets=$(choose_proxy_probe_targets "$settings_file" "$probe_profile")
    [ -n "$targets" ] || return 0
    command -v curl >/dev/null 2>&1 || return 1

    for pair in $targets; do
        url=${pair%%|*}
        marker=${pair#*|}
        before_lines=$(wc -l < "$LOG_FILE" 2>/dev/null || echo 0)
        curl_ok="true"
        if ! curl -k -sS --connect-timeout 5 --max-time 12 -L -o /dev/null "$url" >/dev/null 2>&1; then
            curl_ok="false"
        fi
        if proxy_marker_seen_in_log "$marker" "$before_lines"; then
            return 0
        fi
        if [ "$curl_ok" = "true" ] && proxy_activity_seen_in_log "$before_lines"; then
            return 0
        fi
        if [ "$probe_profile" = "quick_apply" ] && proxy_activity_seen_in_log "$before_lines"; then
            return 0
        fi
    done
    return 1
}

runtime_probe_connectivity() {
    config_file="${1:-$CONFIG_FILE}"
    settings_file="${2:-$SETTINGS_FILE}"
    probe_profile="${3:-default}"
    route_final=$(extract_config_final "route" "$config_file")
    direct_required="false"
    proxy_required="false"
    attempt_limit=2

    [ "$route_final" = "direct" ] && direct_required="true"
    [ "$route_final" = "AUTO-BALANCE" ] && proxy_required="true"
    [ "$(json_file_bool "$settings_file" "force_full_proxy")" = "true" ] && proxy_required="true"
    [ "$(json_file_bool "$settings_file" "proxy_ai")" = "true" ] && proxy_required="true"
    [ "$(json_file_bool "$settings_file" "refilter")" = "true" ] && proxy_required="true"
    case "$probe_profile" in
        quick_inline_single|quick_apply)
            direct_required="false"
            ;;
    esac
    case "$probe_profile" in
        quick_inline_single|quick_apply)
            attempt_limit=1
            ;;
    esac

    attempt=0
    while [ "$attempt" -lt "$attempt_limit" ]; do
        direct_ok="true"
        proxy_ok="true"

        if [ "$direct_required" = "true" ] && ! runtime_probe_direct_path "$probe_profile"; then
            direct_ok="false"
        fi
        if [ "$proxy_required" = "true" ] && ! runtime_probe_proxy_path "$settings_file" "$probe_profile"; then
            proxy_ok="false"
        fi

        if [ "$direct_ok" = "true" ] && [ "$proxy_ok" = "true" ]; then
            write_probe_state "ok"
            return 0
        fi

        if [ "$proxy_ok" != "true" ]; then
            write_probe_state "proxy_failed"
        elif [ "$direct_ok" != "true" ]; then
            write_probe_state "direct_failed"
        else
            write_probe_state "unknown_failed"
        fi

        sleep 1
        attempt=$((attempt+1))
    done
    return 1
}

parse_vless_to_json_line() {
    line="$1"
    tag="$2"
    no_name="${line%%#*}"
    core="${no_name%%\?*}"
    params="${no_name#*\?}"
    [ "$params" = "$no_name" ] && params=""
    core_no_prefix=$(printf '%s' "$core" | sed 's#^vless://##')
    uuid=$(printf '%s' "$core_no_prefix" | cut -d'@' -f1)
    host_port=$(printf '%s' "$core_no_prefix" | cut -d'@' -f2)
    host=$(printf '%s' "$host_port" | cut -d':' -f1)
    port=$(printf '%s' "$host_port" | sed -n 's/.*:\([0-9][0-9]*\)$/\1/p')
    [ -z "$port" ] && port=443

    sni=$(printf '%s' "$params" | sed -n 's/.*[?&]sni=\([^&]*\).*/\1/p')
    [ -z "$sni" ] && sni=$(printf '%s' "$params" | sed -n 's/^sni=\([^&]*\).*/\1/p')
    pbk=$(printf '%s' "$params" | sed -n 's/.*[?&]pbk=\([^&]*\).*/\1/p')
    [ -z "$pbk" ] && pbk=$(printf '%s' "$params" | sed -n 's/^pbk=\([^&]*\).*/\1/p')
    sid=$(printf '%s' "$params" | sed -n 's/.*[?&]sid=\([^&]*\).*/\1/p')
    [ -z "$sid" ] && sid=$(printf '%s' "$params" | sed -n 's/^sid=\([^&]*\).*/\1/p')
    flow=$(printf '%s' "$params" | sed -n 's/.*[?&]flow=\([^&]*\).*/\1/p')
    [ -z "$flow" ] && flow=$(printf '%s' "$params" | sed -n 's/^flow=\([^&]*\).*/\1/p')
    fp=$(printf '%s' "$params" | sed -n 's/.*[?&]fp=\([^&]*\).*/\1/p')
    [ -z "$fp" ] && fp=$(printf '%s' "$params" | sed -n 's/^fp=\([^&]*\).*/\1/p')

    sni=$(url_component_decode "$sni")
    pbk=$(url_component_decode "$pbk")
    sid=$(url_component_decode "$sid")
    flow=$(url_component_decode "$flow")
    fp=$(url_component_decode "$fp")

    [ -z "$fp" ] && fp="chrome"
    [ -z "$flow" ] && flow="xtls-rprx-vision"
    [ -z "$sni" ] && sni="$host"

    esc_tag=$(json_escape "$tag")
    esc_host=$(json_escape "$host")
    esc_uuid=$(json_escape "$uuid")
    esc_flow=$(json_escape "$flow")
    esc_sni=$(json_escape "$sni")
    esc_fp=$(json_escape "$fp")
    esc_pbk=$(json_escape "$pbk")
    esc_sid=$(json_escape "$sid")

    if [ -n "$pbk" ]; then
        printf '{ "type": "vless", "tag": "%s", "server": "%s", "server_port": %s, "uuid": "%s", "flow": "%s", "packet_encoding": "xudp", "tls": { "enabled": true, "server_name": "%s", "utls": { "enabled": true, "fingerprint": "%s" }, "reality": { "enabled": true, "public_key": "%s", "short_id": "%s" } } }' \
            "$esc_tag" "$esc_host" "$port" "$esc_uuid" "$esc_flow" "$esc_sni" "$esc_fp" "$esc_pbk" "$esc_sid"
    else
        printf '{ "type": "vless", "tag": "%s", "server": "%s", "server_port": %s, "uuid": "%s", "packet_encoding": "xudp", "tls": { "enabled": true, "server_name": "%s", "utls": { "enabled": true, "fingerprint": "%s" } } }' \
            "$esc_tag" "$esc_host" "$port" "$esc_uuid" "$esc_sni" "$esc_fp"
    fi
}

share_link_tls_json() {
    tls_force="$1"
    tls_security=$(share_link_lower "$2")
    tls_host="$3"
    tls_sni="$4"
    tls_insecure="$5"
    tls_alpn="$6"
    tls_fp="$7"
    tls_pbk="$8"
    tls_sid="$9"

    case "$tls_security" in
        none)
            if [ "$tls_force" != "true" ] && [ "$tls_insecure" != "true" ] && [ -z "$tls_sni$tls_alpn$tls_fp$tls_pbk$tls_sid" ]; then
                return 1
            fi
            ;;
        ""|tls|reality|xtls) ;;
        *)
            [ "$tls_force" = "true" ] || return 1
            ;;
    esac

    tls_server_name="$tls_sni"
    [ -n "$tls_server_name" ] || tls_server_name="$tls_host"
    tls_json='{ "enabled": true'
    [ -n "$tls_server_name" ] && tls_json="$tls_json, \"server_name\": \"$(json_escape "$tls_server_name")\""
    [ "$tls_insecure" = "true" ] && tls_json="$tls_json, \"insecure\": true"
    if [ -n "$tls_alpn" ]; then
        tls_alpn_json=$(share_link_json_array_from_csv "$tls_alpn")
        [ -n "$tls_alpn_json" ] && tls_json="$tls_json, \"alpn\": [ $tls_alpn_json ]"
    fi
    if [ -n "$tls_fp" ]; then
        tls_json="$tls_json, \"utls\": { \"enabled\": true, \"fingerprint\": \"$(json_escape "$tls_fp")\" }"
    fi
    if [ -n "$tls_pbk" ]; then
        tls_json="$tls_json, \"reality\": { \"enabled\": true, \"public_key\": \"$(json_escape "$tls_pbk")\""
        [ -n "$tls_sid" ] && tls_json="$tls_json, \"short_id\": \"$(json_escape "$tls_sid")\""
        tls_json="$tls_json }"
    fi
    tls_json="$tls_json }"
    printf '%s' "$tls_json"
}

share_link_transport_json() {
    transport_kind=$(share_link_lower "$1")
    transport_host="$2"
    transport_path="$3"
    transport_service_name="$4"
    case "$transport_kind" in
        ""|tcp|raw|none) return 1 ;;
        websocket) transport_kind="ws" ;;
        h2) transport_kind="http" ;;
    esac

    case "$transport_kind" in
        ws)
            transport_json='{ "type": "ws"'
            [ -n "$transport_path" ] && transport_json="$transport_json, \"path\": \"$(json_escape "$transport_path")\""
            transport_host_first=$(share_link_first_csv_value "$transport_host")
            [ -n "$transport_host_first" ] && transport_json="$transport_json, \"headers\": { \"Host\": \"$(json_escape "$transport_host_first")\" }"
            transport_json="$transport_json }"
            ;;
        grpc)
            transport_json='{ "type": "grpc"'
            [ -n "$transport_service_name" ] && transport_json="$transport_json, \"service_name\": \"$(json_escape "$transport_service_name")\""
            transport_host_first=$(share_link_first_csv_value "$transport_host")
            [ -n "$transport_host_first" ] && transport_json="$transport_json, \"authority\": \"$(json_escape "$transport_host_first")\""
            transport_json="$transport_json }"
            ;;
        http)
            transport_json='{ "type": "http"'
            transport_host_json=$(share_link_json_array_from_csv "$transport_host")
            [ -n "$transport_host_json" ] && transport_json="$transport_json, \"host\": [ $transport_host_json ]"
            [ -n "$transport_path" ] && transport_json="$transport_json, \"path\": \"$(json_escape "$transport_path")\""
            transport_json="$transport_json }"
            ;;
        httpupgrade)
            transport_json='{ "type": "httpupgrade"'
            transport_host_first=$(share_link_first_csv_value "$transport_host")
            [ -n "$transport_host_first" ] && transport_json="$transport_json, \"host\": \"$(json_escape "$transport_host_first")\""
            [ -n "$transport_path" ] && transport_json="$transport_json, \"path\": \"$(json_escape "$transport_path")\""
            transport_json="$transport_json }"
            ;;
        quic)
            transport_json='{ "type": "quic" }'
            ;;
        *)
            return 1
            ;;
    esac
    printf '%s' "$transport_json"
}

parse_vless_release_to_json_line() {
    line="$1"
    tag="$2"
    no_name="${line%%#*}"
    core="${no_name%%\?*}"
    params="${no_name#*\?}"
    [ "$params" = "$no_name" ] && params=""
    core_no_prefix=$(printf '%s' "$core" | sed 's#^vless://##')
    uuid=$(printf '%s' "$core_no_prefix" | cut -d'@' -f1)
    host_port=$(printf '%s' "$core_no_prefix" | cut -d'@' -f2)
    endpoint=$(share_link_split_host_port "$host_port" || true)
    host=$(printf '%s' "$endpoint" | cut -f1)
    port=$(printf '%s' "$endpoint" | cut -f2)
    [ -n "$uuid" ] || return 1
    [ -n "$host" ] || return 1
    [ -n "$port" ] || port=443

    security=$(share_link_query_value_any "$params" security type_security tls || true)
    transport_type=$(share_link_query_value_any "$params" type transport net || true)
    header_host=$(share_link_query_value_any "$params" host hostHeader wsHost authority || true)
    path=$(share_link_query_value_any "$params" path wsPath httpPath httpupgradePath || true)
    service_name=$(share_link_query_value_any "$params" serviceName service_name grpcServiceName grpc_service_name || true)
    sni=$(share_link_query_value_any "$params" sni serverName server_name peer || true)
    pbk=$(share_link_query_value_any "$params" pbk publicKey public_key || true)
    sid=$(share_link_query_value_any "$params" sid shortId short_id || true)
    flow=$(share_link_query_value_any "$params" flow || true)
    fp=$(share_link_query_value_any "$params" fp fingerprint client_fingerprint || true)
    alpn=$(share_link_query_value_any "$params" alpn || true)
    packet_encoding=$(share_link_query_value_any "$params" packetEncoding packet_encoding || true)
    insecure="false"
    share_link_query_truthy_any "$params" allowInsecure allow_insecure insecure skip-cert-verify skip_cert_verify && insecure="true"

    [ -n "$pbk" ] && [ -z "$flow" ] && flow="xtls-rprx-vision"
    [ -n "$pbk" ] && [ -z "$fp" ] && fp="chrome"
    [ -z "$packet_encoding" ] && packet_encoding="xudp"

    tls_json=$(share_link_tls_json "false" "$security" "$host" "$sni" "$insecure" "$alpn" "$fp" "$pbk" "$sid" || true)
    transport_json=$(share_link_transport_json "$transport_type" "$header_host" "$path" "$service_name" || true)

    vless_json='{ "type": "vless", "tag": "'"$(json_escape "$tag")"'", "server": "'"$(json_escape "$host")"'", "server_port": '"$port"', "uuid": "'"$(json_escape "$uuid")"'"'
    [ -n "$flow" ] && vless_json="$vless_json, \"flow\": \"$(json_escape "$flow")\""
    if [ -n "$packet_encoding" ] && [ "$packet_encoding" != "none" ]; then
        vless_json="$vless_json, \"packet_encoding\": \"$(json_escape "$packet_encoding")\""
    fi
    [ -n "$tls_json" ] && vless_json="$vless_json, \"tls\": $tls_json"
    [ -n "$transport_json" ] && vless_json="$vless_json, \"transport\": $transport_json"
    vless_json="$vless_json }"
    printf '%s' "$vless_json"
}

parse_trojan_to_json_line() {
    line="$1"
    tag="$2"
    no_name="${line%%#*}"
    core="${no_name%%\?*}"
    params="${no_name#*\?}"
    [ "$params" = "$no_name" ] && params=""
    core_no_prefix=$(printf '%s' "$core" | sed 's#^trojan://##')
    password_enc=$(printf '%s' "$core_no_prefix" | cut -d'@' -f1)
    host_port=$(printf '%s' "$core_no_prefix" | cut -d'@' -f2)
    endpoint=$(share_link_split_host_port "$host_port" || true)
    host=$(printf '%s' "$endpoint" | cut -f1)
    port=$(printf '%s' "$endpoint" | cut -f2)
    [ -n "$host" ] || return 1
    [ -n "$password_enc" ] || return 1
    [ -n "$port" ] || port=443

    password=$(url_component_decode "$password_enc")
    security=$(share_link_query_value_any "$params" security tls || true)
    transport_type=$(share_link_query_value_any "$params" type transport net || true)
    header_host=$(share_link_query_value_any "$params" host hostHeader wsHost authority || true)
    path=$(share_link_query_value_any "$params" path wsPath httpPath httpupgradePath || true)
    service_name=$(share_link_query_value_any "$params" serviceName service_name grpcServiceName grpc_service_name || true)
    sni=$(share_link_query_value_any "$params" sni serverName server_name peer || true)
    fp=$(share_link_query_value_any "$params" fp fingerprint client_fingerprint || true)
    alpn=$(share_link_query_value_any "$params" alpn || true)
    pbk=$(share_link_query_value_any "$params" pbk publicKey public_key || true)
    sid=$(share_link_query_value_any "$params" sid shortId short_id || true)
    insecure="false"
    share_link_query_truthy_any "$params" allowInsecure allow_insecure insecure skip-cert-verify skip_cert_verify && insecure="true"

    [ -z "$security" ] && security="tls"
    [ -z "$fp" ] && [ -n "$pbk" ] && fp="chrome"

    tls_json=$(share_link_tls_json "false" "$security" "$host" "$sni" "$insecure" "$alpn" "$fp" "$pbk" "$sid" || true)
    transport_json=$(share_link_transport_json "$transport_type" "$header_host" "$path" "$service_name" || true)

    trojan_json='{ "type": "trojan", "tag": "'"$(json_escape "$tag")"'", "server": "'"$(json_escape "$host")"'", "server_port": '"$port"', "password": "'"$(json_escape "$password")"'"'
    [ -n "$tls_json" ] && trojan_json="$trojan_json, \"tls\": $tls_json"
    [ -n "$transport_json" ] && trojan_json="$trojan_json, \"transport\": $transport_json"
    trojan_json="$trojan_json }"
    printf '%s' "$trojan_json"
}

parse_hysteria2_to_json_line() {
    line="$1"
    tag="$2"
    no_name="${line%%#*}"
    core="${no_name%%\?*}"
    params="${no_name#*\?}"
    [ "$params" = "$no_name" ] && params=""
    core_no_prefix=$(printf '%s' "$core" | sed 's#^hy2://##; s#^hysteria2://##')
    password_enc=$(printf '%s' "$core_no_prefix" | cut -d'@' -f1)
    host_port=$(printf '%s' "$core_no_prefix" | cut -d'@' -f2)
    endpoint=$(share_link_split_host_port "$host_port" || true)
    host=$(printf '%s' "$endpoint" | cut -f1)
    port=$(printf '%s' "$endpoint" | cut -f2)
    [ -n "$host" ] || return 1
    [ -n "$password_enc" ] || return 1
    [ -n "$port" ] || port=443

    password=$(url_component_decode "$password_enc")
    sni=$(share_link_query_value_any "$params" sni serverName server_name peer || true)
    alpn=$(share_link_query_value_any "$params" alpn || true)
    insecure="false"
    share_link_query_truthy_any "$params" allowInsecure allow_insecure insecure skip-cert-verify skip_cert_verify && insecure="true"
    up_mbps=$(share_link_query_value_any "$params" upmbps up_mbps up || true)
    down_mbps=$(share_link_query_value_any "$params" downmbps down_mbps down || true)
    obfs_type=$(share_link_query_value_any "$params" obfs obfs-type obfs_type || true)
    obfs_password=$(share_link_query_value_any "$params" obfs-password obfs_password obfsPassword || true)
    [ -z "$obfs_type" ] && [ -n "$obfs_password" ] && obfs_type="salamander"

    tls_json=$(share_link_tls_json "true" "tls" "$host" "$sni" "$insecure" "$alpn" "" "" "" || true)
    [ -n "$tls_json" ] || return 1

    hy2_json='{ "type": "hysteria2", "tag": "'"$(json_escape "$tag")"'", "server": "'"$(json_escape "$host")"'", "server_port": '"$port"', "password": "'"$(json_escape "$password")"'", "tls": '"$tls_json"
    case "$up_mbps" in
        ""|*[!0-9]*) ;;
        *) hy2_json="$hy2_json, \"up_mbps\": $up_mbps" ;;
    esac
    case "$down_mbps" in
        ""|*[!0-9]*) ;;
        *) hy2_json="$hy2_json, \"down_mbps\": $down_mbps" ;;
    esac
    if [ -n "$obfs_type" ] || [ -n "$obfs_password" ]; then
        hy2_json="$hy2_json, \"obfs\": {"
        [ -n "$obfs_type" ] && hy2_json="$hy2_json \"type\": \"$(json_escape "$obfs_type")\""
        if [ -n "$obfs_password" ]; then
            [ -n "$obfs_type" ] && hy2_json="$hy2_json,"
            hy2_json="$hy2_json \"password\": \"$(json_escape "$obfs_password")\""
        fi
        hy2_json="$hy2_json }"
    fi
    hy2_json="$hy2_json }"
    printf '%s' "$hy2_json"
}

parse_share_link_to_json_line() {
    line="$1"
    tag="$2"
    share_protocol=$(share_link_protocol_from_line "$line" || true)
    case "$share_protocol" in
        vless) parse_vless_release_to_json_line "$line" "$tag" ;;
        trojan) parse_trojan_to_json_line "$line" "$tag" ;;
        hysteria2) parse_hysteria2_to_json_line "$line" "$tag" ;;
        *) return 1 ;;
    esac
}

build_candidate_config() {
    payload_file="$1"
    raw_file="$2"
    custom_file="$3"
    candidate="$4"
    use_auto_redirect="$5"
    route_mode="$6"
    strict_mode="$7"
    selected_ids_override_file="${8:-}"

    POST_DATA=$(read_text_file_clean "$payload_file")

    rules_refilter=$(json_get_bool "refilter")
    rules_proxy_blocked=$(json_get_bool "proxy_blocked")
    rules_proxy_ai=$(json_get_bool "proxy_ai")
    rules_direct_ru=$(json_get_bool "direct_ru")
    rules_force_ru_suffix=$(json_get_bool "force_ru_suffix")
    force_full_proxy=$(json_get_bool "force_full_proxy")
    full_proxy_mode="false"

    if bool_is_true "$force_full_proxy"; then
        rules_refilter="false"
        rules_proxy_blocked="false"
        rules_proxy_ai="false"
        rules_direct_ru="false"
        rules_force_ru_suffix="false"
        full_proxy_mode="true"
    fi

    if ! bool_is_true "$rules_refilter" && ! bool_is_true "$rules_proxy_ai" && ! bool_is_true "$rules_direct_ru" && ! bool_is_true "$rules_force_ru_suffix"; then
        full_proxy_mode="true"
    fi

    server_cache="$TMP_DIR/server_cache_build.txt"
    build_server_cache "$raw_file" "$server_cache"

    selected_ids_file="$TMP_DIR/selected_ids_apply.txt"
    effective_selected_ids_file="$TMP_DIR/selected_ids_effective.txt"
    if [ -n "$selected_ids_override_file" ] && [ -s "$selected_ids_override_file" ]; then
        cp "$selected_ids_override_file" "$selected_ids_file"
    else
        json_get_servers > "$selected_ids_file"
    fi
    build_effective_selected_ids "$selected_ids_file" "$server_cache" "$effective_selected_ids_file"

    tags_file="$TMP_DIR/tags.txt"
    proxies_file="$TMP_DIR/proxies.txt"
    selected_seen_file="$TMP_DIR/selected_ids.seen.txt"
    : > "$tags_file"
    : > "$proxies_file"
    : > "$selected_seen_file"

    while IFS="$(printf '\t')" read -r sid sname stag sline; do
        [ -n "$sid" ] || continue
        if grep -Fxq "$sid" "$effective_selected_ids_file"; then
            if grep -Fxq "$sid" "$selected_seen_file" 2>/dev/null; then
                continue
            fi
            printf '%s\n' "$sid" >> "$selected_seen_file"
            parsed_proxy=$(parse_share_link_to_json_line "$sline" "$stag" 2>/dev/null || true)
            [ -n "$parsed_proxy" ] || continue
            esc_tag=$(json_escape "$stag")
            printf '"%s",\n' "$esc_tag" >> "$tags_file"
            printf '%s,\n' "$parsed_proxy" >> "$proxies_file"
        fi
    done < "$server_cache"

    TAGS_JSON=$(sed '$ s/,$//' "$tags_file" 2>/dev/null | tr '\n' ' ')
    PROXIES_JSON=$(sed '$ s/,$//' "$proxies_file" 2>/dev/null)

    [ -n "$TAGS_JSON" ] || return 1
    [ -n "$PROXIES_JSON" ] || return 1

    custom_domains=""
    if [ -f "$custom_file" ]; then
        custom_domains=$(grep -v '^[[:space:]]*#' "$custom_file" | grep -v '^[[:space:]]*$' | tr -d '\r' | awk '{printf "\"%s\",", $1}' | sed 's/,$//')
    fi
    manual_domains=$(manual_domains_json_from_payload)

    route_rules_file="$TMP_DIR/route_rules.txt"
    dns_rules_file="$TMP_DIR/dns_rules.txt"
    rule_set_file="$TMP_DIR/rule_set.txt"
    : > "$route_rules_file"
    : > "$dns_rules_file"
    : > "$rule_set_file"

    PROXY_DOMAINS=""
    if [ -n "$custom_domains" ]; then
        PROXY_DOMAINS="$custom_domains"
    fi
    if [ -n "$manual_domains" ]; then
        [ -n "$PROXY_DOMAINS" ] && PROXY_DOMAINS="$PROXY_DOMAINS, "
        PROXY_DOMAINS="$PROXY_DOMAINS$manual_domains"
    fi
    if bool_is_true "$rules_proxy_ai"; then
        [ -n "$PROXY_DOMAINS" ] && PROXY_DOMAINS="$PROXY_DOMAINS, "
        PROXY_DOMAINS="$PROXY_DOMAINS\"openai.com\", \"chatgpt.com\", \"oaistatic.com\", \"oaiusercontent.com\", \"gemini.google.com\", \"bard.google.com\", \"generativeai.google\", \"accounts.google.com\", \"ogs.google.com\", \"content-push.googleapis.com\", \"googleapis.com\", \"gstatic.com\", \"anthropic.com\", \"claude.ai\", \"canva.com\", \"canva.me\", \"netflix.com\", \"nflxext.com\", \"nflxvideo.net\", \"scdn.co\", \"intel.com\", \"amd.com\", \"nvidia.com\""
    fi
    if [ -n "$PROXY_DOMAINS" ]; then
        printf '{ "domain_suffix": [ %s ], "outbound": "AUTO-BALANCE" },\n' "$PROXY_DOMAINS" >> "$route_rules_file"
        printf '{ "domain_suffix": [ %s ], "action": "route", "server": "proxy-dns" },\n' "$PROXY_DOMAINS" >> "$dns_rules_file"
    fi

    if bool_is_true "$rules_direct_ru"; then
        DIRECT_DOMAINS='"yandex.ru", "yandex.net", "ya.ru", "vk.com", "vk.ru", "mail.ru", "gosuslugi.ru", "mos.ru", "sberbank.ru", "tbank.ru", "ozon.ru", "wildberries.ru", "wildberries.com", "wb.ru", "avito.ru", "kinopoisk.ru", "rutube.ru", "dzen.ru", "ok.ru", "kaspersky.ru", "drweb.ru", "apple.com", "icloud.com", "mzstatic.com"'
        printf '{ "domain_suffix": [ %s ], "outbound": "direct" },\n' "$DIRECT_DOMAINS" >> "$route_rules_file"
        printf '{ "domain_suffix": [ %s ], "action": "route", "server": "local-dns" },\n' "$DIRECT_DOMAINS" >> "$dns_rules_file"
    fi

    if bool_is_true "$rules_force_ru_suffix"; then
        RU_SUFFIXES='"ru", "xn--p1ai", "su"'
        printf '{ "domain_suffix": [ %s ], "outbound": "direct" },\n' "$RU_SUFFIXES" >> "$route_rules_file"
        printf '{ "domain_suffix": [ %s ], "action": "route", "server": "local-dns" },\n' "$RU_SUFFIXES" >> "$dns_rules_file"
    fi

    # Если включен Re:filter, подмешиваем ядро blocked-сервисов (YouTube/Telegram/Discord и т.д.)
    # даже при снятой галке proxy_blocked, чтобы маршрутизация не ломалась от одной ошибки в UI.
    if bool_is_true "$rules_proxy_blocked" || bool_is_true "$rules_refilter"; then
        TG_IPS='"149.154.160.0/20", "91.108.4.0/22", "91.108.56.0/22", "91.108.8.0/22", "95.161.64.0/20"'
        BLOCKED_DOMS='"instagram.com", "cdninstagram.com", "facebook.com", "fbcdn.net", "twitter.com", "x.com", "t.co", "twimg.com", "youtube.com", "youtu.be", "googlevideo.com", "ytimg.com", "ggpht.com", "yt3.googleusercontent.com", "www.gstatic.com", "youtubei.googleapis.com", "optimizationguide-pa.googleapis.com", "rutracker.org", "bbc.com", "tiktok.com", "tiktokcdn.com", "linkedin.com", "licdn.com", "discord.com", "discord.gg", "discordapp.com", "discordapp.net", "telegram.org", "t.me", "telegram.me", "web.telegram.org", "cdn-telegram.org"'
        printf '{ "ip_cidr": [ %s ], "outbound": "AUTO-BALANCE" },\n' "$TG_IPS" >> "$route_rules_file"
        printf '{ "domain_suffix": [ %s ], "outbound": "AUTO-BALANCE" },\n' "$BLOCKED_DOMS" >> "$route_rules_file"
        printf '{ "domain_suffix": [ %s ], "action": "route", "server": "proxy-dns" },\n' "$BLOCKED_DOMS" >> "$dns_rules_file"
    fi

    if bool_is_true "$rules_refilter"; then
        if ensure_refilter_rule_sets_ready; then
            printf '{ "tag": "refilter_domains", "type": "local", "format": "binary", "path": "%s" },\n' "$REFILTER_DOMAINS_FILE" >> "$rule_set_file"
            printf '{ "tag": "refilter_ipsum", "type": "local", "format": "binary", "path": "%s" },\n' "$REFILTER_IPSUM_FILE" >> "$rule_set_file"
        else
            return 1
        fi
        printf '{ "rule_set": ["refilter_domains", "refilter_ipsum"], "outbound": "AUTO-BALANCE" },\n' >> "$route_rules_file"
        printf '{ "rule_set": ["refilter_domains"], "action": "route", "server": "proxy-dns" },\n' >> "$dns_rules_file"
    fi

    RULE_SET_BLOCK=$(sed '$ s/,$//' "$rule_set_file" 2>/dev/null | tr '\n' ' ')
    ROUTE_RULES_JSON=$(sed '$ s/,$//' "$route_rules_file" 2>/dev/null | tr '\n' ' ')
    DNS_RULES_JSON=$(sed '$ s/,$//' "$dns_rules_file" 2>/dev/null | tr '\n' ' ')
    [ -n "$ROUTE_RULES_JSON" ] && ROUTE_RULES_JSON="$ROUTE_RULES_JSON,"
    [ -n "$DNS_RULES_JSON" ] && DNS_RULES_JSON="$DNS_RULES_JSON,"

    FINAL_OUTBOUND="direct"
    DNS_FINAL="local-dns"
    DNS_ANY_SERVER="local-dns"
    if [ "$full_proxy_mode" = "true" ]; then
        FINAL_OUTBOUND="AUTO-BALANCE"
        DNS_FINAL="local-dns"
        DNS_ANY_SERVER="local-dns"
    fi

    TUN_ROUTE_EXTRA=""
    if [ "$use_auto_redirect" = "true" ]; then
        TUN_ROUTE_EXTRA=', "auto_redirect": true'
    fi

    ROUTE_BIND_JSON='    "auto_detect_interface": true,'
    WAN_IF=$(detect_default_interface)
    if [ "$route_mode" = "default_interface" ] && [ -n "$WAN_IF" ]; then
        esc_wan=$(json_escape "$WAN_IF")
        ROUTE_BIND_JSON='    "default_interface": "'$esc_wan'",'
    fi

    STRICT_JSON="true"
    [ "$strict_mode" = "false" ] && STRICT_JSON="false"

    cat > "$candidate" <<CONFIG
{
  "log": { "level": "info" },
  "dns": {
    "servers": [
      { "type": "https", "tag": "proxy-dns", "server": "dns.google", "path": "/dns-query", "tls": { "server_name": "dns.google" }, "domain_resolver": "local-dns", "detour": "AUTO-BALANCE" },
      { "type": "udp", "tag": "local-dns", "server": "8.8.4.4", "server_port": 53 }
    ],
    "rules": [
      $DNS_RULES_JSON
      { "action": "route", "server": "$DNS_ANY_SERVER" }
    ],
    "final": "$DNS_FINAL",
    "strategy": "ipv4_only",
    "independent_cache": true
  },
  "inbounds": [
    { "type": "tun", "tag": "tun-in", "interface_name": "tun0", "address": ["172.19.0.1/30"], "auto_route": true, "strict_route": $STRICT_JSON$TUN_ROUTE_EXTRA }
  ],
  "outbounds": [
    { "type": "urltest", "tag": "AUTO-BALANCE", "outbounds": [ $TAGS_JSON ], "url": "https://www.gstatic.com/generate_204", "interval": "$URLTEST_INTERVAL", "tolerance": $URLTEST_TOLERANCE, "idle_timeout": "30m", "interrupt_exist_connections": false },
    { "type": "direct", "tag": "direct" },
    $PROXIES_JSON
  ],
  "route": {
$ROUTE_BIND_JSON
    "default_domain_resolver": "local-dns",
    "rule_set": [ $RULE_SET_BLOCK ],
    "rules": [
      { "inbound": "tun-in", "action": "sniff" },
      { "protocol": "dns", "action": "hijack-dns" },
      { "ip_is_private": true, "outbound": "direct" },
      $ROUTE_RULES_JSON
      { "port": 53, "action": "hijack-dns" }
    ],
    "final": "$FINAL_OUTBOUND"
  }
}
CONFIG
}

try_runtime_start() {
    candidate="$1"
    mode="$2"
    probe_settings_file="${3:-$SETTINGS_FILE}"
    probe_profile="${4:-default}"
    runtime_start_target="$candidate"
    runtime_config_backup="$TMP_DIR/config.runtime.backup.json"
    promoted_to_canonical="false"

    rm -f "$runtime_config_backup"
    if [ "$candidate" != "$CONFIG_FILE" ]; then
        if [ -s "$CONFIG_FILE" ]; then
            cp "$CONFIG_FILE" "$runtime_config_backup"
        fi
        if ! cp "$candidate" "$CONFIG_FILE"; then
            if [ -s "$runtime_config_backup" ]; then
                cp "$runtime_config_backup" "$CONFIG_FILE" >/dev/null 2>&1 || true
            else
                rm -f "$CONFIG_FILE"
            fi
            archive_current_error_if_any
            {
                echo "failed to promote candidate config to canonical runtime path"
                echo "candidate=$candidate"
                echo "config_file=$CONFIG_FILE"
            } > "$ERR_FILE"
            return 1
        fi
        runtime_start_target="$CONFIG_FILE"
        promoted_to_canonical="true"
    fi

    clear_current_error
    reset_watchdog_fail_count
    if /usr/bin/gog-proxy-start "$runtime_start_target" >/dev/null 2>&1; then
        if ! runtime_probe_connectivity "$runtime_start_target" "$probe_settings_file" "$probe_profile"; then
            archive_current_error_if_any
            {
                echo "mode $mode started, but internet probe failed"
                echo "probe_state=$(read_probe_state)"
                [ -s "$LOG_FILE" ] && tail -n 30 "$LOG_FILE"
            } > "$ERR_FILE"
            /usr/bin/gog-proxy-stop >/dev/null 2>&1 || true
            if [ "$promoted_to_canonical" = "true" ]; then
                if [ -s "$runtime_config_backup" ]; then
                    cp "$runtime_config_backup" "$CONFIG_FILE" >/dev/null 2>&1 || true
                else
                    rm -f "$CONFIG_FILE"
                fi
            fi
            rm -f "$runtime_config_backup"
            return 1
        fi

        # Guard against false-positive starts: keep process alive for a short stabilization window.
        i=0
        while [ "$i" -lt 5 ]; do
            sleep 1
            if ! pidof sing-box >/dev/null 2>&1; then
                archive_current_error_if_any
                {
                    echo "mode $mode started, but sing-box exited during stabilization window"
                    [ -s "$LOG_FILE" ] && tail -n 40 "$LOG_FILE"
                } > "$ERR_FILE"
                if [ "$promoted_to_canonical" = "true" ]; then
                    if [ -s "$runtime_config_backup" ]; then
                        cp "$runtime_config_backup" "$CONFIG_FILE" >/dev/null 2>&1 || true
                    else
                        rm -f "$CONFIG_FILE"
                    fi
                fi
                rm -f "$runtime_config_backup"
                return 1
            fi
            i=$((i+1))
        done

        printf '%s' "$mode" > "$MODE_FILE"
        rm -f "$runtime_config_backup"
        return 0
    fi

    capture_last_runtime_error
    /usr/bin/gog-proxy-stop >/dev/null 2>&1 || true
    if [ "$promoted_to_canonical" = "true" ]; then
        if [ -s "$runtime_config_backup" ]; then
            cp "$runtime_config_backup" "$CONFIG_FILE" >/dev/null 2>&1 || true
        else
            rm -f "$CONFIG_FILE"
        fi
    fi
    rm -f "$runtime_config_backup"
    return 1
}

attempt_quarantine_retry_runtime_start() {
    payload_file="$1"
    raw_file="$2"
    custom_file="$3"
    server_cache="$4"
    selected_ids_source_file="$5"
    effective_selected_ids_file="$6"
    candidate="$7"
    mode_name="$8"
    route_mode="$9"
    strict_mode="${10}"
    label="${11}"
    start_reason="${12:-apply}"
    probe_profile="${13:-default}"

    probe_state=$(read_probe_state)
    [ "$probe_state" = "proxy_failed" ] || return 1

    selected_count=$(count_lines_in_file "$selected_ids_source_file")
    [ "$selected_count" -gt 1 ] 2>/dev/null || return 1

    bad_sid=$(detect_quarantine_candidate_id "$server_cache" || true)
    [ -n "$bad_sid" ] || return 1
    grep -Fxq "$bad_sid" "$selected_ids_source_file" 2>/dev/null || return 1

    quarantine_server_id "$bad_sid"
    build_effective_selected_ids "$selected_ids_source_file" "$server_cache" "$effective_selected_ids_file"
    effective_count=$(count_lines_in_file "$effective_selected_ids_file")
    if [ "$effective_count" -le 0 ] 2>/dev/null || [ "$effective_count" -ge "$selected_count" ] 2>/dev/null; then
        return 1
    fi

    use_ar="false"
    [ "$mode_name" = "auto_redirect" ] && use_ar="true"

    if build_candidate_config "$payload_file" "$raw_file" "$custom_file" "$candidate" "$use_ar" "$route_mode" "$strict_mode" "$effective_selected_ids_file" && \
       validate_config "$candidate" && \
       try_runtime_start "$candidate" "$label" "$payload_file" "$probe_profile"; then
        bad_name=$(server_name_from_id "$bad_sid" "$server_cache" || true)
        if [ -n "$bad_name" ]; then
            append_runtime_note "$start_reason auto-quarantined failing AUTO-BALANCE member $bad_name ($bad_sid) during start retry"
        else
            append_runtime_note "$start_reason auto-quarantined failing AUTO-BALANCE member id=$bad_sid during start retry"
        fi
        return 0
    fi

    return 1
}

commit_active_files() {
    new_raw="$1"
    new_custom="$2"
    candidate="$3"
    new_payload="$4"
    active_selected_ids_file="${5:-}"
    server_cache_file="${6:-}"
    persisted_selected_ids_file="${7:-}"
    payload_commit_tmp="$TMP_DIR/payload.commit.json"

    cp "$new_raw" "$RAW_FILE"
    cp "$new_custom" "$CUSTOM_FILE"
    [ -s "$CONFIG_FILE" ] || cp "$candidate" "$CONFIG_FILE"
    if [ -n "$active_selected_ids_file" ] && [ -s "$active_selected_ids_file" ]; then
        copy_text_file_clean "$active_selected_ids_file" "$ACTIVE_SELECTED_IDS_FILE"
    elif [ -n "$persisted_selected_ids_file" ] && [ -s "$persisted_selected_ids_file" ]; then
        copy_text_file_clean "$persisted_selected_ids_file" "$ACTIVE_SELECTED_IDS_FILE"
    else
        rm -f "$ACTIVE_SELECTED_IDS_FILE"
    fi
    if [ -n "$server_cache_file" ] && [ -f "$server_cache_file" ]; then
        cp "$server_cache_file" "$SERVERS_CACHE"
    else
        build_server_cache "$RAW_FILE" "$SERVERS_CACHE"
    fi

    if [ -n "$persisted_selected_ids_file" ] && [ -f "$persisted_selected_ids_file" ] && [ -s "$SERVERS_CACHE" ]; then
        sanitize_json_servers_against_cache "$new_payload" "$SERVERS_CACHE" "$payload_commit_tmp"
        copy_text_file_clean "$payload_commit_tmp" "$PAYLOAD_FILE"
        copy_text_file_clean "$payload_commit_tmp" "$SETTINGS_FILE"
        rm -f "$payload_commit_tmp"
    else
        copy_text_file_clean "$new_payload" "$PAYLOAD_FILE"
        copy_text_file_clean "$new_payload" "$SETTINGS_FILE"
    fi

    clear_manual_stop
    set_autostart
    install_cron
}

handle_get_servers() {
    source_value=""
    if [ "${REQUEST_METHOD:-GET}" = "POST" ]; then
        POST_DATA=$(strip_utf8_bom_text "$(read_post_body)")
        source_value=$(json_get_string "url")
    fi
    if [ -z "$source_value" ]; then
        enc_url=$(printf '%s' "${QUERY_STRING:-}" | sed -n 's/.*url=\([^&]*\).*/\1/p')
        [ -n "$enc_url" ] && source_value=$(url_decode "$enc_url")
    fi
    [ -n "$source_value" ] || fail_json_transient "Пустой источник серверов."

    source_mode=$(subscription_source_kind "$source_value" || true)
    case "$source_mode" in
        remote|inline) ;;
        *)
            fail_json_transient "Неподдерживаемый формат источника. Используйте http(s):// или одну/несколько строк vless://, trojan://, hy2:// или hysteria2://."
            ;;
    esac

    temp_raw="$TMP_DIR/raw_sub_preview.$$.$RANDOM.txt"
    cache="$TMP_DIR/server_preview_cache.$$.$RANDOM.txt"
    old_cache="$TMP_DIR/server_preview_old_cache.$$.$RANDOM.txt"
    preview_selected="$TMP_DIR/server_preview_selected.$$.$RANDOM.txt"
    preview_source_selected="$TMP_DIR/server_preview_selected.source.$$.$RANDOM.txt"
    rm -f "$temp_raw" "$cache" "$old_cache" "$preview_selected" "$preview_source_selected"

    if ! prepare_subscription_source_file "$source_value" "$temp_raw"; then
        fail_json_transient "Не удалось получить источник серверов."
    fi
    if ! validate_subscription_file "$temp_raw"; then
        fail_json_transient "Источник серверов не содержит поддерживаемых share-link строк."
    fi

    build_server_cache "$temp_raw" "$cache"
    if [ -s "$SERVERS_CACHE" ]; then
        cp "$SERVERS_CACHE" "$old_cache"
    elif [ -f "$RAW_FILE" ]; then
        build_server_cache "$RAW_FILE" "$old_cache"
    fi
    settings_get_selected_ids > "$preview_source_selected"
    build_replenished_selected_ids "$preview_source_selected" "$old_cache" "$cache" "$preview_selected"
    print_servers_json "$cache" "" "$preview_selected"
    rm -f "$temp_raw" "$cache" "$old_cache" "$preview_selected" "$preview_source_selected"
    exit 0
}

handle_get_config() {
    active_sid=$(current_active_server_id || true)
    config_selected_override="$TMP_DIR/get_config.selected.override.$$.$RANDOM.txt"
    : > "$config_selected_override"
    if [ ! -s "$SERVERS_CACHE" ] && [ -f "$RAW_FILE" ]; then
        build_server_cache "$RAW_FILE" "$SERVERS_CACHE"
    fi
    if [ -s "$SERVERS_CACHE" ]; then
        build_best_available_selected_ids "$SERVERS_CACHE" "$config_selected_override"
    fi
    printf '{"settings":'
    get_current_settings_json "${SERVERS_CACHE:-}" "$config_selected_override"
    printf ',"servers":'
    if [ -s "$SERVERS_CACHE" ]; then
        print_servers_array "$SERVERS_CACHE" "$active_sid" "$config_selected_override"
    else
        printf '[]'
    fi
    if [ -n "$active_sid" ]; then
        printf ',"active_server_id":"%s"' "$(json_escape "$active_sid")"
    fi
    printf ',"refilter_bootstrap_ready":%s' "$(refilter_bootstrap_ready && printf 'true' || printf 'false')"
    printf ',"refilter_active_ready":%s' "$(refilter_active_ready && printf 'true' || printf 'false')"
    printf '}\n'
    rm -f "$config_selected_override"
    exit 0
}

extract_config_final() {
    section="$1"
    config_file="${2:-$CONFIG_FILE}"
    [ -s "$config_file" ] || return 0
    awk -v sec="\"$section\"" '
        $0 ~ sec"[[:space:]]*:[[:space:]]*\\{" { in_sec=1; next }
        in_sec {
            if ($0 ~ /"final"[[:space:]]*:[[:space:]]*"/) {
                line=$0
                sub(/.*"final"[[:space:]]*:[[:space:]]*"/, "", line)
                sub(/".*/, "", line)
                print line
                exit
            }
            if ($0 ~ /^[[:space:]]*}[[:space:]]*,?[[:space:]]*$/) in_sec=0
        }
    ' "$config_file"
}

handle_status() {
    runtime_status="stopped"
    if pidof sing-box >/dev/null 2>&1; then
        runtime_status="running"
    fi

    mode_val=""
    route_final=""
    dns_final=""
    active_sid=""
    routing_profile=""
    last_error=""
    probe_state=""
    manual_stop="false"
    manual_stop_requested && manual_stop="true"
    [ -s "$PROBE_STATE_FILE" ] && probe_state=$(tail -n 5 "$PROBE_STATE_FILE" 2>/dev/null | tail -n 1 || true)
    discard_transient_current_error_if_healthy "$runtime_status" "$probe_state" >/dev/null 2>&1 || true
    [ -s "$ERR_FILE" ] && last_error=$(tail -n 20 "$ERR_FILE" 2>/dev/null || true)
    if [ "$runtime_status" = "running" ]; then
        mode_val=$(current_mode_label || true)
        route_final=$(extract_config_final "route")
        dns_final=$(extract_config_final "dns")
        active_sid=$(current_active_server_id || true)
        if [ "$route_final" = "AUTO-BALANCE" ]; then
            routing_profile="full-vpn"
        elif [ -n "$route_final" ] || [ -n "$dns_final" ]; then
            routing_profile="split"
        fi
    fi

    printf '{"status":"'
    printf '%s' "$runtime_status"
    printf '"'
    if [ "$runtime_status" = "running" ] && [ -n "$mode_val" ]; then
        printf ',"mode":"%s"' "$(json_escape "$mode_val")"
    fi
    if [ -n "$route_final" ]; then
        printf ',"route_final":"%s"' "$(json_escape "$route_final")"
    fi
    if [ -n "$dns_final" ]; then
        printf ',"dns_final":"%s"' "$(json_escape "$dns_final")"
    fi
    if [ -n "$routing_profile" ]; then
        printf ',"routing_profile":"%s"' "$(json_escape "$routing_profile")"
    fi
    if [ -n "$active_sid" ]; then
        printf ',"active_server_id":"%s"' "$(json_escape "$active_sid")"
    fi
    if [ -n "$probe_state" ]; then
        printf ',"probe_state":"%s"' "$(json_escape "$probe_state")"
    fi
    if [ -n "$last_error" ]; then
        printf ',"last_error":"%s"' "$(json_escape "$last_error")"
    fi
    if [ "$manual_stop" = "true" ]; then
        printf ',"manual_stop":true'
    fi
    printf ',"refilter_bootstrap_ready":%s' "$(refilter_bootstrap_ready && printf 'true' || printf 'false')"
    printf ',"refilter_active_ready":%s' "$(refilter_active_ready && printf 'true' || printf 'false')"
    printf '}\n'
    exit 0
}

handle_logs() {
    lines=$(printf '%s' "${QUERY_STRING:-}" | sed -n 's/.*lines=\([0-9][0-9]*\).*/\1/p')
    [ -n "$lines" ] || lines=120
    case "$lines" in
        ''|*[!0-9]*) lines=120 ;;
    esac
    [ "$lines" -gt 0 ] 2>/dev/null || lines=120
    [ "$lines" -le 500 ] 2>/dev/null || lines=500

    runtime_status="stopped"
    pidof sing-box >/dev/null 2>&1 && runtime_status="running"
    probe_state=""
    [ -s "$PROBE_STATE_FILE" ] && probe_state=$(tail -n 5 "$PROBE_STATE_FILE" 2>/dev/null | tail -n 1 || true)
    discard_transient_current_error_if_healthy "$runtime_status" "$probe_state" >/dev/null 2>&1 || true

    mode_val=""
    if [ "$runtime_status" = "running" ]; then
        mode_val=$(current_mode_label || true)
    fi

    log_val=""
    if [ -f "$LOG_FILE" ]; then
        log_val=$(read_log_snapshot "$LOG_FILE" "$lines")
    fi
    if [ -z "$log_val" ] && [ -f "$LOG_FILE.1" ]; then
        log_val=$(read_log_snapshot "$LOG_FILE.1" "$lines")
    fi

    err_val=""
    if [ -f "$ERR_FILE" ]; then
        err_val=$(tail -n 40 "$ERR_FILE" 2>/dev/null || true)
    fi

    incident_val=""
    if [ -f "$INCIDENT_LOG_FILE" ]; then
        incident_val=$(tail -n "$INCIDENT_LOG_API_TAIL_LINES" "$INCIDENT_LOG_FILE" 2>/dev/null || true)
    fi

    printf '{"status":"success","running":"%s","mode":"%s","log":"%s","last_error":"%s","incident_history":"%s"}\n' \
        "$runtime_status" \
        "$(json_escape "$mode_val")" \
        "$(json_escape "$log_val")" \
        "$(json_escape "$err_val")" \
        "$(json_escape "$incident_val")"
    exit 0
}

handle_update_status() {
    update_emit_status_json
    exit 0
}

handle_update_save_settings() {
    POST_DATA=$(strip_utf8_bom_text "$(read_post_body)")
    upd_manifest_url=$(json_get_string "manifest_url")
    [ -n "$upd_manifest_url" ] || upd_manifest_url="$GOG_UPDATE_DEFAULT_MANIFEST_URL"
    case "$upd_manifest_url" in
        http://*|https://*) ;;
        *) fail_json_transient "Update manifest URL must start with http:// or https://." ;;
    esac
    upd_auto_check=$(json_get_bool "auto_check_enabled")
    upd_auto_install=$(json_get_bool "auto_install_enabled")
    update_write_settings "$upd_manifest_url" "$upd_auto_check" "$upd_auto_install"
    update_write_status_json "idle" "Update settings saved." 0 "" false none false "" "" 0 "" "not_checked"
    update_emit_status_json
    exit 0
}

handle_update_check() {
    update_check_manifest
    update_emit_status_json
    exit 0
}

handle_update_download() {
    set +e
    upd_package_path=$(update_download_verified_package)
    upd_download_rc=$?
    set -e
    case "$upd_download_rc" in
        0)
            upd_status_text=$(read_text_file_clean "$GOG_UPDATE_STATUS_FILE")
            upd_latest_version=$(json_get_string_from_text "latest_version" "$upd_status_text")
            upd_available=$(json_get_bool_from_text "update_available" "$upd_status_text")
            upd_kind=$(json_get_string_from_text "update_kind" "$upd_status_text")
            upd_auto_install_allowed=$(json_get_bool_from_text "auto_install_allowed" "$upd_status_text")
            upd_package_url=$(json_get_string_from_text "package_url" "$upd_status_text")
            upd_package_sha256=$(json_get_string_from_text "package_sha256" "$upd_status_text")
            upd_package_size=$(json_get_number_from_text "package_size" "$upd_status_text")
            upd_notes_url=$(json_get_string_from_text "notes_url" "$upd_status_text")
            upd_signature_status=$(json_get_string_from_text "signature_status" "$upd_status_text")
            [ -n "$upd_kind" ] || upd_kind="control_plane"
            [ "$upd_available" = "false" ] && upd_available="false" || upd_available="true"
            [ "$upd_auto_install_allowed" = "true" ] || upd_auto_install_allowed="false"
            [ -n "$upd_signature_status" ] || upd_signature_status="verified"
            update_write_status_json "package_downloaded" "Update package downloaded and verified." "$(now_epoch)" "$upd_latest_version" "$upd_available" "$upd_kind" "$upd_auto_install_allowed" "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
            update_emit_status_json
            exit 0
            ;;
        2)
            fail_json_transient "Update package download is blocked until the manifest signature is verified with usign."
            ;;
        *)
            fail_json_transient "No verified update package is available."
            ;;
    esac
}

handle_update_install() {
    ensure_update_dirs
    command -v tar >/dev/null 2>&1 || fail_json_transient "tar is required for update install."

    set +e
    upd_package_path=$(update_download_verified_package)
    upd_download_rc=$?
    set -e
    case "$upd_download_rc" in
        0) ;;
        2) fail_json_transient "Update install is blocked until the manifest signature is verified with usign." ;;
        *) fail_json_transient "No verified update package is available for install." ;;
    esac

    upd_status_text=$(read_text_file_clean "$GOG_UPDATE_STATUS_FILE")
    upd_latest_version=$(json_get_string_from_text "latest_version" "$upd_status_text")
    upd_kind=$(json_get_string_from_text "update_kind" "$upd_status_text")
    upd_auto_install_allowed=$(json_get_bool_from_text "auto_install_allowed" "$upd_status_text")
    upd_package_url=$(json_get_string_from_text "package_url" "$upd_status_text")
    upd_package_sha256=$(json_get_string_from_text "package_sha256" "$upd_status_text")
    upd_package_size=$(json_get_number_from_text "package_size" "$upd_status_text")
    upd_notes_url=$(json_get_string_from_text "notes_url" "$upd_status_text")
    upd_signature_status=$(json_get_string_from_text "signature_status" "$upd_status_text")
    [ -n "$upd_kind" ] || upd_kind="none"
    [ "$upd_auto_install_allowed" = "true" ] || upd_auto_install_allowed="false"
    [ "$upd_signature_status" = "verified" ] || fail_json_transient "Update install requires a verified manifest signature."
    [ "$upd_kind" = "control_plane" ] || fail_json_transient "Only control_plane updates can be installed automatically in this safety phase."

    set +e
    upd_backup_path=$(update_create_backup)
    upd_backup_rc=$?
    set -e
    [ "$upd_backup_rc" -eq 0 ] && [ -d "$upd_backup_path" ] || fail_json_transient "Failed to create update backup."

    upd_extract_dir="$GOG_UPDATE_DOWNLOAD_DIR/extract.$$.$RANDOM"
    rm -rf "$upd_extract_dir"
    mkdir -p "$upd_extract_dir" || fail_json_transient "Failed to create update extract directory."

    update_write_status_json "installing" "Installing update package." "$(now_epoch)" "$upd_latest_version" true "$upd_kind" "$upd_auto_install_allowed" "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"

    set +e
    tar -xzf "$upd_package_path" -C "$upd_extract_dir" >"$GOG_UPDATE_LAST_INSTALL_LOG" 2>&1
    upd_tar_rc=$?
    set -e
    if [ "$upd_tar_rc" -ne 0 ]; then
        update_restore_backup "$upd_backup_path" >/dev/null 2>&1 || true
        update_write_status_json "rollback_done" "Update package extraction failed; rollback restored the previous backup." "$(now_epoch)" "$upd_latest_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
        fail_json_transient "Update package extraction failed; rollback was attempted."
    fi

    [ -s "$upd_extract_dir/update_apply.sh" ] || {
        update_restore_backup "$upd_backup_path" >/dev/null 2>&1 || true
        update_write_status_json "rollback_done" "Update package is missing update_apply.sh; rollback restored the previous backup." "$(now_epoch)" "$upd_latest_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
        fail_json_transient "Update package is missing update_apply.sh; rollback was attempted."
    }
    chmod +x "$upd_extract_dir/update_apply.sh" 2>/dev/null || true

    if ! sh -n "$upd_extract_dir/update_apply.sh" >"$GOG_UPDATE_LAST_INSTALL_LOG" 2>&1; then
        update_restore_backup "$upd_backup_path" >/dev/null 2>&1 || true
        update_write_status_json "rollback_done" "Update apply script failed syntax check; rollback restored the previous backup." "$(now_epoch)" "$upd_latest_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
        fail_json_transient "Update apply script failed syntax check; rollback was attempted."
    fi

    set +e
    ( cd "$upd_extract_dir" && sh ./update_apply.sh ) >"$GOG_UPDATE_LAST_INSTALL_LOG" 2>&1
    upd_apply_rc=$?
    set -e
    if [ "$upd_apply_rc" -ne 0 ]; then
        update_restore_backup "$upd_backup_path" >/dev/null 2>&1 || true
        update_write_status_json "rollback_done" "Update apply failed; rollback restored the previous backup." "$(now_epoch)" "$upd_latest_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
        fail_json_transient "Update apply failed; rollback was attempted."
    fi

    if [ -s "$CONFIG_FILE" ] && pidof sing-box >/dev/null 2>&1; then
        if ! runtime_probe_connectivity "$CONFIG_FILE" "$PAYLOAD_FILE" >/dev/null 2>&1; then
            update_restore_backup "$upd_backup_path" >/dev/null 2>&1 || true
            update_write_status_json "rollback_done" "Post-update health check failed; rollback restored the previous backup." "$(now_epoch)" "$upd_latest_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
            fail_json_transient "Post-update health check failed; rollback was attempted."
        fi
    fi

    update_write_status_json "install_done" "Update installed successfully." "$(now_epoch)" "$upd_latest_version" false "$upd_kind" false "$upd_package_url" "$upd_package_sha256" "$upd_package_size" "$upd_notes_url" "$upd_signature_status" "$upd_package_path"
    update_emit_status_json
    exit 0
}

handle_update_rollback() {
    ensure_update_dirs
    upd_backup_path=""
    [ -s "$GOG_UPDATE_DIR/last_backup_path.txt" ] && upd_backup_path=$(cat "$GOG_UPDATE_DIR/last_backup_path.txt" 2>/dev/null || true)
    case "$upd_backup_path" in
        "$GOG_UPDATE_BACKUP_DIR"/*) ;;
        *) fail_json_transient "No trusted update backup is available for rollback." ;;
    esac
    [ -d "$upd_backup_path" ] || fail_json_transient "Update backup directory is missing."

    update_restore_backup "$upd_backup_path" || fail_json_transient "Update rollback failed while restoring the last backup."
    update_write_status_json "rollback_done" "Rollback restored the last update backup." "$(now_epoch)" "" false none false "" "" 0 "" "not_checked"
    update_emit_status_json
    exit 0
}

handle_log_maint() {
    rotate_log_if_needed
    trim_incident_history_if_needed
    ok_json "log maintenance done"
}

read_service_dependency_review_request() {
    POST_DATA=$(strip_utf8_bom_text "$(read_post_body)")
    [ -n "${POST_DATA:-}" ] || fail_json_transient "Пустой POST payload."

    DEP_SERVICE_ID=$(json_get_string "service_id")
    [ -n "$DEP_SERVICE_ID" ] || fail_json_transient "Не указан service_id."
    service_profile_exists "$DEP_SERVICE_ID" || fail_json_transient "Неизвестный service_id: $DEP_SERVICE_ID"

    DEP_DOMAIN_RAW=$(json_get_string "domain")
    DEP_DOMAIN=$(normalize_domain_value "$DEP_DOMAIN_RAW" 2>/dev/null || true)
    [ -n "$DEP_DOMAIN" ] || fail_json_transient "Не указан валидный домен."
}

print_dependency_review_response() {
    message="$1"
    printf '{"status":"success","message":"%s","last_scan_epoch":%s,"profiles":' \
        "$(json_escape "$message")" \
        "$(service_dependency_last_scan_epoch)"
    print_service_dependency_status_json
    printf '}\n'
    exit 0
}

handle_dependency_scan() {
    service_dependency_scan_all >/dev/null 2>&1 || true
    write_service_dependency_last_scan_epoch
    printf '{"status":"success","message":"dependency scan complete","last_scan_epoch":%s,"profiles":' "$(service_dependency_last_scan_epoch)"
    print_service_dependency_status_json
    printf '}\n'
    exit 0
}

handle_dependency_status() {
    printf '{"status":"success","last_scan_epoch":%s,"profiles":' "$(service_dependency_last_scan_epoch)"
    print_service_dependency_status_json
    printf '}\n'
    exit 0
}

handle_dependency_reset() {
    reset_service_dependency_state
    print_dependency_review_response "dependency review state cleared"
}

handle_dependency_accept() {
    read_service_dependency_review_request
    if ! service_dependency_known_domain "$DEP_SERVICE_ID" "$DEP_DOMAIN"; then
        fail_json_transient "Этот домен ещё не найден learner-ом и не может быть принят вручную."
    fi
    service_dependency_set_review_decision accepted "$DEP_SERVICE_ID" "$DEP_DOMAIN"
    print_dependency_review_response "dependency accepted for manual review memory"
}

handle_dependency_reject() {
    read_service_dependency_review_request
    if ! service_dependency_known_domain "$DEP_SERVICE_ID" "$DEP_DOMAIN"; then
        fail_json_transient "Этот домен ещё не найден learner-ом и не может быть отклонён вручную."
    fi
    service_dependency_set_review_decision rejected "$DEP_SERVICE_ID" "$DEP_DOMAIN"
    print_dependency_review_response "dependency rejected for manual review memory"
}

handle_dependency_unreview() {
    read_service_dependency_review_request
    if ! service_dependency_known_domain "$DEP_SERVICE_ID" "$DEP_DOMAIN"; then
        fail_json_transient "Этот домен не найден в learner-данных."
    fi
    service_dependency_clear_review_decision "$DEP_SERVICE_ID" "$DEP_DOMAIN"
    print_dependency_review_response "dependency review decision cleared"
}

handle_prepare_refilter() {
    if refilter_bootstrap_ready && refilter_active_ready; then
        ok_json "Базы Re:filter уже готовы."
    fi

    if refresh_refilter_rule_sets && ensure_refilter_rule_sets_ready; then
        ok_json "Базы Re:filter подготовлены."
    fi

    fail_json_transient "Не удалось подготовить базы Re:filter. Если это новый роутер, сначала запустите GOG Sing-Box Launcher без Re:filter или в полном VPN, затем повторите подготовку."
}

handle_watchdog() {
    rotate_log_if_needed

    if [ ! -s "$CONFIG_FILE" ] || [ ! -s "$PAYLOAD_FILE" ]; then
        reset_watchdog_fail_count
        ok_json "watchdog skipped: no saved active config"
    fi

    if manual_stop_requested; then
        reset_watchdog_fail_count
        ok_json "watchdog skipped: service intentionally stopped"
    fi

    if runtime_has_process_and_tun; then
        if runtime_probe_connectivity "$CONFIG_FILE" "$PAYLOAD_FILE"; then
            reset_watchdog_fail_count
            ok_json "watchdog ok"
        fi

        probe_state=$(read_probe_state)
        if [ "$probe_state" = "proxy_failed" ]; then
            fail_count="$WATCHDOG_MIN_FAILS"
            [ -s "$RAW_FILE" ] && build_server_cache "$RAW_FILE" "$SERVERS_CACHE" >/dev/null 2>&1 || true
            active_sid=$(current_active_server_id || true)
            active_name=""
            [ -n "$active_sid" ] && active_name=$(server_name_from_id "$active_sid" "$SERVERS_CACHE" || true)
            suspected_sid=$(detect_quarantine_candidate_id "$SERVERS_CACHE" || true)
            suspected_name=""
            [ -n "$suspected_sid" ] && suspected_name=$(server_name_from_id "$suspected_sid" "$SERVERS_CACHE" || true)
            recent_attributed_failures=$(summarize_recent_attributed_urltest_failures "$SERVERS_CACHE" || true)
            recent_unmapped_failures=$(summarize_recent_unmapped_urltest_failures "$SERVERS_CACHE" || true)
            archive_current_error_if_any
            {
                echo "watchdog detected proxy path failure"
                echo "reason=proxied resources failed while direct internet may still work"
                echo "probe_state=$probe_state"
                [ -n "$active_sid" ] && echo "active_server_id=$active_sid"
                [ -n "$active_name" ] && echo "active_server_name=$active_name"
                if [ -n "$suspected_sid" ]; then
                    echo "proxy_failure_class=attributed_server_endpoint"
                    echo "suspected_urltest_server_id=$suspected_sid"
                    [ -n "$suspected_name" ] && echo "suspected_urltest_server_name=$suspected_name"
                else
                    echo "proxy_failure_class=unattributed_proxy_targets"
                fi
                if [ -n "$recent_attributed_failures" ]; then
                    echo "recent_attributed_urltest_failures:"
                    printf '%s\n' "$recent_attributed_failures"
                fi
                if [ -n "$recent_unmapped_failures" ]; then
                    echo "recent_unmapped_urltest_targets:"
                    printf '%s\n' "$recent_unmapped_failures"
                fi
            } > "$ERR_FILE"
        else
            fail_count=$(increment_watchdog_fail_count)
            archive_current_error_if_any
            {
                echo "watchdog detected runtime degradation"
                echo "probe_state=$probe_state"
                echo "fail_count=$fail_count/$WATCHDOG_MIN_FAILS"
            } > "$ERR_FILE"

            if [ "$fail_count" -lt "$WATCHDOG_MIN_FAILS" ]; then
                ok_json "watchdog observed transient failure ($fail_count/$WATCHDOG_MIN_FAILS)"
            fi
        fi
    else
        fail_count="$WATCHDOG_MIN_FAILS"
        archive_current_error_if_any
        {
            echo "watchdog detected hard runtime failure"
            echo "reason=missing process or tun0"
        } > "$ERR_FILE"
    fi

    reset_watchdog_fail_count
    previous_mode=""
    [ -s "$MODE_FILE" ] && previous_mode=$(cat "$MODE_FILE")
    [ -n "$previous_mode" ] || previous_mode="watchdog-restart"

    if [ "$probe_state" = "proxy_failed" ]; then
        watchdog_selected_ids="$TMP_DIR/watchdog.selected_ids.txt"
        watchdog_effective_ids="$TMP_DIR/watchdog.effective_ids.txt"
        watchdog_candidate="$TMP_DIR/config.watchdog.quarantine.json"
        build_server_cache "$RAW_FILE" "$SERVERS_CACHE"
        POST_DATA=$(read_text_file_clean "$PAYLOAD_FILE")
        json_get_servers > "$watchdog_selected_ids"
        selected_count=$(count_lines_in_file "$watchdog_selected_ids")

        if [ "$selected_count" -gt 1 ] 2>/dev/null; then
            bad_sid=$(detect_quarantine_candidate_id "$SERVERS_CACHE" || true)
            if [ -n "$bad_sid" ] && grep -Fxq "$bad_sid" "$watchdog_selected_ids"; then
                quarantine_server_id "$bad_sid"
                build_effective_selected_ids "$watchdog_selected_ids" "$SERVERS_CACHE" "$watchdog_effective_ids"
                effective_count=$(count_lines_in_file "$watchdog_effective_ids")

                if [ "$effective_count" -gt 0 ] 2>/dev/null && [ "$effective_count" -lt "$selected_count" ] 2>/dev/null; then
                    use_ar="false"
                    [ "$(current_mode_name)" = "auto_redirect" ] && use_ar="true"
                    route_mode=$(current_route_mode)
                    strict_mode=$(current_strict_mode)

                    if build_candidate_config "$PAYLOAD_FILE" "$RAW_FILE" "$CUSTOM_FILE" "$watchdog_candidate" "$use_ar" "$route_mode" "$strict_mode" "$watchdog_effective_ids" && \
                       validate_config "$watchdog_candidate" && \
                       try_runtime_start "$watchdog_candidate" "$previous_mode" "$PAYLOAD_FILE"; then
                        copy_text_file_clean "$watchdog_effective_ids" "$ACTIVE_SELECTED_IDS_FILE"
                        set_autostart
                        install_cron
                        write_probe_state "ok"
                        clear_current_error
                        append_runtime_note "watchdog quarantined failing AUTO-BALANCE member id=$bad_sid and rebuilt runtime pool"
                        ok_json "watchdog recovered runtime by quarantining a failing server"
                    fi
                fi
            fi
        fi
    fi

    if try_runtime_start "$CONFIG_FILE" "$previous_mode" "$PAYLOAD_FILE"; then
        ok_json "watchdog recovered runtime using current config"
    fi

    FORCE_REAPPLY="true"
    ACTION="cron"
    handle_apply_or_cron
}

handle_stop() {
    remove_autostart
    cleanup_cron_entries
    /etc/init.d/cron restart >/dev/null 2>&1 || true
    if ! force_stop_runtime; then
        fail_json "Не удалось полностью остановить sing-box. Выполни вручную: killall -9 sing-box"
    fi
    mark_manual_stop
    clear_current_error
    rm -f "$MODE_FILE" "$PROBE_STATE_FILE" "$ACTIVE_SELECTED_IDS_FILE"
    clear_active_server_observation
    if [ "$ACTION" != "cron" ]; then
        reset_quarantined_servers
    fi
    reset_watchdog_fail_count
    ok_json "GOG Sing-Box Launcher остановлен. Автозапуск и cron отключены."
}

handle_clear() {
    remove_autostart
    cleanup_cron_entries
    /etc/init.d/cron restart >/dev/null 2>&1 || true
    force_stop_runtime >/dev/null 2>&1 || true
    mark_manual_stop
    clear_current_error
    rm -f "$RAW_FILE" "$CUSTOM_FILE" "$SETTINGS_FILE" "$PAYLOAD_FILE" "$CONFIG_FILE" "$SERVERS_CACHE" "$MODE_FILE" "$LOG_FILE" "$PROBE_STATE_FILE" "$ACTIVE_SELECTED_IDS_FILE" "$REFILTER_DOMAINS_FILE" "$REFILTER_IPSUM_FILE"
    clear_active_server_observation
    reset_quarantined_servers
    reset_watchdog_fail_count
    rm -rf "$TMP_DIR"/*
    ok_json "Конфигурация удалена."
}

handle_apply_or_cron() {
    new_payload="$TMP_DIR/payload.new.json"
    new_raw="$TMP_DIR/raw_sub.new.txt"
    new_custom="$TMP_DIR/custom_list.new.txt"
    candidate="$TMP_DIR/config.candidate.json"
    force_reapply="${FORCE_REAPPLY:-false}"

    if [ "$ACTION" = "cron" ]; then
        if manual_stop_requested && [ "$force_reapply" != "true" ]; then
            ok_json "cron skipped: service intentionally stopped"
        fi
        [ -s "$PAYLOAD_FILE" ] || fail_json "Нет сохранённой конфигурации для cron."
        POST_DATA=$(read_text_file_clean "$PAYLOAD_FILE")
    else
        POST_DATA=$(strip_utf8_bom_text "$(read_post_body)")
        [ -n "${POST_DATA:-}" ] || fail_json_transient "Пустой POST payload."
    fi
    printf '%s' "$POST_DATA" > "$new_payload"

    sub_url=$(json_get_string "url")
    if [ -z "$sub_url" ]; then
        if [ "$ACTION" = "cron" ]; then
            fail_json "В payload отсутствует источник серверов."
        fi
        fail_json_transient "В payload отсутствует источник серверов."
    fi

    source_mode=$(subscription_source_kind "$sub_url" || true)
    case "$source_mode" in
        remote|inline) ;;
        *)
            fail_json "Неподдерживаемый формат источника серверов. Используйте http(s):// или одну/несколько строк vless://, trojan://, hy2:// или hysteria2://."
            ;;
    esac

    if ! prepare_subscription_source_file "$sub_url" "$new_raw"; then
        # If internet is currently unstable, allow apply from the last cached subscription.
        saved_url=""
        [ -s "$SETTINGS_FILE" ] && saved_url=$(json_get_string_from_text "url" "$(read_text_file_clean "$SETTINGS_FILE")")
        if [ "$source_mode" = "remote" ] && [ -s "$RAW_FILE" ] && [ -n "$saved_url" ] && [ "$saved_url" = "$sub_url" ]; then
            cp "$RAW_FILE" "$new_raw"
            archive_current_error_if_any
            echo "Не удалось скачать подписку, использован локальный кэш." > "$ERR_FILE"
        else
            fail_json "Не удалось получить источник серверов."
        fi
    fi
    if ! validate_subscription_file "$new_raw"; then
        saved_url=""
        [ -s "$SETTINGS_FILE" ] && saved_url=$(json_get_string_from_text "url" "$(read_text_file_clean "$SETTINGS_FILE")")
        if [ "$source_mode" = "remote" ] && [ -s "$RAW_FILE" ] && [ -n "$saved_url" ] && [ "$saved_url" = "$sub_url" ]; then
            cp "$RAW_FILE" "$new_raw"
            if validate_subscription_file "$new_raw"; then
                archive_current_error_if_any
                echo "Downloaded subscription payload was invalid, reused last cached working subscription." > "$ERR_FILE"
            else
                fail_json "Источник серверов повреждён: и свежий контент, и локальный кэш не содержат поддерживаемых share-link строк."
            fi
        else
            fail_json "Источник серверов не содержит поддерживаемых share-link строк."
        fi
    fi

    custom_url=$(json_get_string "custom_url")
    case "$custom_url" in
        *'...'*|*'raw.githubusercontent.com/.../'*|*'example.com/'*)
            custom_url=""
            ;;
    esac
    if [ -n "$custom_url" ]; then
        if ! download_file "$custom_url" "$new_custom"; then
            if [ -f "$CUSTOM_FILE" ]; then
                cp "$CUSTOM_FILE" "$new_custom"
            else
                : > "$new_custom"
            fi
            archive_current_error_if_any
            echo "Не удалось скачать кастомный список доменов, запуск продолжается без него: $custom_url" > "$ERR_FILE"
        fi
        validate_custom_list_file "$new_custom" || { : > "$new_custom"; archive_current_error_if_any; echo "Кастомный список доменов повреждён, запуск продолжается без него." > "$ERR_FILE"; }
    else
        : > "$new_custom"
    fi

    if ! json_get_servers | grep -q '.'; then
        if [ "$ACTION" = "cron" ]; then
            fail_json "Не выбран ни один сервер."
        fi
        fail_json_transient "Не выбран ни один сервер."
    fi

    reset_quarantined_servers
    old_server_cache_for_change="$TMP_DIR/server_cache_previous.txt"
    server_cache_for_change="$TMP_DIR/server_cache_change.txt"
    current_settings_selected_ids_for_change="$TMP_DIR/selected_ids_change.current_settings.txt"
    current_settings_available_ids_for_change="$TMP_DIR/selected_ids_change.current_settings.available.txt"
    payload_selected_ids_for_change="$TMP_DIR/selected_ids_change.payload.txt"
    selected_ids_source_for_change="$TMP_DIR/selected_ids_change.source.txt"
    available_selected_ids_for_change="$TMP_DIR/selected_ids_change.available.txt"
    effective_selected_ids_for_change="$TMP_DIR/selected_ids_change.effective.txt"
    payload_repaired_for_apply="$TMP_DIR/payload.apply.repaired.json"
    preapply_config_backup="$TMP_DIR/config.preapply.backup.json"
    preapply_raw_backup="$TMP_DIR/raw.preapply.backup.txt"
    preapply_custom_backup="$TMP_DIR/custom.preapply.backup.txt"
    preapply_settings_backup="$TMP_DIR/settings.preapply.backup.json"
    preapply_payload_backup="$TMP_DIR/payload.preapply.backup.json"
    preapply_cache_backup="$TMP_DIR/cache.preapply.backup.txt"
    preapply_active_ids_backup="$TMP_DIR/active_selected.preapply.txt"
    previous_mode_label="$(current_mode_label || true)"
    rm -f "$preapply_config_backup" "$preapply_raw_backup" "$preapply_custom_backup" \
        "$preapply_settings_backup" "$preapply_payload_backup" "$preapply_cache_backup" \
        "$preapply_active_ids_backup"
    [ -f "$CONFIG_FILE" ] && cp "$CONFIG_FILE" "$preapply_config_backup"
    [ -f "$RAW_FILE" ] && cp "$RAW_FILE" "$preapply_raw_backup"
    [ -f "$CUSTOM_FILE" ] && cp "$CUSTOM_FILE" "$preapply_custom_backup"
    [ -f "$SETTINGS_FILE" ] && cp "$SETTINGS_FILE" "$preapply_settings_backup"
    [ -f "$PAYLOAD_FILE" ] && cp "$PAYLOAD_FILE" "$preapply_payload_backup"
    [ -f "$SERVERS_CACHE" ] && cp "$SERVERS_CACHE" "$preapply_cache_backup"
    [ -f "$ACTIVE_SELECTED_IDS_FILE" ] && cp "$ACTIVE_SELECTED_IDS_FILE" "$preapply_active_ids_backup"
    if [ -s "$SERVERS_CACHE" ]; then
        cp "$SERVERS_CACHE" "$old_server_cache_for_change"
    elif [ -s "$RAW_FILE" ]; then
        build_server_cache "$RAW_FILE" "$old_server_cache_for_change"
    else
        : > "$old_server_cache_for_change"
    fi
    build_server_cache "$new_raw" "$server_cache_for_change"
    settings_get_selected_ids > "$current_settings_selected_ids_for_change"
    build_available_selected_ids "$current_settings_selected_ids_for_change" "$SERVERS_CACHE" "$current_settings_available_ids_for_change"
    json_get_servers > "$payload_selected_ids_for_change"
    build_replenished_selected_ids "$payload_selected_ids_for_change" "$old_server_cache_for_change" "$server_cache_for_change" "$available_selected_ids_for_change"
    if [ "$ACTION" = "cron" ] && [ -s "$ACTIVE_SELECTED_IDS_FILE" ]; then
        build_replenished_selected_ids "$ACTIVE_SELECTED_IDS_FILE" "$old_server_cache_for_change" "$server_cache_for_change" "$selected_ids_source_for_change"
        if [ ! -s "$selected_ids_source_for_change" ]; then
            cp "$available_selected_ids_for_change" "$selected_ids_source_for_change"
        fi
    else
        cp "$available_selected_ids_for_change" "$selected_ids_source_for_change"
    fi
    build_effective_selected_ids "$selected_ids_source_for_change" "$server_cache_for_change" "$effective_selected_ids_for_change"
    rewrite_json_servers_from_selected_file "$new_payload" "$available_selected_ids_for_change" "$payload_repaired_for_apply"

    if [ "$ACTION" = "cron" ] && [ "$force_reapply" != "true" ] && [ -f "$RAW_FILE" ]; then
        old_hash=$(md5sum "$RAW_FILE" "$CUSTOM_FILE" 2>/dev/null | awk '{print $1}' | tr -d '\n')
        new_hash=$(md5sum "$new_raw" "$new_custom" 2>/dev/null | awk '{print $1}' | tr -d '\n')
        old_effective_hash=$(md5sum "$ACTIVE_SELECTED_IDS_FILE" 2>/dev/null | awk '{print $1}' | tr -d '\n')
        new_effective_hash=$(md5sum "$effective_selected_ids_for_change" 2>/dev/null | awk '{print $1}' | tr -d '\n')
        old_persisted_hash=$(md5sum "$current_settings_available_ids_for_change" 2>/dev/null | awk '{print $1}' | tr -d '\n')
        new_persisted_hash=$(md5sum "$available_selected_ids_for_change" 2>/dev/null | awk '{print $1}' | tr -d '\n')
        if [ -n "$old_hash" ] && [ "$old_hash" = "$new_hash" ] && [ -n "$old_effective_hash" ] && [ "$old_effective_hash" = "$new_effective_hash" ] && [ "$old_persisted_hash" = "$new_persisted_hash" ]; then
            ok_json "Изменений нет."
        fi
    fi

    requested_auto_redirect=$(json_get_bool "use_auto_redirect")
    requested_refilter=$(json_get_bool "refilter")
    payload_for_apply="$payload_repaired_for_apply"
    compat_note=""

    if [ "$requested_refilter" = "true" ] && ! refresh_refilter_rule_sets; then
        if [ "$ACTION" = "cron" ] && [ -s "$CONFIG_FILE" ] && runtime_has_process_and_tun; then
            archive_current_error_if_any
            {
                echo "refilter bootstrap refresh failed"
                echo "reason=github unreachable and persistent bootstrap cache is unavailable"
                echo "action=kept current runtime unchanged"
            } > "$ERR_FILE"
            ok_json "Re:filter cache refresh failed, current runtime kept unchanged."
        fi
        fail_json "Re:filter включён, но локальный cold-start cache не готов: GitHub недоступен и persistent bootstrap cache пуст. Повтори позже или временно сними галку Re:filter."
    fi

    mode_list=""
    if [ "$requested_auto_redirect" = "true" ]; then
        mode_list="auto_redirect:auto_detect_interface:true auto_redirect:default_interface:true"
    fi
    mode_list="$mode_list classic:auto_detect_interface:true classic:default_interface:true classic:default_interface:false"

    selected_mode=""
    for mode in $mode_list; do
        mode_name=$(printf '%s' "$mode" | cut -d: -f1)
        route_mode=$(printf '%s' "$mode" | cut -d: -f2)
        strict_mode=$(printf '%s' "$mode" | cut -d: -f3)

        use_ar="false"
        [ "$mode_name" = "auto_redirect" ] && use_ar="true"

        if ! build_candidate_config "$payload_for_apply" "$new_raw" "$new_custom" "$candidate" "$use_ar" "$route_mode" "$strict_mode" "$selected_ids_source_for_change"; then
            continue
        fi
        if validate_config "$candidate"; then
            selected_mode="$mode_name|$route_mode|$strict_mode"
            break
        fi
    done

    [ -z "$selected_mode" ] && [ "$requested_refilter" = "true" ] && fail_json "Не удалось собрать валидный конфиг с Re:filter. Проверь локальные rule-set файлы и совместимость sing-box."

    [ -n "$selected_mode" ] || {
        msg="Новый конфиг не прошёл проверку sing-box."
        if [ -s /tmp/gog_singbox_check.log ]; then
            msg="$msg $(tail -n 1 /tmp/gog_singbox_check.log | tr -d '\r')"
        fi
        fail_json "$msg"
    }

    effective_selected_count=$(count_lines_in_file "$effective_selected_ids_for_change")
    probe_profile="default"
    runtime_mode_list="$mode_list"
    if [ "$ACTION" = "apply" ]; then
        probe_profile="quick_apply"
        runtime_mode_list=$(printf '%s' "$selected_mode" | tr '|' ':')
    fi
    if [ "$ACTION" = "apply" ] && [ "$source_mode" = "inline" ] && [ "$effective_selected_count" -le 1 ] 2>/dev/null; then
        probe_profile="quick_inline_single"
    fi

    apply_failure_restore_mode="sync"
    if [ "$ACTION" = "apply" ]; then
        apply_failure_restore_mode="async"
    fi

    runtime_success="false"
    effective_label=""
    for mode in $runtime_mode_list; do
        mode_name=$(printf '%s' "$mode" | cut -d: -f1)
        route_mode=$(printf '%s' "$mode" | cut -d: -f2)
        strict_mode=$(printf '%s' "$mode" | cut -d: -f3)

        use_ar="false"
        [ "$mode_name" = "auto_redirect" ] && use_ar="true"

        if ! build_candidate_config "$payload_for_apply" "$new_raw" "$new_custom" "$candidate" "$use_ar" "$route_mode" "$strict_mode" "$selected_ids_source_for_change"; then
            continue
        fi
        if ! validate_config "$candidate"; then
            continue
        fi

        label="$mode_name / $route_mode / strict_route=$strict_mode"
        if try_runtime_start "$candidate" "$label" "$payload_for_apply" "$probe_profile"; then
            runtime_success="true"
            effective_label="$label"
            break
        fi
        if attempt_quarantine_retry_runtime_start "$payload_for_apply" "$new_raw" "$new_custom" "$server_cache_for_change" "$selected_ids_source_for_change" "$effective_selected_ids_for_change" "$candidate" "$mode_name" "$route_mode" "$strict_mode" "$label" "apply" "$probe_profile"; then
            runtime_success="true"
            effective_label="$label"
            break
        fi
    done

    if [ "$runtime_success" != "true" ]; then
        restart_previous_if_possible "$apply_failure_restore_mode"
        if [ -s "$ERR_FILE" ]; then
            fail_json "Новый конфиг не запустился. $(tail -n 20 "$ERR_FILE" | tr '\n' ' ')"
        fi
        fail_json "Новый конфиг не запустился."
    fi

    post_commit_step=""
    post_commit_rc=0
    set +e
    post_commit_step="build_effective_selected_ids"
    build_effective_selected_ids "$selected_ids_source_for_change" "$server_cache_for_change" "$effective_selected_ids_for_change"
    post_commit_rc=$?
    if [ "$post_commit_rc" -eq 0 ]; then
        post_commit_step="commit_active_files"
        commit_active_files "$new_raw" "$new_custom" "$candidate" "$payload_for_apply" "$effective_selected_ids_for_change" "$TMP_DIR/server_cache_build.txt" "$available_selected_ids_for_change"
        post_commit_rc=$?
    fi
    if [ "$post_commit_rc" -eq 0 ]; then
        post_commit_step="write_probe_state"
        write_probe_state "ok"
        post_commit_rc=$?
    fi
    if [ "$post_commit_rc" -eq 0 ]; then
        post_commit_step="clear_current_error"
        clear_current_error
        post_commit_rc=$?
    fi
    set -e

    if [ "$post_commit_rc" -ne 0 ] 2>/dev/null; then
        set +e
        if [ -f "$preapply_config_backup" ]; then
            cp "$preapply_config_backup" "$CONFIG_FILE" >/dev/null 2>&1 || true
        else
            rm -f "$CONFIG_FILE"
        fi
        if [ -f "$preapply_raw_backup" ]; then
            cp "$preapply_raw_backup" "$RAW_FILE" >/dev/null 2>&1 || true
        else
            rm -f "$RAW_FILE"
        fi
        if [ -f "$preapply_custom_backup" ]; then
            cp "$preapply_custom_backup" "$CUSTOM_FILE" >/dev/null 2>&1 || true
        else
            rm -f "$CUSTOM_FILE"
        fi
        if [ -f "$preapply_settings_backup" ]; then
            cp "$preapply_settings_backup" "$SETTINGS_FILE" >/dev/null 2>&1 || true
        else
            rm -f "$SETTINGS_FILE"
        fi
        if [ -f "$preapply_payload_backup" ]; then
            cp "$preapply_payload_backup" "$PAYLOAD_FILE" >/dev/null 2>&1 || true
        else
            rm -f "$PAYLOAD_FILE"
        fi
        if [ -f "$preapply_cache_backup" ]; then
            cp "$preapply_cache_backup" "$SERVERS_CACHE" >/dev/null 2>&1 || true
        else
            rm -f "$SERVERS_CACHE"
        fi
        if [ -f "$preapply_active_ids_backup" ]; then
            copy_text_file_clean "$preapply_active_ids_backup" "$ACTIVE_SELECTED_IDS_FILE"
        else
            rm -f "$ACTIVE_SELECTED_IDS_FILE"
        fi
        if [ -s "$CONFIG_FILE" ]; then
            fallback_mode="$previous_mode_label"
            [ -n "$fallback_mode" ] || fallback_mode="apply-recovery"
            try_runtime_start "$CONFIG_FILE" "$fallback_mode" "$PAYLOAD_FILE" >/dev/null 2>&1 || true
        fi
        set -e
        archive_current_error_if_any
        {
            echo "apply post-start commit failed"
            echo "step=$post_commit_step"
            echo "rc=$post_commit_rc"
            echo "requested_url=$sub_url"
            [ -s "$LOG_FILE" ] && tail -n 40 "$LOG_FILE"
        } > "$ERR_FILE"
        fail_json "Конфиг временно запустился, но commit operator-state сорвался на шаге $post_commit_step. Выполнен откат к предыдущему baseline."
    fi

    if [ "$ACTION" = "cron" ]; then
        ok_json "Подписка обновлена. Режим: $effective_label$compat_note"
    fi

    printf '{"status":"success","message":"%s","mode":"%s"}\n' \
        "$(json_escape "Конфиг применён. Режим: $effective_label$compat_note")" \
        "$(json_escape "$effective_label")"
    exit 0
}

case "$ACTION" in
    status) handle_status ;;
    logs) handle_logs ;;
    update_status) handle_update_status ;;
    update_check) handle_update_check ;;
    log_maint) handle_log_maint ;;
    dependency_status) handle_dependency_status ;;
    get_config) handle_get_config ;;
    get_servers) handle_get_servers ;;
    apply|cron|watchdog|stop|clear|prepare_refilter|dependency_scan|dependency_reset|dependency_accept|dependency_reject|dependency_unreview|update_save_settings|update_download|update_install|update_rollback)
        acquire_action_lock
        case "$ACTION" in
            apply|cron) handle_apply_or_cron ;;
            watchdog) handle_watchdog ;;
            stop) handle_stop ;;
            clear) handle_clear ;;
            prepare_refilter) handle_prepare_refilter ;;
            dependency_scan) handle_dependency_scan ;;
            dependency_reset) handle_dependency_reset ;;
            dependency_accept) handle_dependency_accept ;;
            dependency_reject) handle_dependency_reject ;;
            dependency_unreview) handle_dependency_unreview ;;
            update_save_settings) handle_update_save_settings ;;
            update_download) handle_update_download ;;
            update_install) handle_update_install ;;
            update_rollback) handle_update_rollback ;;
        esac
        ;;
    *) fail_json_transient "Неизвестное действие: $ACTION" ;;
esac
EOF
chmod +x /www/cgi-bin/myproxy_api

mkdir -p /etc/gog/update
cat <<'EOF' > /etc/gog/update/trusted.pub
untrusted comment: GOG Sing-Box Launcher update signing key
RWSOfAeFGOdGkw/D4m/S9SHLPvbjimTuOvkWKttQHrbOZgD93xuGd387
EOF
chmod 0644 /etc/gog/update/trusted.pub

echo "=========================================="
echo "✅ GOG Sing-Box Launcher 1.13.7 baseline установлен (v1.91-sb1137)"
echo "=========================================="
echo "Открой в браузере на роутере: /myproxy/"
