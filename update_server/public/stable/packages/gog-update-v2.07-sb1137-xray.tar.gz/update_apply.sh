#!/bin/sh
set -eu
PKG_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
INSTALLER="$PKG_DIR/gog_singbox_launcher_1_13_7.sh"
[ -s "$INSTALLER" ] || {
    echo "installer missing from update package" >&2
    exit 1
}
[ -d "$PKG_DIR/refilter-cache" ] && export REFILTER_BUNDLE_DIR="$PKG_DIR/refilter-cache"
[ -d "$PKG_DIR/core-cache" ] && export GOG_CORE_BUNDLE_DIR="$PKG_DIR/core-cache"
sh -n "$INSTALLER"
GOG_UPDATE_MODE=1 sh "$INSTALLER"
cat > /tmp/gog-post-update-refresh.sh <<'EOS'
#!/bin/sh
mkdir -p /tmp/gog 2>/dev/null || true
sleep 6
i=0
while [ "$i" -lt 20 ]; do
    if [ ! -d /tmp/gog/action.lock ]; then
        QUERY_STRING='action=cron' REQUEST_METHOD='POST' /www/cgi-bin/myproxy_api >/tmp/gog/post-update-refresh.out 2>&1
        echo "post-update refresh finished rc=$?" > /tmp/gog/post-update-refresh.state
        exit 0
    fi
    i=$((i + 1))
    sleep 2
done
echo "post-update refresh skipped: lock still present" > /tmp/gog/post-update-refresh.state
exit 0
EOS
chmod +x /tmp/gog-post-update-refresh.sh
mkdir -p /tmp/gog 2>/dev/null || true
sh /tmp/gog-post-update-refresh.sh >/tmp/gog/post-update-refresh.launch.log 2>&1 &
cd /
rm -f /tmp/gog-update/update-package.tar.gz 2>/dev/null || true
rm -rf /tmp/gog-update/extract.* 2>/dev/null || true