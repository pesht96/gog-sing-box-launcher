#!/bin/sh
set -eu
PKG_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
INSTALLER="$PKG_DIR/gog_singbox_launcher_1_13_7.sh"
[ -s "$INSTALLER" ] || {
    echo "installer missing from update package" >&2
    exit 1
}
sh -n "$INSTALLER"
gog_was_running=0
if [ -x /www/cgi-bin/myproxy_api ]; then
    gog_status_before="$(REQUEST_METHOD=GET QUERY_STRING='action=status' /www/cgi-bin/myproxy_api 2>/dev/null | tail -n 1 || true)"
    case "$gog_status_before" in
        *'"status":"running"'*) gog_was_running=1 ;;
    esac
fi
if [ "$gog_was_running" != "1" ]; then
    if ps 2>/dev/null | grep '[s]ing-box' >/dev/null 2>&1 && ip link show tun0 >/dev/null 2>&1; then
        gog_was_running=1
    fi
fi
GOG_UPDATE_MODE=1 sh "$INSTALLER"
if [ "$gog_was_running" = "1" ] && [ -s /etc/sing-box/last_payload.json ]; then
    echo "post-update runtime reapply: refreshing generated sing-box config"
    FORCE_REAPPLY=true REQUEST_METHOD=GET QUERY_STRING='action=cron' /www/cgi-bin/myproxy_api >/tmp/gog_update_post_apply.out 2>&1 || {
        cat /tmp/gog_update_post_apply.out >&2 2>/dev/null || true
        exit 1
    }
    cat /tmp/gog_update_post_apply.out 2>/dev/null || true
fi