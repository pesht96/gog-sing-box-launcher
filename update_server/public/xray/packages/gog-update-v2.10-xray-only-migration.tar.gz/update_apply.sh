#!/bin/sh
set -eu

log() {
    printf '%s\n' "$*"
}

warn() {
    printf 'WARN: %s\n' "$*" >&2
}

run_timeout() {
    seconds="$1"
    shift
    if command -v timeout >/dev/null 2>&1; then
        timeout "$seconds" "$@"
        return $?
    fi
    "$@"
}

json_escape_min() {
    sed 's/\\/\\\\/g; s/"/\\"/g'
}

df_available_kb_migration() {
    df -k "$1" 2>/dev/null | awk 'NR == 2 { print $4 + 0; exit }'
}

du_kb_migration() {
    [ -e "$1" ] || {
        printf '0\n'
        return 0
    }
    du -sk "$1" 2>/dev/null | awk 'NR == 1 { print $1 + 0; exit }'
}

format_kb_migration() {
    awk -v kb="$1" 'BEGIN {
        if (kb >= 1048576) {
            printf "%.1f GB", kb / 1048576
        } else {
            printf "%.1f MB", kb / 1024
        }
    }'
}

MIGRATION_OLD_RUNTIME_STOPPED=0

migration_write_failed_status() {
    fail_msg="${1:-Xray-only migration failed. See /etc/gog/update/last_install.log.}"
    esc_msg=$(printf '%s' "$fail_msg" | json_escape_min)
    manifest_url=""
    if [ -s /etc/gog/update/settings.json ]; then
        manifest_url=$(sed -n 's/.*"manifest_url"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' /etc/gog/update/settings.json 2>/dev/null | head -n 1)
    fi
    [ -n "$manifest_url" ] || manifest_url="https://gog-sing-box-launcher.pages.dev/stable/update.json"
    esc_manifest_url=$(printf '%s' "$manifest_url" | json_escape_min)
    now_epoch=$(date +%s 2>/dev/null || echo 0)
    mkdir -p /etc/gog/update >/dev/null 2>&1 || true
    cat > /etc/gog/update/status.json <<GOGMIGRATIONSTATUS
{"status":"success","current_version":"v2.07-sb1137","channel":"stable","compatibility":"sb1137","manifest_url":"$esc_manifest_url","auto_check_enabled":true,"auto_install_enabled":true,"update_state":"install_failed","last_check_epoch":$now_epoch,"latest_version":"v2.10-xray-only","update_available":true,"update_kind":"control_plane","auto_install_allowed":false,"signature_required":true,"signature_status":"verified","message":"$esc_msg"}
GOGMIGRATIONSTATUS
}

migration_on_exit() {
    rc="$1"
    [ "$rc" -eq 0 ] 2>/dev/null && return 0
    set +e
    warn "migration package exited with rc=$rc"
    if [ "$MIGRATION_OLD_RUNTIME_STOPPED" = "1" ] && ! pidof xray >/dev/null 2>&1 && ! pidof sing-box >/dev/null 2>&1; then
        if [ -x /usr/bin/gog-proxy-start ] && [ -s /etc/sing-box/config.json ]; then
            warn "attempting to restore old sing-box runtime after failed migration"
            /usr/bin/gog-proxy-start /etc/sing-box/config.json >/tmp/gog-migration-restore-old-runtime.log 2>&1 &
            sleep 3
        else
            warn "old runtime restore helper/config is unavailable after failed migration"
        fi
    fi
    migration_write_failed_status "Xray-only migration failed before completion; old runtime was restored when possible. See /etc/gog/update/last_install.log."
    return 0
}

trap 'migration_on_exit $?' EXIT

ensure_pre_stop_update_tooling() {
    required_tools=""
    optional_tools=""
    command -v sha256sum >/dev/null 2>&1 || required_tools="$required_tools coreutils-sha256sum"
    required_tools="$required_tools curl ca-bundle nftables kmod-nf-tproxy kmod-nft-tproxy ip-full usign"
    optional_tools="$optional_tools wget-ssl iptables-nft kmod-ipt-tproxy iptables-mod-tproxy"

    log "installing migration tooling and TProxy dependencies:$required_tools"
    if command -v apk >/dev/null 2>&1; then
        apk cache clean >/dev/null 2>&1 || true
        rm -f /var/cache/apk/* >/dev/null 2>&1 || true
        for tool_pkg in $required_tools; do
            run_timeout 120 apk add "$tool_pkg" || {
                echo "failed to install required migration/TProxy package: $tool_pkg" >&2
                return 1
            }
        done
        for tool_pkg in $optional_tools; do
            run_timeout 120 apk add "$tool_pkg" || warn "optional migration fallback package was not installed: $tool_pkg"
        done
    elif command -v opkg >/dev/null 2>&1; then
        run_timeout 120 opkg update >/dev/null 2>&1 || true
        for tool_pkg in $required_tools; do
            run_timeout 120 opkg install "$tool_pkg" || {
                echo "failed to install required migration/TProxy package: $tool_pkg" >&2
                return 1
            }
        done
        for tool_pkg in $optional_tools; do
            run_timeout 120 opkg install "$tool_pkg" || warn "optional migration fallback package was not installed: $tool_pkg"
        done
    else
        echo "no package manager found to install required migration tooling:$required_tools" >&2
        return 1
    fi
}

migration_lan_interface_name() {
    lan_if="$(uci get network.lan.device 2>/dev/null || true)"
    [ -n "$lan_if" ] || lan_if="$(uci get network.lan.ifname 2>/dev/null || true)"
    [ -n "$lan_if" ] || lan_if="br-lan"
    printf '%s' "$lan_if"
}

load_tproxy_modules_migration() {
    for tproxy_mod in nf_tproxy_ipv4 nf_tproxy_ipv6 nft_tproxy xt_TPROXY; do
        modprobe "$tproxy_mod" >/dev/null 2>&1 || true
    done
}

verify_tproxy_pre_stop() {
    load_tproxy_modules_migration
    lan_if="$(migration_lan_interface_name)"
    if command -v nft >/dev/null 2>&1; then
        nft delete table ip gog_xray_preflight >/dev/null 2>&1 || true
        if nft add table ip gog_xray_preflight >/tmp/gog-migration-nft-preflight.out 2>/tmp/gog-migration-nft-preflight.err && \
           nft add chain ip gog_xray_preflight prerouting '{ type filter hook prerouting priority mangle; policy accept; }' >>/tmp/gog-migration-nft-preflight.out 2>>/tmp/gog-migration-nft-preflight.err && \
           nft add rule ip gog_xray_preflight prerouting iifname "$lan_if" meta l4proto tcp tproxy to :12345 meta mark set 1 accept >>/tmp/gog-migration-nft-preflight.out 2>>/tmp/gog-migration-nft-preflight.err; then
            nft delete table ip gog_xray_preflight >/dev/null 2>&1 || true
            log "TProxy preflight: nft path OK on $lan_if"
            return 0
        fi
        warn "TProxy preflight: nft path failed"
        cat /tmp/gog-migration-nft-preflight.err >&2 2>/dev/null || true
        nft delete table ip gog_xray_preflight >/dev/null 2>&1 || true
    fi
    if command -v iptables >/dev/null 2>&1; then
        iptables -t mangle -F GOG_XRAY_PREFLIGHT >/dev/null 2>&1 || true
        iptables -t mangle -X GOG_XRAY_PREFLIGHT >/dev/null 2>&1 || true
        if iptables -t mangle -N GOG_XRAY_PREFLIGHT >/tmp/gog-migration-iptables-preflight.out 2>/tmp/gog-migration-iptables-preflight.err && \
           iptables -t mangle -A GOG_XRAY_PREFLIGHT -p tcp -j TPROXY --on-port 12345 --tproxy-mark 1/1 >>/tmp/gog-migration-iptables-preflight.out 2>>/tmp/gog-migration-iptables-preflight.err; then
            iptables -t mangle -F GOG_XRAY_PREFLIGHT >/dev/null 2>&1 || true
            iptables -t mangle -X GOG_XRAY_PREFLIGHT >/dev/null 2>&1 || true
            log "TProxy preflight: iptables path OK"
            return 0
        fi
        warn "TProxy preflight: iptables path failed"
        cat /tmp/gog-migration-iptables-preflight.err >&2 2>/dev/null || true
        iptables -t mangle -F GOG_XRAY_PREFLIGHT >/dev/null 2>&1 || true
        iptables -t mangle -X GOG_XRAY_PREFLIGHT >/dev/null 2>&1 || true
    fi
    echo "TProxy preflight failed; required kernel/userland support is missing." >&2
    return 1
}

MIGRATION_REPLACE_SINGBOX_FOR_SPACE=0
MIGRATION_MIN_TMP_KB=35000
MIGRATION_MIN_ROOT_WRAPPER_KB=50000

migration_storage_preflight() {
    root_free_kb=$(df_available_kb_migration /usr || true)
    tmp_free_kb=$(df_available_kb_migration /tmp || true)
    case "$root_free_kb" in ''|*[!0-9]*) root_free_kb=0 ;; esac
    case "$tmp_free_kb" in ''|*[!0-9]*) tmp_free_kb=0 ;; esac

    log "storage preflight: /usr free $(format_kb_migration "$root_free_kb"), /tmp free $(format_kb_migration "$tmp_free_kb")"
    if [ "$tmp_free_kb" -lt "$MIGRATION_MIN_TMP_KB" ] 2>/dev/null; then
        echo "not enough /tmp space for migration package and Xray runtime; have $(format_kb_migration "$tmp_free_kb"), need $(format_kb_migration "$MIGRATION_MIN_TMP_KB")" >&2
        return 1
    fi

    if [ -x /usr/bin/xray ] && /usr/bin/xray version >/dev/null 2>&1 && [ -s /usr/share/xray/geoip.dat ] && [ -s /usr/share/xray/geosite.dat ]; then
        log "storage preflight: existing Xray wrapper/assets are usable; resume path does not require additional root flash"
        return 0
    fi

    if [ "$root_free_kb" -ge "$MIGRATION_MIN_ROOT_WRAPPER_KB" ] 2>/dev/null; then
        log "storage preflight: enough flash for Xray compressed-wrapper install without removing sing-box first"
        return 0
    fi

    singbox_reclaim_kb=$(du_kb_migration /usr/bin/sing-box)
    case "$singbox_reclaim_kb" in ''|*[!0-9]*) singbox_reclaim_kb=0 ;; esac
    projected_root_kb=$((root_free_kb + singbox_reclaim_kb))
    log "storage preflight: sing-box reclaimable $(format_kb_migration "$singbox_reclaim_kb"), projected /usr free $(format_kb_migration "$projected_root_kb")"

    if [ "$singbox_reclaim_kb" -gt 10240 ] && [ "$projected_root_kb" -ge "$MIGRATION_MIN_ROOT_WRAPPER_KB" ] 2>/dev/null; then
        MIGRATION_REPLACE_SINGBOX_FOR_SPACE=1
        log "storage preflight: weak-router replace path enabled; sing-box package must be removed before Xray install"
        return 0
    fi

    echo "not enough flash for Xray migration; have $(format_kb_migration "$root_free_kb"), projected after sing-box reclaim $(format_kb_migration "$projected_root_kb"), need $(format_kb_migration "$MIGRATION_MIN_ROOT_WRAPPER_KB")" >&2
    return 1
}

remove_old_singbox_package_for_space() {
    [ "$MIGRATION_REPLACE_SINGBOX_FOR_SPACE" = "1" ] || return 0
    log "removing old sing-box package before Xray install to free flash"
    if command -v apk >/dev/null 2>&1; then
        run_timeout 120 apk del sing-box || {
            echo "failed to remove old sing-box package with apk" >&2
            return 1
        }
    elif command -v opkg >/dev/null 2>&1; then
        run_timeout 120 opkg remove sing-box || {
            echo "failed to remove old sing-box package with opkg" >&2
            return 1
        }
    else
        echo "no package manager found to remove old sing-box package" >&2
        return 1
    fi

    root_free_after_kb=$(df_available_kb_migration /usr || true)
    case "$root_free_after_kb" in ''|*[!0-9]*) root_free_after_kb=0 ;; esac
    log "storage after sing-box removal: /usr free $(format_kb_migration "$root_free_after_kb")"
    if [ "$root_free_after_kb" -lt "$MIGRATION_MIN_ROOT_WRAPPER_KB" ] 2>/dev/null; then
        echo "flash is still too low after removing sing-box; have $(format_kb_migration "$root_free_after_kb"), need $(format_kb_migration "$MIGRATION_MIN_ROOT_WRAPPER_KB")" >&2
        return 1
    fi
}

PKG_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
INSTALLER="$PKG_DIR/gog_singbox_launcher_1_13_7.sh"
CORE_BUNDLE="$PKG_DIR/core-cache"
REFILTER_BUNDLE="$PKG_DIR/refilter-cache"
NEXT_MANIFEST_FILE="$PKG_DIR/xray_next_manifest_url.txt"

[ -s "$INSTALLER" ] || {
    echo "installer missing from update package" >&2
    exit 1
}
[ -s "$CORE_BUNDLE/xray.gz" ] || {
    echo "bundled Xray gzip runtime missing from update package" >&2
    exit 1
}
[ -s "$CORE_BUNDLE/geoip.dat.gz" ] || {
    echo "bundled Xray geoip gzip asset missing from update package" >&2
    exit 1
}
[ -s "$CORE_BUNDLE/geosite.dat.gz" ] || {
    echo "bundled Xray geosite gzip asset missing from update package" >&2
    exit 1
}
[ -s "$REFILTER_BUNDLE/refilter_domains.txt" ] || {
    echo "bundled Re:filter domains lite file missing from update package" >&2
    exit 1
}
[ -s "$REFILTER_BUNDLE/refilter_ipsum.txt" ] || {
    echo "bundled Re:filter ipsum lite file missing from update package" >&2
    exit 1
}

sh -n "$INSTALLER"

log "=== GOG Xray-only migration begin ==="
date 2>/dev/null || true
log "package_dir=$PKG_DIR"

if [ ! -s /etc/sing-box/last_payload.json ]; then
    echo "No saved GOG payload found; refusing to migrate because there is no user subscription state to preserve." >&2
    exit 1
fi

migration_storage_preflight

log "migration inner backup skipped; the old updater backup is the rollback anchor"

if [ -x /usr/bin/gog-proxy-stop ]; then
    log "stopping old GOG runtime through existing stop helper"
    /usr/bin/gog-proxy-stop >/dev/null 2>&1 || warn "old stop helper returned non-zero"
    MIGRATION_OLD_RUNTIME_STOPPED=1
fi

if [ -x /etc/init.d/sing-box ]; then
    log "disabling stock sing-box init service"
    /etc/init.d/sing-box stop >/dev/null 2>&1 || true
    MIGRATION_OLD_RUNTIME_STOPPED=1
    /etc/init.d/sing-box disable >/dev/null 2>&1 || true
fi

ensure_pre_stop_update_tooling
verify_tproxy_pre_stop
remove_old_singbox_package_for_space

log "installing Xray-only control plane and bundled assets"
REFILTER_ALLOW_FULL_UPSTREAM=0 \
GOG_CORE_BUNDLE_DIR="$CORE_BUNDLE" \
REFILTER_INSTALL_BUNDLE_DIR="$REFILTER_BUNDLE" \
REFILTER_BUNDLE_DIR="$REFILTER_BUNDLE" \
GOG_XRAY_MIN_ROOT_KB=120000 \
GOG_DOWNLOAD_MAX_TIME_SECONDS=60 \
GOG_DOWNLOAD_RETRIES=0 \
GOG_UPDATE_MODE=1 \
sh "$INSTALLER"

if [ -s "$NEXT_MANIFEST_FILE" ]; then
    next_manifest_url=$(head -n 1 "$NEXT_MANIFEST_FILE" | tr -d '\r')
    case "$next_manifest_url" in
        http://*|https://*)
            esc_url=$(printf '%s' "$next_manifest_url" | json_escape_min)
            auto_check_enabled=true
            auto_install_enabled=true
            if [ -s /etc/gog/update/settings.json ]; then
                settings_body=$(cat /etc/gog/update/settings.json 2>/dev/null || true)
                case "$settings_body" in *'"auto_check_enabled":false'*) auto_check_enabled=false ;; esac
                case "$settings_body" in *'"auto_install_enabled":false'*) auto_install_enabled=false ;; esac
            fi
            mkdir -p /etc/gog/update
            printf '{"manifest_url":"%s","auto_check_enabled":%s,"auto_install_enabled":%s}\n' "$esc_url" "$auto_check_enabled" "$auto_install_enabled" > /etc/gog/update/settings.json
            log "next Xray-only manifest URL saved: $next_manifest_url"
            ;;
        *)
            warn "next manifest URL ignored because it is not http(s)"
            ;;
    esac
fi

if [ -s /etc/sing-box/last_payload.json ]; then
    log "rebuilding runtime from preserved user payload through new Xray-only cron path"
    for old_update_lock_dir in /tmp/gog-build/action.lock /tmp/gog/action.lock; do
        if [ -d "$old_update_lock_dir" ]; then
            old_update_lock_action=""
            [ -s "$old_update_lock_dir/action" ] && old_update_lock_action=$(sed -n '1p' "$old_update_lock_dir/action" 2>/dev/null | tr -d '\r')
            if [ "$old_update_lock_action" = "update_install" ]; then
                log "clearing inherited update_install lock at $old_update_lock_dir before Xray-only cron rebuild"
                rm -f "$old_update_lock_dir/pid" "$old_update_lock_dir/epoch" "$old_update_lock_dir/action" "$old_update_lock_dir/owner" 2>/dev/null || true
                rmdir "$old_update_lock_dir" 2>/dev/null || true
            fi
        fi
    done
    mkdir -p /tmp/gog-build >/dev/null 2>&1 || true
    allow_probe_epoch=$(date +%s 2>/dev/null || echo 0)
    printf '%s\n' "$allow_probe_epoch" > /tmp/gog-build/allow_failed_probe
    printf '%s\n' "$allow_probe_epoch" > /tmp/gog-allow-failed-probe
    log "migration failed-probe tolerance enabled for preserved-node cron rebuild"
    set +e
    cron_output=$(GOG_ALLOW_START_WITH_FAILED_PROBE=1 QUERY_STRING='action=cron' REQUEST_METHOD='POST' /www/cgi-bin/myproxy_api 2>&1)
    cron_rc=$?
    rm -f /tmp/gog-build/allow_failed_probe >/dev/null 2>&1 || true
    rm -f /tmp/gog-allow-failed-probe >/dev/null 2>&1 || true
    set -e
    printf '%s\n' "$cron_output"
    if [ "$cron_rc" -ne 0 ]; then
        echo "Xray-only cron/apply failed during migration." >&2
        exit 1
    fi
    printf '%s' "$cron_output" | grep -q '"status"[[:space:]]*:[[:space:]]*"success"' || {
        echo "Xray-only cron/apply did not return success during migration." >&2
        exit 1
    }
fi

[ -s /etc/xray/gog-xray.json ] || {
    echo "Xray config was not created." >&2
    exit 1
}
XRAY_LOCATION_ASSET=/usr/share/xray /usr/bin/xray run -test -config /etc/xray/gog-xray.json
pidof xray >/dev/null 2>&1 || {
    echo "Xray process is not running after migration." >&2
    exit 1
}
if pidof sing-box >/dev/null 2>&1; then
    echo "sing-box process is still running after Xray migration." >&2
    exit 1
fi

if [ "${GOG_REMOVE_OLD_SINGBOX_PACKAGE:-0}" = "1" ]; then
    log "optional old sing-box package removal requested"
    if command -v apk >/dev/null 2>&1; then
        run_timeout 45 apk del sing-box >/dev/null 2>&1 || warn "apk del sing-box failed or timed out"
    elif command -v opkg >/dev/null 2>&1; then
        run_timeout 45 opkg remove sing-box >/dev/null 2>&1 || warn "opkg remove sing-box failed or timed out"
    else
        warn "no package manager found for sing-box removal"
    fi
fi

rm -f "$PKG_DIR/core-cache"/Xray-*.zip "$PKG_DIR/core-cache"/*.gz >/dev/null 2>&1 || true
rm -rf /tmp/gog-build/* /tmp/gog-core-bundle /tmp/gog-refilter-bundle >/dev/null 2>&1 || true
mkdir -p /tmp/gog-build >/dev/null 2>&1 || true

if [ -x /www/cgi-bin/myproxy_api ]; then
    log "scheduling post-migration Xray-only update status refresh"
    (
        sleep 3
        QUERY_STRING='action=update_check' REQUEST_METHOD='GET' /www/cgi-bin/myproxy_api
        rm -rf /tmp/gog-update >/dev/null 2>&1 || true
    ) >/tmp/gog-migration-post-update-check.log 2>&1 &
fi

log "=== GOG Xray-only migration complete ==="
exit 0