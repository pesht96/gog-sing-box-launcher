#!/bin/sh
set -eu
PKG_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
UI_TARGET=/www/gog/index.html
CGI_TARGET=/www/cgi-bin/myproxy_api
XRAY_BIN=/usr/bin/xray
LOG_MARKER=/etc/gog/temp_log_retention.json
version=$("$XRAY_BIN" version | head -n 1 | awk '{print $2}')
printf '%s\n' "$version" | awk -F. '{exit !(NF == 3 && ($1 > 26 || ($1 == 26 && ($2 > 10 || ($2 == 10 && $3 >= 31)))))}' || {
    echo 'Xray 26.10.31 or newer is required; no files changed.' >&2
    exit 1
}
[ -s "$UI_TARGET" ] && [ -s "$CGI_TARGET" ] || exit 1
(cd "$PKG_DIR" && sha256sum -c SHA256SUMS) || exit 1
sh -n "$PKG_DIR/myproxy_api"
cp "$UI_TARGET" "$PKG_DIR/previous-ui"
cp "$CGI_TARGET" "$PKG_DIR/previous-cgi"
ui_changed=0
cgi_changed=0
finish() {
    result=$?
    trap - EXIT
    if [ "$result" -ne 0 ]; then
        [ "$ui_changed" = 0 ] || cp "$PKG_DIR/previous-ui" "$UI_TARGET"
        [ "$cgi_changed" = 0 ] || cp "$PKG_DIR/previous-cgi" "$CGI_TARGET"
    fi
    rm -f "$UI_TARGET.new.$$" "$CGI_TARGET.new.$$"
    exit "$result"
}
trap finish EXIT
trap 'exit 1' HUP INT TERM
cp "$PKG_DIR/index.html" "$UI_TARGET.new.$$"
if [ -s "$LOG_MARKER" ] && grep -qx 'LOG_ROTATE_MAX_BYTES=4194304' "$CGI_TARGET"; then
    sed 's/^LOG_ROTATE_MAX_BYTES=262144$/LOG_ROTATE_MAX_BYTES=4194304/' "$PKG_DIR/myproxy_api" > "$CGI_TARGET.new.$$"
else
    cp "$PKG_DIR/myproxy_api" "$CGI_TARGET.new.$$"
fi
chmod 644 "$UI_TARGET.new.$$"
chmod 755 "$CGI_TARGET.new.$$"
sh -n "$CGI_TARGET.new.$$"
mv "$UI_TARGET.new.$$" "$UI_TARGET"
ui_changed=1
mv "$CGI_TARGET.new.$$" "$CGI_TARGET"
cgi_changed=1
echo 'v2.11-xray-only UI/CGI installed; runtime and user settings untouched.'
